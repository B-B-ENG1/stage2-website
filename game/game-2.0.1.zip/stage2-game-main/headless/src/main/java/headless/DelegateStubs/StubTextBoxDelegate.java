package headless.DelegateStubs;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextBoxDelegate;

public class StubTextBoxDelegate extends TextBoxDelegate {

    private String text = "";
    private float width = 0;
    private float height = 0;
    private float x;
    private float y;
    private Color color;
    ClickListener clickListener;
    ChangeListener changeListener;

    public StubTextBoxDelegate(float width, float height,  Color color) {
        this.width = width;
        this.height = height;
        this.color = color;
    }

    @Override
    public void addToStage(StageDelegate stage) {}

    @Override
    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String getText() {
        return text;
    }

    @Override
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void addListener(ClickListener listener) {
        clickListener = listener;
    }

    @Override
    public void addListener(ChangeListener listener) {
        changeListener = listener;
    }
}
