package headless.DelegateStubs;

import io.github.team6ENG.EscapeUni.Screens.Delegates.FrameBufferDelegate;

public class StubFrameBufferDelegate extends FrameBufferDelegate {
    public StubFrameBufferDelegate() {}

    @Override
    public void begin() {}

    @Override
    public void end() {}

}
