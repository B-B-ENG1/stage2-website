package headless;

import io.github.team6ENG.EscapeUni.Entities.Goose;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;

public class GooseAccessGameScreen extends GameScreen {

    public GooseAccessGameScreen(final Main game) {
        super(game);
    }

    /**
     * A getter for the goose in this game screen.
     * @return the goose which follows the player in the game.
     */
    public Goose getGoose() {
        return goose;
    }
}
