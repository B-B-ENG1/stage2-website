package headless.AlwaysEnergyDrink;

import io.github.team6ENG.EscapeUni.Entities.EnergyDrink;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.EnergyDrinkManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.PondManager;
import io.github.team6ENG.EscapeUni.World;

/**
 * A partial mock of the energy drink manager which always returns true when
 * checking whether a drink is active.
 */
public class AEDEnergyDrinkManager extends EnergyDrinkManager {

    public AEDEnergyDrinkManager(World world, GraphicsManager graphics,
                                 AudioManager audioManager, int blockSize) {
        super(world, graphics, audioManager, blockSize);
    }

    @Override
    public boolean isDrinkEffective() {
        return true;
    }
}
