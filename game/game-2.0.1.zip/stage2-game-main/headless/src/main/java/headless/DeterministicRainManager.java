package headless;

import io.github.team6ENG.EscapeUni.Managers.*;
import io.github.team6ENG.EscapeUni.World;

/**
 * A rain manager which places puddles deterministically, i.e. it always
 * places a puddle rather than having a random chance to.
 */
public class DeterministicRainManager extends RainManager {

    boolean canRain = false;

    public DeterministicRainManager(World world, GraphicsManager graphics, AudioManager audio,
                                    PuddleManager puddleManager) {
        super(world, graphics, audio, puddleManager);
    }

    /**
     * Allows rain to happen: in this case, it will be guaranteed to rain when
     * tryRain is called.
     */
    public void allowRain() {
        canRain = true;
    }


    /**
     * Always attempts to add exactly one puddle this frame.
     * @param delta is the time since the previous frame.
     */
    @Override
    protected void placePuddle(float delta) {
        puddleManager.addPuddles(1);
    }

    /**
     * If allowed to rain, guarantees that rain will occur. Otherwise,
     * rain will not occur.
     * @param delta is the time since the previous frame.
     */
    @Override
    protected void tryRain(float delta) {
        if (canRain) {
            world.rainEvent();
            audio.playRain();
        }
    }


}
