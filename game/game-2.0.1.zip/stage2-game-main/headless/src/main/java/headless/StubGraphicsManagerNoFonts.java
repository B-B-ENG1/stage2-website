package headless;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.utils.viewport.FitViewport;
import headless.DelegateStubs.*;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.*;

public class StubGraphicsManagerNoFonts extends StubGraphicsManager {

    @Override
    public void initialiseFonts() {
    }

    @Override
    public void dispose() {}

    @Override
    public void flush() {}
}
