package headless;

import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;

import java.util.*;

public class MockLeaderboard extends LeaderboardManager {

    private class EntryComparator implements Comparator<ScoreEntry> {
        @Override
        public int compare(ScoreEntry o1, ScoreEntry o2) {
            return o2.score - o1.score;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof EntryComparator;
        }
    }

    private PriorityQueue<ScoreEntry> localFakeDatabase;
    private PriorityQueue<ScoreEntry> remoteFakeDatabase;

    @Override
    protected void createTableIfNotExists() {
        EntryComparator comparator = new EntryComparator();
        localFakeDatabase = new PriorityQueue<>(comparator);
        remoteFakeDatabase = new PriorityQueue<>(comparator);
    }


    @Override
    protected int submitScoreRemote(String username, int score) {
        remoteFakeDatabase.add(new ScoreEntry(username, score));
        // Return a fake position
        return 1;
    }


    @Override
    protected int addScoreLocal(String username, int score) {
        localFakeDatabase.add(new ScoreEntry(username, score));
        // Return a fake position
        return 1;
    }

    @Override
    protected List<ScoreEntry> getTopScoresRemote(int limit) {
        List<ScoreEntry> list = new ArrayList<ScoreEntry>();
        Iterator<ScoreEntry> iterator = remoteFakeDatabase.iterator();
        for (int i = 0; i < limit; i++) {
            list.add(iterator.next());
        }
        return list;
    }

    @Override
    protected List<ScoreEntry> getTopScoresLocal(int limit) {
        List<ScoreEntry> list = new ArrayList<ScoreEntry>();
        Iterator<ScoreEntry> iterator = localFakeDatabase.iterator();
        for (int i = 0; i < limit; i++) {
            list.add(iterator.next());
        }
        return list;
    }



}
