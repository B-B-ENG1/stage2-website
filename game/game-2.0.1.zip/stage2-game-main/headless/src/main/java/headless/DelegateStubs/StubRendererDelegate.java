package headless.DelegateStubs;

import com.badlogic.gdx.graphics.OrthographicCamera;
import io.github.team6ENG.EscapeUni.Screens.Delegates.RendererDelegate;

public class StubRendererDelegate extends RendererDelegate {

    public StubRendererDelegate() {}

    @Override
    public void render() {}

    @Override
    public void setView(OrthographicCamera camera) {}

    @Override
    public void dispose() {}
}
