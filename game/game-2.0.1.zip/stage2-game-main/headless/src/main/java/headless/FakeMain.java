package headless;

import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Main;

public class FakeMain extends Main {

    private MockLeaderboard leaderboard;

    public FakeMain() {
        super();
        leaderboard = new MockLeaderboard();

    }

    @Override
    public void createGraphicsManager() {
        graphicsManager = new StubGraphicsManager();
    }

    @Override
    public LeaderboardManager createLeaderboard() {
        return leaderboard;
    }

    /**
     * Adds a score to the leaderboard with the current username.
     * @param score is the score to be added.
     */
    public void addScore(int score) {
        leaderboard.addOrUpdateScore(username, score);
    }

}
