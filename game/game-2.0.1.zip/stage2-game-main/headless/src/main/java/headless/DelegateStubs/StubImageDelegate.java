package headless.DelegateStubs;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;

public class StubImageDelegate extends ImageDelegate {

    private float x, y, scaleX, scaleY, rotation, width, height;

    public StubImageDelegate() {}

    @Override
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public void setScale(float scale) {
        scaleX = scale;
        scaleY = scale;
    }

    @Override
    public void setScale(float scaleX, float scaleY) {
        this.scaleX = scaleX;
        this.scaleY = scaleY;
    }

    @Override
    public void setRotation(float rotation) {
        this.rotation = rotation;
    }

    @Override
    public void draw(SpriteBatch batch, float parentAlpha) {}

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public void setWidth(float width) {
        this.width = width;
    }

    @Override
    public void setHeight(float height) {
        this.height = height;
    }
}
