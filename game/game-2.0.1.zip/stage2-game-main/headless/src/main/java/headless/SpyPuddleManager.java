package headless;

import io.github.team6ENG.EscapeUni.Managers.BlockPositionCache;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.PuddleManager;

public class SpyPuddleManager extends PuddleManager {

    private int addedPuddleCount = 0;

    public SpyPuddleManager(GraphicsManager graphics, int blockSize) {
        super(graphics, blockSize);
    }

    @Override
    public void addPuddles(int puddleNumber) {
        super.addPuddles(puddleNumber);
        addedPuddleCount++;
    }

    /**
     * Determines how many puddles have been told to be added by external
     * commands.
     * @return an integer representing the number of calls of {@code addPuddles}
     *  there have been.
     */
    public int getAddedPuddleCount() {
        return  addedPuddleCount;
    }
}
