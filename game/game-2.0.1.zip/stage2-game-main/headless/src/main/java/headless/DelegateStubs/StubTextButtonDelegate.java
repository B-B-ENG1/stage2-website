package headless.DelegateStubs;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

public class StubTextButtonDelegate extends TextButtonDelegate {

    protected float width = 0;
    protected float height = 0;
    protected float posX = 0;
    protected float posY = 0;
    protected Color color;
    protected ClickListener clickListener;

    public StubTextButtonDelegate() {}


    @Override
    public void setFontScale(float scale) {}

    @Override
    public void pad(float pad) {}

    @Override
    public void setSize(float width, float height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public float getWidth() {return width;}

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setPosition(float x, float y) {
        posX = x;
        posY = y;
    }

    @Override
    public void setColor(Color color) {this.color = color;}

    @Override
    public void addToStage(StageDelegate stage) {
        // Note: We may want to make this a spy method in the future, which
        // allows the stage delegate to keep track of which button delegates etc.
        // it contains.
    }

    @Override
    public Cell addToTable(Table table) {
        return table.add();
    }

    @Override
    public void addListener(ClickListener listener) {
        clickListener = listener;
    }

    @Override
    public void click(float x, float y) {
        // For testing purposes.
        InputEvent event = new InputEvent();
        event.setType(InputEvent.Type.touchDown);
        clickListener.clicked(event, x, y);
        event.setType(InputEvent.Type.touchUp);
        clickListener.clicked(event, x, y);
    }

    @Override
    public void enter(float x, float y) {
        // For testing purposes.
        InputEvent event = new InputEvent();
        event.setType(InputEvent.Type.touchUp);
        clickListener.enter(event, x, y, 1, new Actor());
    }

    @Override
    public void exit(float x, float y) {
        // For testing purposes.
        InputEvent event = new InputEvent();
        event.setType(InputEvent.Type.exit);
        clickListener.exit(event, x, y, 1, new Actor());
    }

    @Override
    public Color getColor() {
        return color;
    }

}
