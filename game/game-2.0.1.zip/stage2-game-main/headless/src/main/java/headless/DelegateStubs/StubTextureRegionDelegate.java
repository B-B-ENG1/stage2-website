package headless.DelegateStubs;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import io.github.team6ENG.EscapeUni.Screens.Delegates.SpriteDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;

public class StubTextureRegionDelegate extends TextureRegionDelegate {
    public StubTextureRegionDelegate() {}

    @Override
    public void draw(SpriteBatch batch, float x, float y) {}

    @Override
    public void draw(SpriteBatch batch, float x, float y,
                     float width, float height) {}

    @Override
    public float getRegionWidth() {
        return 1;
    }

    @Override
    public float getRegionHeight() {
        return 1;
    }

    @Override
    public SpriteDelegate createSpriteDelegate() {
        return new StubSpriteDelegate();
    }

    @Override
    public void setSpriteRegion(Sprite sprite) {}

    @Override
    public void dispose() {}
}
