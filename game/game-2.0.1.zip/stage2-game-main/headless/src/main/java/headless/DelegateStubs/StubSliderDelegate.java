package headless.DelegateStubs;

import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import io.github.team6ENG.EscapeUni.Screens.Delegates.SliderDelegate;

public class StubSliderDelegate extends SliderDelegate {

    private float value = 0;
    private ChangeListener changeListener;

    private Runnable clickRunner;

    public StubSliderDelegate(){}

    @Override
    public void setValue(float value) {
        this.value = value;
    }

    @Override
    public float getValue() {
        return value;
    }

    @Override
    public void addListener(ChangeListener listener) {
        changeListener = listener;
    }


    @Override
    public Cell addToTable(Table table) {
        return table.add();
    }

    @Override
    public void change(float value) {
        // For testing purposes.
        this.value = value;
        ChangeListener.ChangeEvent event = new ChangeListener.ChangeEvent();
        changeListener.changed(event, new Actor());
    }

}
