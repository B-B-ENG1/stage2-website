package headless.AlwaysEnergyDrink;

import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.EnergyDrinkManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;

/**
 * A partial mock of game screen for which the player always has a drink speed
 * boost active.
 */
public class AEDGameScreen extends GameScreen {

    public AEDGameScreen(Main game) {
        super(game);
    }

    @Override
    public void initialiseEnergyDrinks(int number, int blockSize) {
        energyDrinkManager = new AEDEnergyDrinkManager(world, graphics, audioManager, blockSize);
    }
}
