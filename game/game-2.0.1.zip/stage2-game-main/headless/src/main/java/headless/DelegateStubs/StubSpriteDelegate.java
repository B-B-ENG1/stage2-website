package headless.DelegateStubs;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

import io.github.team6ENG.EscapeUni.Screens.Delegates.SpriteDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;

public class StubSpriteDelegate extends SpriteDelegate {

    private float x, y, width, height;

    public StubSpriteDelegate() {}

    @Override
    public void draw(SpriteBatch batch) {}

    @Override
    public float getX() {
        return x;
    }

    @Override
    public float getY() {
        return y;
    }

    @Override
    public float getWidth() {
        return width;
    }

    @Override
    public float getHeight() {
        return height;
    }

    @Override
    public void setScale(float scale) {}

    @Override
    public void setScale(float scaleX, float scaleY) {}

    @Override
    public void translateX(float deltaX) {
        x += deltaX;
    }

    @Override
    public void setX(float x) {
        this.x = x;
    }

    @Override
    public void translateY(float deltaY) {
        y += deltaY;
    }

    @Override
    public void setY(float y) {
        this.y = y;
    }

    @Override
    public void setBounds(float x, float y, int width, int height) {
        setX(x);
        setY(y);
        this.width = width;
        this.height = height;
    }

    @Override
    public void setRegion(TextureRegionDelegate texture) {}

    @Override
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    @Override
    public boolean nullTexture() {
        return false;
    }

    @Override
    public void setColor(float r, float g, float b, float a) {}

    @Override
    public void dispose() {}

}
