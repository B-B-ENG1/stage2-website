package headless;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.utils.viewport.FitViewport;

import headless.DelegateStubs.*;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.*;

public class StubGraphicsManager extends GraphicsManager {

    @Override
    protected void createBatch() {}

    @Override
    protected void createButtonSkin() {}

    @Override
    public void initialiseFonts() {
        menuFont = new BitmapFont();
        gameFont = new BitmapFont();
    }

    @Override
    public void drawText(BitmapFont font, String str, float x, float y) {}

    @Override
    public void drawImage(ImageDelegate image, float parentAlpha) {}

    @Override
    public void drawTexture(TextureDelegate texture, float x, float y) {}

    @Override
    public void drawTexture(TextureDelegate texture, float x,
                            float y, float width, float height) {}

    @Override
    public void drawTextureRegion(TextureRegionDelegate texture, float x,
                                  float y, float width, float height) {}

    public void drawTextureRegion(TextureRegionDelegate texture, float x,
                                  float y) {}

    @Override
    public void drawSprite(SpriteDelegate sprite) {}

    @Override
    public void setBatchColour(Color colour) {}

    @Override
    public void updateBatchProjectionMatrix(Matrix4 matrix) {}

    @Override
    public Matrix4 getTransformMatrix() {
        return new Matrix4();
    }

    @Override
    public void beginBatch() {}

    @Override
    public void endBatch() {}

    @Override
    public void dispose() {
        if (menuFont != null) {
            menuFont.dispose();
        }
        if (gameFont != null) {
            gameFont.dispose();
        }
    }

    @Override
    public void flush() {}

    @Override
    public TextBoxDelegate createTextBox(String message, int width, int height,
                                         Color color) {
        return new StubTextBoxDelegate(width, height, color);
    }

    @Override
    public StageDelegate createStageDelegate(FitViewport viewport) {
        return new StubStageDelegate();
    }

    @Override
    public StageDelegate createFixedStageDelegate(FitViewport viewport) {
        return new StubStageDelegate();
    }

    @Override
    public TextButtonDelegate createTextButtonDelegate(String text) {
        return new StubTextButtonDelegate();
    }

    @Override
    public SpriteDelegate createSpriteDelegate(TextureRegionDelegate texture) {
        return new StubSpriteDelegate();
    }

    @Override
    public SliderDelegate createSliderDelegate(float min,
                                               float max,
                                               float stepSize,
                                               boolean vertical ) {
        return new StubSliderDelegate();
    }

    @Override
    public TextureDelegate createTextureDelegate(String asset) {
        return new StubTextureDelegate();
    }

    @Override
    public TextureDelegate createTextureDelegate(int width, int height,
                                                 Pixmap.Format format) {
        return new StubTextureDelegate();
    }

    @Override
    public RendererDelegate createRendererDelegate(TiledMap map, float unitScale) {
        return new StubRendererDelegate();
    }

    @Override
    public FrameBufferDelegate createFrameBufferDelegate(Pixmap.Format format,
                                                         int width,
                                                         int height,
                                                         boolean hasDepth) {
        return new StubFrameBufferDelegate();
    }
}
