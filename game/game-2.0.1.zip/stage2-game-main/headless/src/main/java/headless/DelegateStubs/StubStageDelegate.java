package headless.DelegateStubs;

import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

public class StubStageDelegate extends StageDelegate {

    public StubStageDelegate() {}

    @Override
    public void addActor(Actor actor) {}

    @Override
    public void setInputProcessor() {}

    @Override
    public boolean isInputProcessor() {
        return false;
    }

    @Override
    public void act() {}

    public void act(float delta) {}

    @Override
    public void draw() {}

    @Override
    public Viewport getViewport() {
        return new FitViewport(0,0);
    }

    @Override
    public Matrix4 getCameraCombinedProjection() {
        return new Matrix4();
    }

    @Override
    public void dispose() {}
}
