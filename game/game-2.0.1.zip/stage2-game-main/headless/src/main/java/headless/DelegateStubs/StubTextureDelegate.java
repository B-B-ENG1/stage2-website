package headless.DelegateStubs;

import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDrawableDelegate;

public class StubTextureDelegate extends TextureDelegate {

    public StubTextureDelegate() {}

    @Override
    public void draw(SpriteBatch batch, float x, float y) {}

    @Override
    public void draw(SpriteBatch batch, float x, float y,
                     float width, float height) {}

    @Override
    public void dispose() {}

    @Override
    public void draw(Pixmap pixmap, int x, int y) {}

    @Override
    public float getWidth() {
        return 1;
    }

    @Override
    public float getHeight() {
        return 1;
    }

    @Override
    public TextureRegionDelegate[][] split(int tileWidth, int tileHeight) {
        TextureRegionDelegate[][] delegates = new TextureRegionDelegate[32][32];
        for (int i = 0; i < delegates.length; i++) {
            for (int j = 0; j < delegates[i].length; j++) {
                delegates[i][j] = new StubTextureRegionDelegate();
            }
        }
        return delegates;
    }

    @Override
    public ImageDelegate createImage() {
        return new StubImageDelegate();
    }

    @Override
    public TextureRegionDrawableDelegate createDrawable() {
        return new StubTextureRegionDrawableDelegate();
    }
}
