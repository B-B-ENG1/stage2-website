package headless.DelegateStubs;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDrawableDelegate;

public class StubTextureRegionDrawableDelegate
    extends TextureRegionDrawableDelegate {

    public StubTextureRegionDrawableDelegate() {}

    @Override
    public ImageButtonDelegate createImageButton() {
        return new StubImageButtonDelegate();
    }

    @Override
    public void setMinSize(float width, float height) {}

    @Override
    public float getMinWidth() {
        return 1;
    }

    @Override
    public float getMinHeight() {
        return 1;
    }
}

