package headless;

import headless.AlwaysEnergyDrink.AEDGameScreen;
import io.github.team6ENG.EscapeUni.Entities.EnergyDrink;
import io.github.team6ENG.EscapeUni.Entities.Player;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class EnergyDrinkTests extends AbstractMainFakeTest {
    @ParameterizedTest
    @ValueSource(floats = {
        0, EnergyDrink.duration / 2, EnergyDrink.duration - 0.1f
    })
    public void drinkActiveTest(float duration) {
        EnergyDrink drink = new EnergyDrink(
            main.getWorld(),
            0,
            0,
            main.graphicsManager,
            main.audioManager
        );
        drink.collect();
        drink.update(duration);
        assertTrue(drink.isEffective(), "The drink should still be " +
            "effective after time " + duration + " s.");
    }

    @ParameterizedTest
    @ValueSource(floats = {
        EnergyDrink.duration, EnergyDrink.duration + 0.1f
    })
    public void drinkDoneTest(float duration) {
        EnergyDrink drink = new EnergyDrink(
            main.getWorld(),
            0,
            0,
            main.graphicsManager,
            main.audioManager
        );
        drink.collect();
        drink.update(duration);
        assertFalse(drink.isEffective(), "The drink should no longer be " +
            "effective after time " + duration + " s.");
    }

    @Test
    public void drinkSpeedTest() {
        AEDGameScreen game = new AEDGameScreen(main);
        game.render(0.1f);
        assertEquals(EnergyDrink.speedModifier, game.playerSpeedModifier, 0.1f,
            "Player speed should be modified when a drink is active.");
    }
}
