package headless;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.Mockito;

import static org.mockito.Mockito.mock;

public abstract class AbstractHeadlessGdxTest {

    @BeforeEach
    public void setup() {
        Gdx.gl = Gdx.gl20 = mock(GL20.class);
        HeadlessLauncher.main(new String[0]);
    }

    /**
     * Mocks an input such that LibGDX believes a certain key to be pressed.
     * @param key is the key to be pressed, using {@code Input.Keys}
     *            attributes.
     */
    public void mockKeyPressed(int key) {
        Input mockInput = mock(Input.class);
        Mockito.when(mockInput.isKeyPressed(key)).thenReturn(true);
        Gdx.input = mockInput;
    }

    /**
     * Mocks an input such that LibGDX believes a certain key to have just been
     * pressed.
     * @param key is the key to be pressed, using {@code Input.Keys}
     *            attributes.
     */
    public void mockKeyJustPressed(int key) {
        Input mockInput = mock(Input.class);
        Mockito.when(mockInput.isKeyJustPressed(key)).thenReturn(true);
        Gdx.input = mockInput;
    }

    /**
     * Mocks simultaneous input of two keys such that LibGDX believes them to be pressed.
     * @param key1 is the first key to be pressed, using {@code Input.Keys}
     * @param key2 is the first key to be pressed, using {@code Input.Keys}
     *            attributes.
     */
    public void mockKeysPressed(int key1, int key2) {
        Input mockInput = mock(Input.class);
        Mockito.when(mockInput.isKeyPressed(key1)).thenReturn(true);
        Mockito.when(mockInput.isKeyPressed(key2)).thenReturn(true);
        Gdx.input = mockInput;
    }

    /**
     * Resets input to not press any keys.
     */
    public void resetMockKeys() {
        Gdx.input = Mockito.mock(Input.class);
    }

}
