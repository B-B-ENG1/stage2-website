package headless;

import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Screens.WinScreen;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class LeaderboardTests extends AbstractMainFakeTest {

    // Note: Leaderboard ordering is not to be tested here.
    // This class is for testing a fake of the database: it's about
    // whether something has tried to be added, not whether it actually
    // has.

    @ParameterizedTest
    @ValueSource(ints = {0, 100, 200, 300, 400})
    public void leaderboardAddTest(int score) {
        main.getWorld().incrementScore(score - World.initialScore);
        WinScreen win = new WinScreen(main);
        main.username = "testUser";
        win.show();
        MockLeaderboard lb = (MockLeaderboard) win.getLeaderboard();
        LeaderboardManager.ScoreEntry actual = lb.getTopScores(1).get(0);
        assertEquals(new LeaderboardManager.ScoreEntry(main.username, score),
            actual,
            "Incorrect score saved to database."
        );
    }

}
