package headless.ScreenTests;

import com.badlogic.gdx.Game;
import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Entities.Bus;
import io.github.team6ENG.EscapeUni.Screens.*;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class WinLoseScreenTests extends AbstractMainFakeTest {

    @Test
    public void outOfTimeTest() {
        syncPostRunnables();
        GameScreen game = new GameScreen(main);
        main.setScreen(game);
        game.render(main.getWorld().getTimer());
        assertInstanceOf(GameOverScreen.class, main.getCurrentScreen(), "When time hits zero, the game should lose.");
    }

    @Test
    public void WinLoseMainMenuButtonTest() {
        WinScreen screen = new WinScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate mainMenuButton = screen.getMainMenuButton();
        mainMenuButton.click(0,0);
        assertEquals(InstructionsScreen.clickColor, mainMenuButton.getColor(),
            "Main Menu button should change to the \"click color\" when clicked.");
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        mainMenuButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, mainMenuButton.getColor(),
            "Main Menu button should change to the \"normal color\" when exited.");
        mainMenuButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, mainMenuButton.getColor(),
            "Main Menu button should change to the \"click color\" when entered.");
    }

    @Test
    public void WinLoseExitButtonTest() {
        WinScreen screen = new WinScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate ExitButton = screen.getExitButton();
        ExitButton.click(0, 0);
        assertEquals(InstructionsScreen.clickColor, ExitButton.getColor(),
            "Exit button should change to the \"click color\" when clicked.");
        assertInstanceOf(WinScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        ExitButton.exit(0, 0);
        assertEquals(InstructionsScreen.normalColor, ExitButton.getColor(),
            "Exit button should change to the \"normal color\" when exited.");
        ExitButton.enter(0, 0);
        assertEquals(InstructionsScreen.clickColor, ExitButton.getColor(),
            "Exit button should change to the \"click color\" when entered.");
    }

    @Test
    public void WinLoseAchievementsButtonTest() {
        WinScreen screen = new WinScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate achievementsButton = screen.getAchievementsButton();
        achievementsButton.click(0, 0);
        assertEquals(InstructionsScreen.clickColor, achievementsButton.getColor(),
            "Achievements button should change to the \"click color\" when clicked.");
        assertInstanceOf(WinScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        achievementsButton.exit(0, 0);
        assertEquals(InstructionsScreen.normalColor, achievementsButton.getColor(),
            "Achievements button should change to the \"normal color\" when exited.");
        achievementsButton.enter(0, 0);
        assertEquals(InstructionsScreen.clickColor, achievementsButton.getColor(),
            "Achievements button should change to the \"click color\" when entered.");
    }

    @Test
    public void gameWinTest() {
        syncPostRunnables();
        GameScreen game = new GameScreen(main);
        main.setScreen(game);
        Bus bus = game.getBus();
        bus.leave();
        game.render(20f);
        assertInstanceOf(WinScreen.class, main.getCurrentScreen(),
            "Game should be won after the bus leaves.");
    }
}
