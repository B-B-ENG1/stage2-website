package headless;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class PlayerTests extends AbstractMainFakeTest{

    /**
     * Asserts that, when a key is pressed, a certain movement should happen.
     * @param plr is the player which should be moving.
     * @param keyPressed is the key which is pressed.
     * @param deltaX is the expected change in X.
     * @param deltaY is the expected change in Y.
     * @param timeDelta is the change in time over which the movement occurs.
     * @param speedModifier is the speed modifier affecting the movement.
     */
    private void assertMovement(Player plr, int keyPressed, float deltaX,
                                float deltaY, float timeDelta,
                                float speedModifier) {
        float prevX = plr.getX();
        float prevY = plr.getY();
        // When key is pressed and inputs are handled
        mockKeyPressed(keyPressed);
        plr.handleInput(timeDelta, speedModifier);
        resetMockKeys();
        // Then we should have correct displacement.
        assertEquals(prevY + deltaY,
            plr.getY(), 0.01f, "Player did not displace by the correct amount in the" +
                " y direction when a key was pressed.");
        assertEquals(prevX + deltaX, plr.getX(), 0.01f,
            "Player did not displace by the correct amount in the " +
                "x direction when a key was pressed.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0.5f, 1.1f, 1.5f, 2.5f})
    public void downTest(float delta) {
        // Initial setup for the player.
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );
        TiledMapTileLayer layer = new TiledMapTileLayer( 800, 800, 16,16);
        plr.loadSprite(layer, 8);
        plr.sprite.setY(700);

        // Moving down
        float displacementY = -plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.S, 0, displacementY, delta, 1);
        displacementY = -plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.DOWN, 0, displacementY, delta, 1);
    }

    @ParameterizedTest
    @ValueSource(floats = {0.5f, 1.1f, 1.5f, 2.5f})
    public void upTest(float delta) {
        // Initial setup for the player.
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );
        // Arbitrary tile layer to load the player onto. This is similar to Ron Cooke and
        // Langwith, being mostly just dark empty space for testing convenience.
        TiledMapTileLayer layer = new TiledMapTileLayer( 800, 800, 16,16);
        plr.loadSprite(layer, 8);

        // Moving up
        float displacementY = plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.W, 0, displacementY, delta, 1);
        displacementY = plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.UP, 0, displacementY, delta, 1);
    }

    @ParameterizedTest
    @ValueSource(floats = {0.5f, 1.1f, 1.5f, 2.5f})
    public void leftTest(float delta) {
        // Initial setup for the player.
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );
        // Arbitrary tile layer to load the player onto. This is similar to Ron Cooke and
        // Langwith, being mostly just dark empty space for testing convenience.
        TiledMapTileLayer layer = new TiledMapTileLayer( 800, 800, 16,16);
        plr.loadSprite(layer, 8);
        plr.sprite.setX(700);

        // Moving left
        float displacementX = -plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.A, displacementX, 0, delta, 1);
        displacementX = -plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.LEFT, displacementX, 0, delta, 1);

    }

    @ParameterizedTest
    @ValueSource(floats = {0.5f, 1.1f, 1.5f, 2.5f})
    public void rightTest(float delta) {
        // Initial setup for the player.
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );
        // Arbitrary tile layer to load the player onto. This is similar to Ron Cooke and
        // Langwith, being mostly just dark empty space for testing convenience.
        TiledMapTileLayer layer = new TiledMapTileLayer( 800, 800, 16,16);
        plr.loadSprite(layer, 8);

        // Moving right
        float displacementX = plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.D, displacementX, 0, delta, 1);
        displacementX = plr.computeDisplacement(delta, 1);
        assertMovement(plr, Input.Keys.RIGHT, displacementX, 0, delta, 1);

    }

    @ParameterizedTest
    @MethodSource("movementAnimationTestCases")
    public void movementAnimationTest(int key, Player.AnimationEnum expectedAnim) {
        // Initial setup for the player.
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );
        TiledMapTileLayer layer = new TiledMapTileLayer( 800, 800, 16,16);
        plr.loadSprite(layer, 8);

        // Now check sprite
        mockKeyPressed(key);
        plr.handleInput(1,1);
        plr.updatePlayer(0);
        assertEquals(expectedAnim, plr.getAnimatingState(),
            "Player animation failed to update when moving forwards.");
        resetMockKeys();
    }

    /**
     * Gives test cases for the movementAnimationTest test. These take the form
     * (Key Pressed, Expected Animation Enum Value)
     * @return The stream of test case arguments.
     */
    private static Stream<Arguments> movementAnimationTestCases() {
        return Stream.of(
            Arguments.of(Input.Keys.S, Player.AnimationEnum.FORWARDS),
            Arguments.of(Input.Keys.W, Player.AnimationEnum.BACKWARDS),
            Arguments.of(Input.Keys.A, Player.AnimationEnum.LEFT_FORWARDS),
            Arguments.of(Input.Keys.D, Player.AnimationEnum.RIGHT_FORWARDS)
        );
    }

    @ParameterizedTest
    @MethodSource("mapLimitTestCases")
    public void mapLimitTest(Player plr, float x, float y, int key) {
        plr.sprite.setX(x);
        plr.sprite.setY(y);
        assertMovement(plr, key, 0, 0, 1, 1);
    }

    private static Stream<Arguments> mapLimitTestCases() {
        // Initial setup for the player.
        FakeMain main = new FakeMain();
        main.create();
        Player plr = new Player(
            main.graphicsManager,
            main.getWorld(),
            main.audioManager,
            main.itemManager
        );

        // Run the tests on the actual map used in the game.
        int tileDimensions = GameScreen.defaultTileDimensions;
        TiledMap map = new TmxMapLoader().load("tileMap/map.tmx");
        TiledMapTileLayer collisionLayer = (TiledMapTileLayer)map.getLayers().get(GameScreen.wallLayer);
        plr.loadSprite(collisionLayer, tileDimensions);
        float mapWidth = main.getWorld().getWorldWidth(tileDimensions);
        float mapHeight = main.getWorld().getWorldHeight(tileDimensions);
        return Stream.of(
            Arguments.of(plr, mapWidth - plr.sprite.getWidth(), 0, Input.Keys.D),
            Arguments.of(plr, 0, mapHeight - plr.sprite.getHeight(), Input.Keys.W),
            Arguments.of(plr, 0, 0, Input.Keys.A),
            Arguments.of(plr, 0, 0, Input.Keys.S)
        );
    }
}
