package headless.ScreenTests;

import com.badlogic.gdx.Game;
import headless.AbstractMainFakeTest;
import headless.MockLeaderboard;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Screens.*;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class AchievementTests extends AbstractMainFakeTest {

    @Test
    public void pveEventTest() {
        main.getWorld().positiveEventFound();
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertTrue(screen.achievementFound("Completed an event"));
    }

    @Test
    public void nveEventTest() {
        main.getWorld().negativeEventFound();
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertTrue(screen.achievementFound("Completed an event"));
    }

    @Test
    public void hdnEventTest() {
        main.getWorld().hiddenEventFound();
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertTrue(screen.achievementFound("Completed an event"));
    }

    @Test
    public void completedNoEventTest() {
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertFalse(screen.achievementFound("Completed an event"));
    }

    @Test
    public void completedAllEventsTest() {
        // Find all events.
        for (int i = 0; i < World.totalPositiveEvents; i++) {
            main.getWorld().positiveEventFound();
        }
        for (int i = 0; i < World.totalNegativeEvents; i++) {
            main.getWorld().negativeEventFound();
        }
        for (int i = 0; i < World.totalHiddenEvents; i++) {
            main.getWorld().hiddenEventFound();
        }
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertTrue(screen.achievementFound("All events in one run"));
    }

    @ParameterizedTest
    @MethodSource("notCompletedAllEventsTestCases")
    public void notCompletedAllEventsTest(int pos, int neg, int hid) {
        // Find all events.
        for (int i = 0; i < pos; i++) {
            main.getWorld().positiveEventFound();
        }
        for (int i = 0; i < neg; i++) {
            main.getWorld().negativeEventFound();
        }
        for (int i = 0; i < hid; i++) {
            main.getWorld().hiddenEventFound();
        }
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertFalse(screen.achievementFound("All events in one run"));
    }

    private static Stream<Arguments> notCompletedAllEventsTestCases() {
        return Stream.of(
            Arguments.of(0,0,0),
            Arguments.of(World.totalPositiveEvents,0,0),
            Arguments.of(0,World.totalNegativeEvents,0),
            Arguments.of(0,0,World.totalHiddenEvents),
            Arguments.of(1,1,1),
            Arguments.of(
                World.totalPositiveEvents - 1,
                World.totalNegativeEvents - 1,
                World.totalHiddenEvents - 1
            )
        );
    }

    @ParameterizedTest
    @ValueSource(floats = {
        AchievementsScreen.FAST_REMAINING * World.initialTimer,
        AchievementsScreen.FAST_REMAINING * World.initialTimer - 0.1f,
        AchievementsScreen.FAST_REMAINING * World.initialTimer - 30f,
        0
    })
    public void finishFastAchievementTest(float timeTaken) {
        main.getWorld().decrementTimer(timeTaken);
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertTrue(screen.achievementFound("Finishing fast"));
    }

    @ParameterizedTest
    @ValueSource(floats = {
        World.initialTimer,
        AchievementsScreen.FAST_REMAINING * World.initialTimer + 0.1f,
        AchievementsScreen.FAST_REMAINING * World.initialTimer + 30f
    })
    public void finishFastNoAchievementTest(float timeTaken) {
        main.getWorld().decrementTimer(timeTaken);
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertFalse(screen.achievementFound("Finishing fast"));
    }

    @Test
    public void onLeaderboardTest() {
        // Add enough worse scores to show a score of 100.
        for (int i = 0; i < 10; i++) {
            main.username = "worseTestUser" + i;
            main.addScore(50 + i);
        }
        main.username = "testUser";
        main.addScore(100);
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        LeaderboardManager lb = main.createLeaderboard();
        assertTrue(screen.achievementFound("On the leaderboard"));
    }

    @Test
    public void notOnLeaderboardTest() {
        // Add enough better scores to hide a score of 50.
        for (int i = 0; i < 10; i++) {
            main.username = "betterTestUser" + i;
            main.addScore(100 + i);
        }
        main.username = "testUser";
        main.addScore(50);
        AchievementsScreen screen = new AchievementsScreen(main);
        screen.show();
        assertFalse(screen.achievementFound("On the leaderboard"));
    }

    @Test
    public void mainMenuButtonTest() {
        AchievementsScreen screen = new AchievementsScreen(main);
        main.setScreen(screen);
        screen.show();
        ButtonDelegate menuButton = screen.getAchievementsMainMenuButton();
        menuButton.enter(0, 0);
        assertEquals(InstructionsScreen.clickColor, menuButton.getColor(),
            "Main menu button should change to the \"click color\" when entered.");
        menuButton.click(0, 0);
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: main menu screen initially not set as the" +
            "current screen.");
        menuButton.exit(0, 0);
        assertEquals(InstructionsScreen.normalColor, menuButton.getColor(),
            "menu button should change to the \"click color\" when entered.");
    }

    @Test
    public void backButtonTest() {
        AchievementsScreen screen = new AchievementsScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate backButton = screen.getAchievementsBackButton();
        backButton.enter(0, 0);
        assertEquals(InstructionsScreen.clickColor, backButton.getColor(),
            "Back button should change to the \"click color\" when entered.");
        backButton.click(0, 0);
        assertInstanceOf(WinScreen.class, main.getCurrentScreen(), "Test setup failed: win screen initially not set as the" +
            "current screen.");
        backButton.exit(0, 0);
        assertEquals(InstructionsScreen.normalColor, backButton.getColor(),
            "Back should change to the \"click color\" when entered.");
    }
}
