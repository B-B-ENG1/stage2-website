package headless;

import com.badlogic.gdx.Game;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Managers.*;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.Screens.LangwithScreen;
import io.github.team6ENG.EscapeUni.Screens.PauseScreen;
import io.github.team6ENG.EscapeUni.Screens.RonCookeScreen;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import javax.swing.*;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class WorldTests extends AbstractMainFakeTest {

    @Test
    public void timerDecrementTest() {
        World world = new World();
        world.decrementTimer(2);
        assertEquals(World.initialTimer - 2, world.getTimer(), 0.1,
            "When the time is decremented by 2 from its initial value," +
                "the new time should be 2 less than the initial value.");
        world.decrementTimer(0);
        assertEquals(World.initialTimer - 2, world.getTimer(), 0.1,
            "When the time is decremented by 0, it should not change value");
        // The difference will be -1, so we expect it to default to 0.
        world.decrementTimer(world.getTimer() + 1);
        assertEquals(0, world.getTimer(), 0.1,
            "When the time decrement is greater than the current time," +
                "the timer should set to 0."
        );
        try {
            world.decrementTimer(-1);
        } catch (IllegalArgumentException e) {
            assertEquals("Time delta must be non-negative.", e.getMessage());
            return;
        }
        fail("An IllegalArgumentException should be thrown when a negative" +
            " time delta is provided.");
    }

    @ParameterizedTest
    @MethodSource("getScoreTestCases")
    public void scoreTest(float scoreDelta, float expectedScore) {
        World world = main.getWorld();
        world.incrementScore(scoreDelta);
        assertEquals(expectedScore, world.getScore(), 0.1,
            "Score failed to correctly update after change.");
    }

    private static Stream<Arguments> getScoreTestCases() {
        return Stream.of(
            Arguments.of(-World.initialScore, 0f),
            Arguments.of(-World.initialScore - 1, 0f),
            Arguments.of(10, World.initialScore + 10)
        );
    }

    @Test
    public void negativeDistanceErrorTest() {
        try {
            World.withinDistance(0, 0, -1);
        } catch(IllegalArgumentException e) {
            return;
        }
        fail("withinDistance should throw an error if given a negative square" +
            "distance.");
    }

    @Test
    public void withinDistanceTests() {
        assertFalse(World.withinDistance(1, 1, 2),
            "Point (1,1) should not be within square distance" +
                "2 of (0,0)."
        );
        assertTrue(World.withinDistance(4, 4, 33),
            "Point (4,4) should be within square distance " +
                "31 of (0,0)."
        );
    }

    @Test
    public void correctReset() {
        World world = new World();
        // Given non-initial values for events, timer, score
        world.positiveEventFound();
        world.negativeEventFound();
        world.negativeEventFound();
        world.hiddenEventFound();
        world.incrementScore(100);
        world.decrementTimer(120);
        // When these values are reset
        world.reset();
        // Then the values should return to their initial values.
        assertEquals(World.initialTimer, world.getTimer(),
            "Timer should reset to initial value");
        assertEquals(World.initialScore, world.getScore(),
            "Score should reset to initial value");
        assertEquals(0, world.getFoundHiddenEvents(),
            "Found hidden events should reset to 0.");
        assertEquals(0, world.getFoundPositiveEvents(),
            "Found positive events should reset to 0.");
        assertEquals(0, world.getFoundNegativeEvents(),
            "Found negative events should reset to 0.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0f, 0.1f, 10f})
    public void pausedTimerTest(float delta) {
        // Initial setup.
        GraphicsManager graphicsManager = main.graphicsManager;
        AudioManager audioManager = new AudioManager();
        ItemManager items = new ItemManager(main);
        Player plr = new Player(graphicsManager, main.getWorld(), audioManager, items);
        GameScreen game = new GameScreen(main);

        // Set up game, pause, and check timer.
        main.setScreen(game);
        PauseScreen pause = game.pauseMenu();
        pause.render(delta);
        assertEquals(World.initialTimer, main.getWorld().getTimer(),
            0.01f, "Timer should not change on the pause screen.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0f, 0.1f, 10f})
    public void timerTestGame(float delta) {
        // Initial setup.
        GraphicsManager graphicsManager = main.graphicsManager;
        AudioManager audioManager = new AudioManager();
        ItemManager items = new ItemManager(main);
        Player plr = new Player(graphicsManager, main.getWorld(), audioManager, items);
        GameScreen game = new GameScreen(main);
        // Set the screen up and render.
        main.setScreen(game);
        game.render(delta);
        assertEquals(World.initialTimer - delta, main.getWorld().getTimer(),
            0.01f, "Timer failed to change on game screen.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0f, 0.1f, 10f})
    public void timerTestRC(float delta) {
        // Initial setup.
        GraphicsManager graphicsManager = main.graphicsManager;
        AudioManager audioManager = new AudioManager();
        ItemManager items = new ItemManager(main);
        Player plr = new Player(graphicsManager, main.getWorld(), audioManager, items);
        GameScreen game = new GameScreen(main);
        BuildingManager manager = new BuildingManager(main, game, plr, audioManager);
        RonCookeScreen rcs = new RonCookeScreen(main, manager, game);
        // Set the screen up and render.
        main.setScreen(rcs);
        rcs.render(delta);
        assertEquals(World.initialTimer - delta, main.getWorld().getTimer(),
            0.01f, "Timer failed to change on Ron Cooke screen.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0f, 0.1f, 10f})
    public void timerTestLW(float delta) {
        // Initial setup.
        GraphicsManager graphicsManager = main.graphicsManager;
        AudioManager audioManager = new AudioManager();
        ItemManager items = new ItemManager(main);
        Player plr = new Player(graphicsManager, main.getWorld(), audioManager, items);
        GameScreen game = new GameScreen(main);
        BuildingManager manager = new BuildingManager(main, game, plr, audioManager);
        LangwithScreen lws = new LangwithScreen(main, manager, game);
        // Set the screen up and render.
        main.setScreen(lws);
        lws.render(delta);
        assertEquals(World.initialTimer - delta, main.getWorld().getTimer(),
            0.01f, "Timer failed to change on Langwith screen.");
    }



    @ParameterizedTest
    @ValueSource(floats = {0, 0.1f, 4f, 10f})
    public void clockTimeTest(float delta) {
        GameScreen screen = new GameScreen(main);
        main.setScreen(screen);
        screen.render(delta);
        assertEquals(World.initialTimer - delta, main.getWorld().getTimer(),
            "Timer failed to decrement by correct time over delay.");
    }

    @ParameterizedTest
    @ValueSource(floats = {0, 0.1f, 4f, 10f})
    public void scoreTimeTest(float delta) {
        GameScreen screen = new GameScreen(main);
        main.setScreen(screen);
        screen.render(delta);
        assertEquals(World.initialScore - delta, main.getWorld().getScore(),
            "Timer failed to decrement by correct time over delay.");
    }

}
