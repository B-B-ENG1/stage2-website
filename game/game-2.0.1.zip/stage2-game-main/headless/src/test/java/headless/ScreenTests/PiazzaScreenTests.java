package headless.ScreenTests;

import com.badlogic.gdx.Input;
import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Managers.BuildingManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.Screens.PauseScreen;
import io.github.team6ENG.EscapeUni.Screens.PiazzaScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class PiazzaScreenTests extends AbstractMainFakeTest {

    @Test
    public void piazzaTest() {
        syncPostRunnables();
        GameScreen game = new GameScreen(main);
        BuildingManager building = new BuildingManager(main, game,
            game.getPlayer(), main.audioManager
        );
        // When Piazza screen is loaded...
        PiazzaScreen piazza = new PiazzaScreen(main, building, game);
        main.setScreen(piazza);
        mockKeyJustPressed(Input.Keys.P);
        piazza.render(0f);
        assertInstanceOf(PauseScreen.class, main.getCurrentScreen(),
            "Game should pause correctly on the Piazza screen.");
    }
}
