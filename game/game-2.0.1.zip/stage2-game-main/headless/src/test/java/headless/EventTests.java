package headless;

import com.badlogic.gdx.Input;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.Entities.*;
import io.github.team6ENG.EscapeUni.Managers.*;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

public class EventTests extends AbstractMainFakeTest {

    @Test
    public void puddleInteractionTest() {
        GameScreen game = new GameScreen(main);
        Player plr = game.getPlayer();
        PuddleManager puddleManager = game.getPuddleManager();
        Puddle puddle = puddleManager.getPuddles().get(0);
        plr.sprite.setPosition(
            puddle.x - plr.sprite.getWidth() / 2,
            puddle.y - plr.sprite.getHeight() / 2
        );
        plr.checkPuddleCollision();
        assertTrue(plr.inPuddle(), "Player should be recognised as being in a" +
            " puddle.");
    }

    @ParameterizedTest
    @MethodSource("getPuddleCollisionTestCases")
    public void puddleCollisionTest(float puddleX, float puddleY,
                                    float playerX, float playerY,
                                    boolean shouldCollide) {
        Puddle puddle = new Puddle(main.graphicsManager, puddleX, puddleY);
        assertEquals(shouldCollide, puddle.checkCollision(playerX, playerY),
            "Puddle centred at " + puddleX + ", " + puddleY + " should collide with" +
                " player centred at " + playerX + ", " + playerY);

    }

    private static Stream<Arguments> getPuddleCollisionTestCases() {
        Puddle puddle = new Puddle(new StubGraphicsManagerNoFonts(), 0, 0);
        float width = puddle.getImage().getWidth();
        float height = puddle.getImage().getHeight();
        return Stream.of(
            Arguments.of(0, 100, width/2, 100-width/3, true),
            Arguments.of(5, 8, 5, 8, true),
            Arguments.of(700, 800, 700+width, 800 + height, true),
            Arguments.of(200, 400, 200 - width, 400 - height, true),
            Arguments.of(600, 650, 650 - width * 2, 400 + height * 2, false)
        );
    }

    @ParameterizedTest
    @ValueSource(floats = {
        RainManager.rainDuration,
        RainManager.rainDuration + 1
    })
    public void rainStopTest(float time) {
        RainManager rain = new RainManager(
            main.getWorld(),
            main.graphicsManager,
            main.audioManager,
            new PuddleManager(main.graphicsManager, 3)
        );
        main.getWorld().rainEvent();
        rain.update(time);
        assertFalse(main.getWorld().isRaining(),
            "Rain should stop after the rain duration has passed.");
    }

    @ParameterizedTest
    @ValueSource(floats = {
        0.01f,
        RainManager.rainDuration/2,
        RainManager.rainDuration - 1
    })
    public void rainStayTest(float time) {
        RainManager rain = new RainManager(
            main.getWorld(),
            main.graphicsManager,
            main.audioManager,
            new PuddleManager(main.graphicsManager, 3)
        );
        main.getWorld().rainEvent();
        rain.update(time);
        assertTrue(main.getWorld().isRaining(),
            "Rain should not stop before the rain duration has passed.");
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3, 4, 5})
    public void rainPuddleTest(int puddleNum) {
        SpyPuddleManager puddles = new SpyPuddleManager(main.graphicsManager, 3);
        DeterministicRainManager rain = new DeterministicRainManager(
            main.getWorld(),
            main.graphicsManager,
            main.audioManager,
            puddles
        );
        main.getWorld().rainEvent();
        // Update the rain manager puddleNum number of times,
        // which should give this number of puddles since
        // the deterministic manager is guaranteed to place a puddle.
        for (int i = 0; i < puddleNum; i++) rain.update(1);
        assertEquals(puddleNum, puddles.getAddedPuddleCount(),
            "Incorrect number of puddles added.");
    }

    @ParameterizedTest
    @ValueSource(ints = {0, 1, 2, 3, 4, 5})
    public void noRainPuddleTest(int puddleNum) {
        SpyPuddleManager puddles = new SpyPuddleManager(main.graphicsManager, 3);
        DeterministicRainManager rain = new DeterministicRainManager(
            main.getWorld(),
            main.graphicsManager,
            main.audioManager,
            puddles
        );
        // Update the rain manager puddleNum number of times.
        for (int i = 0; i < puddleNum; i++) rain.update(1);
        assertEquals(0, puddles.getAddedPuddleCount(),
            "Incorrect number of puddles added.");
    }

    @Test
    public void wormCollisionTest() {
        Player plr = new Player(main.graphicsManager,
                                main.getWorld(),
                                main.audioManager,
                                main.itemManager
        );
        WormManager worms =  new WormManager(main.graphicsManager, 3);
        main.getWorld().addWormManager(worms);
        worms.addWorms(1);
        Worm worm = worms.getWorms().get(0);
        plr.sprite.setPosition(
            worm.x - plr.sprite.getWidth()/2 + worm.getImage().getWidth()/2,
            worm.y - plr.sprite.getHeight()/2 + worm.getImage().getHeight()/2
        );
        plr.checkWormCollision(1);
        Worm worm2 = main.getWorld().consumeWormPickupRequest();
        assertEquals(worm, worm2, "Incorrect worm pickup request following " +
            "worm collision.");
    }

    @Test
    public void wormNoMoveTest() {
        // Given a player belonging to a game screen and world, and a worm
        GameScreen game = new GameScreen(main);
        Player plr = game.getPlayer();

        WormManager worms =  new WormManager(main.graphicsManager, 3);
        main.getWorld().addWormManager(worms);
        worms.addWorms(1);
        Worm worm = worms.getWorms().get(0);

        // When the worm hinders the player
        main.getWorld().requestWormPickup(worm);
        game.render(0.1f);
        float oldX = plr.getX();

        // and the player attempts to move
        mockKeyPressed(Input.Keys.D);
        game.render(1f);

        // Then the player should not move
        assertEquals(oldX, plr.getX(), 0.1,
            "Player should not move when stopped by a worm.");

    }


}
