package headless;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.Entities.Goose;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Entities.Torch;
import io.github.team6ENG.EscapeUni.Entities.Worm;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Managers.LightingManager;
import io.github.team6ENG.EscapeUni.Managers.WormManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class GooseTests extends AbstractMainFakeTest {

    @Test
    public void gooseDeletesWormTest() {
        // Given a goose and player belonging to a world, and a worm
        World world = main.getWorld();
        Player plr = new Player(
            main.graphicsManager,
            world,
            main.audioManager,
            main.itemManager
        );
        Goose goose = new Goose(main.graphicsManager, world);
        TiledMapTileLayer layer = new TiledMapTileLayer(0,0,0,0);
        goose.loadSprite(layer, 1);

        WormManager manager = new WormManager(main.graphicsManager, 3);
        manager.addWorms(1);
        world.addWormManager(manager);
        Worm worm = manager.getWorms().get(0);

        // when the worm is requested to be picked up and the goose is told to
        // target whilst at the worm
        world.requestWormPickup(worm);
        goose.setPosition(worm.x, worm.y);
        goose.target(0.1f, 0, manager, plr);
        goose.target(4f, 0, manager, plr);

        // then the worm is removed and collected
        assertFalse(manager.getWorms().contains(worm),
            "The worm should be removed after it is eaten.");
        assertTrue(worm.isCollected(),
            "The worm should be collected after it is eaten.");
        // Note: Whilst this test uses many classes' methods, the only class
        // which uses nontrivial and non-constructor methods is the goose class.
        // This is hence a "sociable" unit test.
    }

    @Test
    public void gooseFoodTest() {
        GooseAccessGameScreen game = new GooseAccessGameScreen(main);
        Player plr = game.getPlayer();
        Goose goose = game.getGoose();
        ItemManager items = main.itemManager;
        int initialGooseCount = Goose.gooseCount;
        // When the item is collected, E is pressed and the goose is close
        // enough...
        items.getGooseFood().collect();
        game.render(0f);
        goose.setPosition(
            plr.getX() + plr.sprite.getWidth()/2 - goose.getWidth()/2,
            plr.getY() + plr.sprite.getHeight()/2 - goose.getHeight()/2
        );
        mockKeyJustPressed(Input.Keys.E);
        game.render(0f);
        // Create baby geese
        assertEquals(initialGooseCount + 5, Goose.gooseCount,
            "Baby geese should be created when the goose food is used on the" +
                " goose.");
    }

    @Test
    public void torchTest() {
        GameScreen game = new GameScreen(main);
        LightingManager light = game.lighting;
        Torch torch = game.getPlayer().torch;
        torch.toggleNoNoise(true);
        assertTrue(light.isVisible("playerTorch"),
            "Torch light should be visible when switched on.");
        torch.toggleNoNoise(false);
        assertFalse(light.isVisible("playerTorch"),
            "Torch light should not be visible when switched off.");
    }

    @Test
    public void stealTorchTest() {
        // Initial setup for sociable unit test
        GooseAccessGameScreen game = new GooseAccessGameScreen(main);
        Player plr = game.getPlayer();
        Goose goose = game.getGoose();
        LightingManager light = game.lighting;
        Torch torch = game.getPlayer().torch;
        // Torch is collected first and switched on, so that we avoid false
        // positives
        main.itemManager.getTorch().collect();
        torch.toggleNoNoise(true);
        // When the torch is switched on, then the light should not be visible.
        goose.stealTorch(plr, light, main.itemManager);
        assertFalse(light.isVisible("playerTorch"),
            "Torch light should not be visible when torch is stolen.");
        assertTrue(light.isVisible("gooseTorch"),
            "Torch light should be visible on the goose when torch is stolen.");
    }
}
