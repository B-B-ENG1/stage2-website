package headless.ScreenTests;

import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.GameOverScreen;
import io.github.team6ENG.EscapeUni.Screens.MainMenuScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GameOverScreenTests extends AbstractMainFakeTest {

    @Test
    public void mainMenuButtonTest() {
        GameOverScreen screen = new GameOverScreen(main, "void");
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate mainMenuButton = screen.getMainMenuButton();
        mainMenuButton.click(0,0);
        assertEquals(GameOverScreen.clickColor, mainMenuButton.getColor(),
            "Main menu button should change to the \"click color\" when clicked.");
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: game over screen initially not set as the" +
            "current screen.");
        mainMenuButton.exit(0,0);
        assertEquals(GameOverScreen.normalColor, mainMenuButton.getColor(),
            "Main menu button should change to the \"normal color\" when exited.");
        mainMenuButton.enter(0,0);
        assertEquals(GameOverScreen.clickColor, mainMenuButton.getColor(),
            "Main menu button should change to the \"click color\" when entered.");
    }

    @Test
    public void exitButtonTest() {
        GameOverScreen screen = new GameOverScreen(main, "void");
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate exitButton = screen.getExitButton();
        exitButton.click(0,0);
        assertEquals(GameOverScreen.clickColor, exitButton.getColor(),
            "Exit button should change to the \"click color\" when clicked.");
        assertInstanceOf(GameOverScreen.class, main.getCurrentScreen(), "Test setup failed: game over screen initially not set as the" +
            "current screen.");
        exitButton.exit(0,0);
        assertEquals(GameOverScreen.normalColor, exitButton.getColor(),
            "Exit button should change to the \"normal color\" when exited.");
        exitButton.enter(0,0);
        assertEquals(GameOverScreen.clickColor, exitButton.getColor(),
            "Exit button should change to the \"click color\" when entered.");
    }
}
