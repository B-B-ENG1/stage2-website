package headless;

import com.badlogic.gdx.Input;
import io.github.team6ENG.EscapeUni.Entities.Goose;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class PointsTests extends AbstractMainFakeTest{

    @Test
    public void ptTest1() {
        float initialPoints = main.getWorld().getScore();
        GooseAccessGameScreen gs = new GooseAccessGameScreen(main);
        ItemManager im = main.itemManager;
        Player plr = gs.getPlayer();
        Goose goose = gs.getGoose();
        im.getGooseFood().collect();
        gs.render(0f);
        goose.setPosition(
            plr.getX() + plr.sprite.getWidth()/2 - goose.getWidth()/2,
            plr.getY() + plr.sprite.getHeight()/2 - goose.getHeight()/2
        );
        mockKeyJustPressed(Input.Keys.E);
        gs.render(0f);
        assertEquals(initialPoints + 100, main.getWorld().getScore(), 0.1f,
            "Score should increase by 100 points after the goose is fed."
        );
    }

    @Test
    public void ptTest2() {
        float initialPoints = main.getWorld().getScore();
        GooseAccessGameScreen gs = new GooseAccessGameScreen(main);
        ItemManager im = main.itemManager;
        Player plr = gs.getPlayer();
        Goose goose = gs.getGoose();
        goose.attackMode();
        goose.stealTorch(plr, gs.lighting, im);
        gs.render(0f);
        goose.setPosition(
            plr.getX() + plr.sprite.getWidth()/2 - goose.getWidth()/2,
            plr.getY() + plr.sprite.getHeight()/2 - goose.getHeight()/2
        );
        gs.render(0f);
        assertEquals(initialPoints + 100, main.getWorld().getScore(), 0.1f,
            "Score should increase by 100 points after the player takes back" +
                " the torch off the goose."
        );
    }
}
