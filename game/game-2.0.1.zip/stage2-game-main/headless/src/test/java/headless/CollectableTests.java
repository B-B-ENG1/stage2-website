package headless;

import io.github.team6ENG.EscapeUni.Entities.Collectable;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class CollectableTests extends AbstractMainFakeTest {

    @Test
    public void testInRange() {
        Collectable collectable = new Collectable(0,0);
        float rangeSquared = Collectable.pickupDistanceSquared;
        float offsetX = Collectable.pickupOffsetX;
        float offsetY = Collectable.pickupOffsetY;
        assertTrue(collectable.checkInRange(-offsetX, -offsetY),
            "(0,0) should be in range of (0,0)."
        );
        float targetX = (float)Math.sqrt(rangeSquared)/2 - offsetX;
        float targetY = (float)Math.sqrt(rangeSquared)/2 - offsetY;
        assertTrue(collectable.checkInRange(targetX,targetY),
            "(" + targetX + "," + targetY +
                ") should be in range of (0,0)."
        );

    }

    @Test
    public void hotbarTest() {
        ItemManager itemManager = main.itemManager;
        itemManager.getTorch().collect();
        assertEquals(24f, itemManager.getTorch().img.getWidth(), 0.1f,
            "Item should have size reduced to 24 when added to hotbar.");

    }

}
