package headless.ScreenTests;

import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.InstructionsScreen;
import io.github.team6ENG.EscapeUni.Screens.MainMenuScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class MainMenuScreenTests extends AbstractMainFakeTest {

    @Test
    public void MenuPlayButtonTest() {
        MainMenuScreen screen = new MainMenuScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate playButton = screen.getPlayButton();
        playButton.click(0,0);
        assertEquals(InstructionsScreen.clickColor, playButton.getColor(),
            "Play button should change to the \"click color\" when clicked.");
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        playButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, playButton.getColor(),
            "Play button should change to the \"normal color\" when exited.");
        playButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, playButton.getColor(),
            "Play button should change to the \"click color\" when entered.");
    }

    @Test
    public void MenuExitButtonTest() {
        MainMenuScreen screen = new MainMenuScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate ExitButton = screen.getExitButton();
        ExitButton.click(0,0);
        assertEquals(InstructionsScreen.clickColor, ExitButton.getColor(),
            "Exit button should change to the \"click color\" when clicked.");
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        ExitButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, ExitButton.getColor(),
            "Exit button should change to the \"normal color\" when exited.");
        ExitButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, ExitButton.getColor(),
            "Exit button should change to the \"click color\" when entered.");
    }
}
