package headless.ScreenTests;

import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.SliderDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.Screens.InstructionsScreen;
import io.github.team6ENG.EscapeUni.Screens.MainMenuScreen;
import io.github.team6ENG.EscapeUni.Screens.PauseScreen;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.*;

public class PauseScreenTests extends AbstractMainFakeTest {

    @ParameterizedTest
    @ValueSource(floats = {
        0f,
        0.5f,
        1f
    })
    public void testGameVolumeSliders(float value) {
        GameScreen gameScreen = new GameScreen(main);
        AudioManager audio = new AudioManager();
        PauseScreen screen = new PauseScreen(main, gameScreen, audio);
        SliderDelegate gameSlider = screen.getGameVolumeSlider();
        gameSlider.change(value);
        assertEquals(value, audio.getGameVolume(), 0.01,
            "When the game volume slider moves, the game's" +
                "volume in the audio manager should update");
    }

    @ParameterizedTest
    @ValueSource(floats = {
        0f,
        0.5f,
        1f
    })
    public void testMusicVolumeSliders(float value) {
        GameScreen gameScreen = new GameScreen(main);
        AudioManager audio = new AudioManager();
        PauseScreen screen = new PauseScreen(main, gameScreen, audio);
        SliderDelegate musicSlider = screen.getMusicSlider();
        musicSlider.change(value);
        assertEquals(value, audio.getMusicVolume(), 0.01,
            "When the music volume slider moves, the music's" +
                "volume in the audio manager should update");
    }

    @Test
    public void playButtonTest() {
        GameScreen gameScreen = new GameScreen(main);
        AudioManager audio = new AudioManager();
        PauseScreen screen = new PauseScreen(main, gameScreen, audio);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate playButton = screen.getContinueButton();
        playButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, playButton.getColor(),
            "Play button should change to the \"click color\" when entered.");
        playButton.click(0,0);
        assertEquals(gameScreen, main.getCurrentScreen(), "Test setup failed: " +
            "instructions screen initially not set as the current screen.");

        playButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, playButton.getColor(),
            "Play button should change to the \"click color\" when entered.");
    }

    @Test
    public void mainMenuButtonTest() {
        GameScreen gameScreen = new GameScreen(main);
        AudioManager audio = new AudioManager();
        PauseScreen screen = new PauseScreen(main, gameScreen, audio);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate menuButton = screen.getMainMenuButton();
        menuButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, menuButton.getColor(),
            "Main menu button should change to the \"click color\" when entered.");
        menuButton.click(0,0);
        assertInstanceOf(MainMenuScreen.class, main.getCurrentScreen(), "Test setup failed: game over screen initially not set as the" +
            "current screen.");
        menuButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, menuButton.getColor(),
            "menu button should change to the \"click color\" when entered.");
    }
}
