package headless.ScreenTests;

import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.Screens.InstructionsScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class InstructionScreenTests extends AbstractMainFakeTest {


    @Test
    public void playButtonTest() {
        InstructionsScreen screen = new InstructionsScreen(main);
        main.setScreen(screen);
        screen.show();
        TextButtonDelegate playButton = screen.getPlayButton();
        playButton.click(0,0);
        assertEquals(InstructionsScreen.clickColor, playButton.getColor(),
            "Play button should change to the \"click color\" when clicked.");
        assertInstanceOf(GameScreen.class, main.getCurrentScreen(), "Test setup failed: instructions screen initially not set as the" +
            "current screen.");
        playButton.exit(0,0);
        assertEquals(InstructionsScreen.normalColor, playButton.getColor(),
            "Play button should change to the \"normal color\" when exited.");
        playButton.enter(0,0);
        assertEquals(InstructionsScreen.clickColor, playButton.getColor(),
            "Play button should change to the \"click color\" when entered.");
    }
}
