package headless.ScreenTests;

import com.badlogic.gdx.Input;
import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Managers.BuildingManager;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.Screens.PauseScreen;
import io.github.team6ENG.EscapeUni.Screens.PiazzaScreen;
import io.github.team6ENG.EscapeUni.Screens.UsernameScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertInstanceOf;

public class UsernameTests extends AbstractMainFakeTest {

    @Test
    public void usernameTest() {
        syncPostRunnables();
        UsernameScreen screen = new UsernameScreen(main);
        screen.show();
        screen.getTextBox().setText("testUsername");
        screen.getConfirmButton().click(0,0);
        assertEquals("testUsername", main.username,
            "Game username should be updated by the username screen."
        );
    }
}
