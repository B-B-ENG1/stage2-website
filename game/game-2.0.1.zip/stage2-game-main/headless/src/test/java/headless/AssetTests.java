package headless;

import com.badlogic.gdx.Gdx;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.World;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class AssetTests extends AbstractHeadlessGdxTest {

    @ParameterizedTest
    @ValueSource(strings = {
        AssetManager.gooseFoodAsset,
        AssetManager.torchAsset,
        AssetManager.pizzaAsset,
        AssetManager.phoneAsset,
        AssetManager.maleAsset,
        AssetManager.femaleAsset,
        AssetManager.maleImgAsset,
        AssetManager.femaleImgAsset,
        AssetManager.maleIDCardAsset,
        AssetManager.femaleIDCardAsset,
        AssetManager.gooseAsset,
        AssetManager.receptionistAsset,
        AssetManager.menuScreenFont,
        AssetManager.uiSkin,
        AssetManager.mapAsset,
        AssetManager.busAsset,
        AssetManager.puddleAsset,
        AssetManager.rainTintAsset

    })
    public void testAssets(String assetPath) {
        assertTrue(Gdx.files.internal(assetPath).exists(),
            "Asset " + assetPath + " does not exist.");
    }

    @Test
    public void enumAssetsTest() {
        // Integration test between World and AssetManager:
        // does the world get the correct assets for the male selected characters?
        World world = new World();
        world.setCharacter(AssetManager.CharacterChoice.MALE);
        assertEquals(AssetManager.maleAsset, world.getCharacterAsset(),
            "When the world's character is set to MALE, the character asset "
                + "should match the male asset in AssetManager."
        );
        assertEquals(AssetManager.maleIDCardAsset, world.getIDCardAsset(),
            "When the world's character is set to MALE, the ID card asset "
                + "should match the male asset in AssetManager."
        );
        world.setCharacter(AssetManager.CharacterChoice.FEMALE);
        assertEquals(AssetManager.femaleAsset, world.getCharacterAsset(),
            "When the world's character is set to FEMALE, the character asset "
                + "should match the male asset in AssetManager."
        );
        assertEquals(AssetManager.femaleIDCardAsset, world.getIDCardAsset(),
            "When the world's character is set to FEMALE, the ID card asset "
                + "should match the male asset in AssetManager."
        );
    }
}
