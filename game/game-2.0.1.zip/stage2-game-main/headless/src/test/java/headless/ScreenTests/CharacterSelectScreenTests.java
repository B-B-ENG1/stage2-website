package headless.ScreenTests;

import headless.AbstractMainFakeTest;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageButtonDelegate;
import io.github.team6ENG.EscapeUni.World;
import io.github.team6ENG.EscapeUni.Screens.InstructionsScreen;
import io.github.team6ENG.EscapeUni.Screens.CharacterSelectScreen;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CharacterSelectScreenTests extends AbstractMainFakeTest {

    @Test
    public void character1SelectionTest() {
        syncPostRunnables();
        CharacterSelectScreen screen = new CharacterSelectScreen(main);
        main.setScreen(screen);
        screen.show();
        World world = main.getWorld();
        ImageButtonDelegate char1button = screen.getcharacterButton1();
        char1button.click(0,0);
        assertEquals(AssetManager.femaleAsset, world.getCharacterAsset(),
            "When the character is set to FEMALE, the character asset "
                + "should match the female asset in AssetManager.");
        assertInstanceOf(InstructionsScreen.class, main.getCurrentScreen(),
            "Character selection failed to move to instruction screen.");
    }

    @Test
    public void character2SelectionTest() {
        syncPostRunnables();
        CharacterSelectScreen screen = new CharacterSelectScreen(main);
        main.setScreen(screen);
        screen.show();
        World world = main.getWorld();
        ImageButtonDelegate char2button = screen.getcharacterButton2();
        char2button.click(0,0);
        assertEquals(AssetManager.maleAsset, world.getCharacterAsset(),
            "When the character is set to MALE, the character asset "
                + "should match the male asset in AssetManager.");
        assertInstanceOf(InstructionsScreen.class, main.getCurrentScreen(),
            "Character selection failed to move to instruction screen.");
    }


}
