package headless;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Gdx;
import io.github.team6ENG.EscapeUni.Main;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;

public abstract class AbstractMainFakeTest extends AbstractHeadlessGdxTest {
    protected FakeMain main;

    @BeforeEach
    public void fakeMain() {
        main = new FakeMain();
        main.create();
    }

    @AfterEach
    public void dispose() {
        main.dispose();
    }

    /**
     * When this method is called, runnables told to run just before the next
     * frame is rendered will now run instantly.
     */
    protected void syncPostRunnables() {
        Application mockApp = mock(Application.class);
        Mockito.doAnswer(inv -> {
            Runnable command = inv.getArgument(0);
            command.run();
            return null;
        }).when(mockApp).postRunnable(any(Runnable.class));
        Gdx.app = mockApp;
    }
}
