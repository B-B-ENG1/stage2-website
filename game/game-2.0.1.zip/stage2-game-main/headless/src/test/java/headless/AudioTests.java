package headless;

import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import net.bytebuddy.pool.TypePool;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AudioTests extends AbstractHeadlessGdxTest {

    /**
     * Tests whether the audio manager correctly gives an IllegalArgumentException
     * for invalid inputs into setMusicVolume, that is, inputs not between 0 and 1
     * inclusive.
     * @param manager is the manager to test behaviour with.
     * @param volume is the volume for which there should be an error.
     */
    private void assertMusicVolumeError(AudioManager manager, float volume) {
        try {
            manager.setMusicVolume(volume);
        }catch (IllegalArgumentException e) {
            return;
        }
        fail("Music volume falsely accepted input " + volume + ".");
    }

    /**
     * Tests whether the audio manager correctly gives an IllegalArgumentException
     * for invalid inputs into setGameVolume, that is, inputs not between 0 and 1
     * inclusive.
     * @param manager is the manager to test behaviour with.
     * @param volume is the volume for which there should be an error.
     */
    private void assertGameVolumeError(AudioManager manager, float volume) {
        try {
            manager.setGameVolume(volume);
        }catch (IllegalArgumentException e) {
            return;
        }
        fail(
            "Game volume falsely accepted input " + volume + "."
        );
    }

    @Test
    public void gameVolumeTest1() {
        AudioManager manager = new AudioManager();
        assertGameVolumeError(manager,-1);
        assertGameVolumeError(manager,2);
    }

    @Test
    public void musicVolumeTest1() {
        AudioManager manager = new AudioManager();
        assertMusicVolumeError(manager,-1);
        assertMusicVolumeError(manager,2);
    }

    @Test
    public void gameVolumeTest2() {
        float delta = 0.001f;
        AudioManager manager = new AudioManager();
        manager.setGameVolume(0);
        assertEquals(0,manager.getGameVolume(), delta,
            "Game volume failed to set to 0."
        );
        manager.setGameVolume(1);
        assertEquals(1,manager.getGameVolume(), delta,
            "Game volume failed to set to 1."
        );
        manager.setGameVolume(0.5f);
        assertEquals(0.5f,manager.getGameVolume(), delta,
            "Game volume failed to set to 0.5."
        );
        manager.dispose();
    }

    @Test
    public void musicVolumeTest2() {
        float delta = 0.001f;
        AudioManager manager = new AudioManager();
        manager.setMusicVolume(0);
        assertEquals(0,manager.getMusicVolume(), delta,
            "Music volume failed to set to 0."
        );
        manager.setMusicVolume(1);
        assertEquals(1,manager.getMusicVolume(), delta,
            "Music volume failed to set to 1."
        );
        manager.setMusicVolume(0.5f);
        assertEquals(0.5f,manager.getMusicVolume(), delta,
            "Music volume failed to set to 0.5."
        );
        manager.dispose();
    }

}
