package io.github.team6ENG.EscapeUni.Managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Music;
import com.badlogic.gdx.audio.Sound;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.World;

/**
 * Control and play game sounds
 */
public class AudioManager {

    private final Sound torchClick;
    private final Sound honk;
    private final Sound footSteps;
    private final Music music;
    private final Sound noAccess;
    private final Sound collect;
    private final Sound rain;
    private float gameVolume = .5f;
    private float musicVolume = .5f;

    /**
     * Initialises the audio manager.
     */
    public AudioManager(){

        honk = Gdx.audio.newSound(Gdx.files.internal("soundEffects/honk.mp3"));
        torchClick = Gdx.audio.newSound(Gdx.files.internal("soundEffects/click.mp3"));
        footSteps = Gdx.audio.newSound(Gdx.files.internal("soundEffects/footsteps.mp3"));
        noAccess = Gdx.audio.newSound(Gdx.files.internal("soundEffects/wrong.mp3"));
        collect = Gdx.audio.newSound(Gdx.files.internal("soundEffects/tap.mp3"));
        rain = Gdx.audio.newSound(Gdx.files.internal("soundEffects/rain.mp3"));
        music = Gdx.audio.newMusic(Gdx.files.internal("soundEffects/music.mp3"));
    }


    public void playHonk(){
        honk.play(gameVolume);
    }
    public void playTorch(){
        torchClick.play(gameVolume);
    }
    public void playNoAccess(){
        noAccess.play(gameVolume);
    }
    public void playCollect(){collect.play(gameVolume);}
    public void playRain(){rain.play(gameVolume/12);}
    public void loopFootsteps(){
        footSteps.loop(.2f * gameVolume);
    }
    public void stopFootsteps(){
        footSteps.stop();
    }
    public void stopRain() {rain.stop();}
    public void playMusic(){
        setMusicVolume();
        music.play();
        music.setLooping(true);
    }
    public void setMusicVolume(){
        music.setVolume(0.01f * musicVolume);
    }
    public void stopMusic(){
        music.stop();
    }
    public void pauseMusic(){
        music.pause();
    }


    private void disposeSound(Sound sound) {
        if (sound != null) {
            sound.dispose();
        }
    }

    public void dispose() {
        if (music != null) {
            music.dispose();
        }
        disposeSound(torchClick);
        disposeSound(footSteps);
        disposeSound(noAccess);
        disposeSound(collect);
        disposeSound(honk);
    }

    /**
     * A setter for the game volume.
     * @param volume is the desired volume.
     * @throws IllegalArgumentException if the volume is not between 0 and 1
     *  inclusive.
     */
    public void setGameVolume(float volume) {
        if (volume < 0 || volume > 1) {
            throw new IllegalArgumentException("Volume must be between 0 and 1.");
        }
        gameVolume = volume;
    }

    /**
     * A setter for the music volume.
     * @param volume is the desired volume.
     * @throws IllegalArgumentException if the volume is not between 0 and 1
     *  inclusive.
     */
    public void setMusicVolume(float volume) {
        if (volume < 0 || volume > 1) {
            throw new IllegalArgumentException("Volume must be between 0 and 1.");
        }
        musicVolume = volume;
    }

    /**
     * A getter for {@code gameVolume}
     * @return the current volume of sound effects.
     */
    public float getGameVolume() {
        return gameVolume;
    }

    /**
     * A getter for {@code musicVolume}
     * @return the current volume of music.
     */
    public float getMusicVolume() {
        return musicVolume;
    }

    public boolean isMusicPlaying() {
        return music.isPlaying();
    }
}
