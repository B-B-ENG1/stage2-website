package io.github.team6ENG.EscapeUni.Managers;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Random;

public abstract class AssetManager {
    /**
     * Values corresponding to each sprite the player can take.
     */
    public enum CharacterChoice {
        MALE,
        FEMALE;
        /**
         * Given a particular player choice, returns the corresponding asset.
         * @return the sprite sheet for this choice of character.
         */
        public String getCharacterAsset() {
            if (this == MALE) {
                return maleAsset;
            }else{
                return femaleAsset;
            }
        }

        /**
         * Given a particular player choice, returns the corresponding asset for
         * their ID card.
         * @return the ID card asset for this choice of character.
         */
        public String getIDCardAsset() {
            if (this == MALE) {
                return maleIDCardAsset;
            }else{
                return femaleIDCardAsset;
            }
        }
    }

    public static final String torchAsset = "items/torch.png";
    public static final String pizzaAsset = "items/pizza.png";
    public static final String energyDrinkAsset = "items/energyDrink.png";
    public static final String phoneAsset = "items/phone.png";
    public static final String gogglesAsset = "items/goggles.png";
    public static final String potionAsset = "items/potion.png";
    public static final String gooseFoodAsset = "items/gooseFood.png";

    public static final String menuScreenFont = "fonts/menuScreenFont.fnt";
    public static final String uiSkin = "skins/uiskin.json";

    public static final String mapAsset = "tileMap/map.png";
    public static final String busAsset = "images/bus.png";

    public static final String maleAsset =  "sprites/maleSprite.png";
    public static final String femaleAsset = "sprites/femaleSprite.png";
    public static final String maleImgAsset =  "images/maleSpriteImg.png";
    public static final String femaleImgAsset = "images/femaleSpriteImg.png";
    public static final String maleIDCardAsset = "items/idMale.png";
    public static final String femaleIDCardAsset = "items/idFemale.png";

    public static final String gooseAsset = "sprites/goose.png";
    public static final String receptionistAsset = "sprites/receptionist.png";
    public static final String puddleAsset = "sprites/puddle.png";
    public static final String wormAsset = "sprites/worm.png";

    public static final String[] rainAssets = {"rain/rain1.png",
        "rain/rain2.png",
        "rain/rain3.png",
        "rain/rain4.png"
    };
    public static final String rainTintAsset = "rain/rainTint.png";

}
