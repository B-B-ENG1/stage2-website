package io.github.team6ENG.EscapeUni.Screens;

import java.util.ArrayList;
import java.util.List;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;

import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.World;

/**
 * Screen displayed at the end of the game showing unlocked achievements.
 */
public class AchievementsScreen extends AbstractScreen {

	private StageDelegate stage;
	private final GlyphLayout layout = new GlyphLayout();
	private ButtonDelegate mainMenuButton;
	private TextButtonDelegate backButton;
	private com.badlogic.gdx.InputProcessor previousInputProcessor;

	private List<String> names = new ArrayList<>();
	private List<Boolean> unlocked = new ArrayList<>();
	private final LeaderboardManager leaderboard;
	private java.util.List<LeaderboardManager.ScoreEntry> topScores;
	private static final int TOP_LIMIT = 10;
    /**
     * This is the proportional lower bound on the fast completion achievement.
     * That is, the achievement is given if and only if the game is completed
     * with at least FAST_REMAINING times the maximum time remaining.
     */
    public static final float FAST_REMAINING = 0.5f;

	private static final String TITLE_TEXT = "Achievements";

	public AchievementsScreen(final Main game) {
		super(game);
		this.leaderboard = game.createLeaderboard();
	}

	@Override
	public void show() {
		stage = graphics.createFixedStageDelegate(game.viewport);
		previousInputProcessor = Gdx.input.getInputProcessor();
		stage.setInputProcessor();

		setupAchievements();
		setupUI();
		positionButtons();
	}

	private void setupAchievements() {
		names.clear(); unlocked.clear();

		// completed any event
		int totalFound = world.getFoundNegativeEvents() + world.getFoundPositiveEvents() + world.getFoundHiddenEvents();
		boolean anyEvent = totalFound > 0;

		// finishing fast
		boolean finishingFast = world.getTimer() >= (World.initialTimer * FAST_REMAINING);

		// unlocking every event
		boolean allEvents = world.getFoundNegativeEvents() >= World.totalNegativeEvents
			&& world.getFoundPositiveEvents() >= World.totalPositiveEvents
			&& world.getFoundHiddenEvents() >= World.totalHiddenEvents;

		// being on leaderboard
		try {
			topScores = leaderboard.getTopScores(TOP_LIMIT);
		} catch (Exception e) {
			topScores = new ArrayList<>();
		}
		boolean onLeaderboard = false;
		if (topScores != null) {
			for (LeaderboardManager.ScoreEntry s : topScores) {
				if (s.username != null && s.username.equals(game.username)) {
					onLeaderboard = true;
					break;
				}
			}
		}

		names.add("Completed an event"); unlocked.add(anyEvent);
		names.add("Finishing fast"); unlocked.add(finishingFast);
		names.add("All events in one run"); unlocked.add(allEvents);
		names.add("On the leaderboard"); unlocked.add(onLeaderboard);
	}

	private void setupUI() {
		mainMenuButton = createButton("Main Menu");
		backButton = createButton("Back");
		mainMenuButton.addToStage(stage);
		backButton.addToStage(stage);
		addListeners();
	}

	private void positionButtons() {
		float w = stage.getViewport().getWorldWidth();
		float h = stage.getViewport().getWorldHeight();

		mainMenuButton.setSize(280, 70);
		backButton.setSize(280, 70);
		mainMenuButton.setPosition((w - mainMenuButton.getWidth()) / 2f, 80f);
		backButton.setPosition((w - backButton.getWidth()) / 2f, 80f + (mainMenuButton.getHeight() + 16f));
	}


    /**
     * getters for main menu and back button's delegate, available for testing purposes.
     * @return the character 1 & 2 button delegates associated with the screen.
     */
    public ButtonDelegate getAchievementsMainMenuButton() {
        return mainMenuButton;
    }
    public TextButtonDelegate getAchievementsBackButton() {
        return backButton;
    }


	private void addListeners() {
		Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
		Color clickColor = new Color(0.4f, 1f, 1f, 1f);

		mainMenuButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				mainMenuButton.setColor(clickColor);
				dispose();
				game.resetGame();
			}
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
				mainMenuButton.setColor(clickColor);
			}
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
				mainMenuButton.setColor(normalColor);
			}
		});

		backButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				backButton.setColor(clickColor);
				dispose();
				game.setScreen(new WinScreen(game));
			}
			@Override
			public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
				backButton.setColor(clickColor);
			}
			@Override
			public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
				backButton.setColor(normalColor);
			}
		});
	}

    /**
     * Determines whether the achievement with the given name has been obtained.
     * If this achievement does not exist then this defaults to false.
     * @param name is the name of the achievement to be checked.
     * @return true if the achievement with the given name exists and has been
     *  obtained, and false otherwise.
     */
    public boolean achievementFound(String name) {
        int index = names.indexOf(name);
        if (index < 0 || index > unlocked.size()) return false;
        return unlocked.get(index);
    }

	@Override
	public void render(float delta) {
        super.render(delta);
		ScreenUtils.clear(Color.BLACK);

		if (stage != null) stage.act(delta);

		if (stage != null) {
			graphics.updateBatchProjectionMatrix(stage.getCameraCombinedProjection());
		} else {
			graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
		}

		graphics.beginBatch();
		float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
		float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();

		if (graphics.menuFont != null) {
			graphics.menuFont.setColor(Color.WHITE);
			layout.setText(graphics.menuFont, TITLE_TEXT);
			graphics.drawText(graphics.menuFont, TITLE_TEXT, (w - layout.width) / 2f, h * 0.9f);

			float prevScale = graphics.gameFont.getData().scaleX;
			graphics.gameFont.getData().setScale(0.45f);
			graphics.gameFont.setColor(Color.WHITE);

			float y = h * 0.75f;
			for (int i = 0; i < names.size(); i++) {
				String mark = unlocked.get(i) ? "[X] " : "[ ] ";
				Color c = unlocked.get(i) ? Color.GOLD : Color.LIGHT_GRAY;
				graphics.gameFont.setColor(c);
				String line = mark + names.get(i);
				layout.setText(graphics.gameFont, line);
				graphics.drawText(graphics.gameFont, line, (w - layout.width) / 2f, y);
				y -= 26f;
			}

			graphics.gameFont.getData().setScale(prevScale);
			graphics.gameFont.setColor(Color.WHITE);
		}

		graphics.endBatch();

		if (stage != null) stage.draw();

		if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
			Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
		}
	}

	@Override
	public void resize(int width, int height) {
		if (stage != null) stage.getViewport().update(width, height, true);
		positionButtons();
	}

	@Override
	public void pause() { }

	@Override
	public void resume() { }

	@Override
	public void hide() {
		if (stage != null && stage.isInputProcessor()) {
			Gdx.input.setInputProcessor(null);
		}

		if (previousInputProcessor != null) {
			Gdx.input.setInputProcessor(previousInputProcessor);
			previousInputProcessor = null;
		}
	}

	@Override
	public void dispose() {
		if (stage != null) {
			stage.dispose();
			stage = null;
		}
	}

}
