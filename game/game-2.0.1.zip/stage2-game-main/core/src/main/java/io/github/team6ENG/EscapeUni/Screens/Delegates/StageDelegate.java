package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

/**
 * Contains a Stage object, with greater capacity for faking.
 */
public class StageDelegate {

    private Stage stage;

    protected StageDelegate() {}

    public StageDelegate(FitViewport viewport, SpriteBatch batch) {
        stage = new Stage(viewport, batch);
    }

    public StageDelegate(FitViewport viewport) {
        stage = new Stage(viewport);
    }

    public void addActor(Actor actor) {
        stage.addActor(actor);
    }

    public void setInputProcessor() {
        Gdx.input.setInputProcessor(stage);
    }

    public boolean isInputProcessor() {
        return stage == Gdx.input.getInputProcessor();
    }

    public void act() {
        stage.act();
    }

    public void act(float delta) {
        stage.act(delta);
    }

    public void draw() {
        stage.draw();
    }

    public Viewport getViewport() {
        return stage.getViewport();
    }

    public Matrix4 getCameraCombinedProjection() {
        return stage.getCamera().combined;
    }

    public void dispose() {
        stage.dispose();
    }
}
