package io.github.team6ENG.EscapeUni.Screens;

import java.util.Random;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.scenes.scene2d.utils.ScissorStack;

import io.github.team6ENG.EscapeUni.Entities.*;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.BuildingManager;
import io.github.team6ENG.EscapeUni.Managers.EnergyDrinkManager;
import io.github.team6ENG.EscapeUni.Managers.LightingManager;
import io.github.team6ENG.EscapeUni.Managers.PondManager;
import io.github.team6ENG.EscapeUni.Managers.PuddleManager;
import io.github.team6ENG.EscapeUni.Managers.RainManager;
import io.github.team6ENG.EscapeUni.Managers.WormManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.RendererDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.World;

/**
 * GameScreen - main gameplay screen
 *
 */
public class GameScreen extends AbstractScreen {

    public static int wallLayer = 0;
    private Player player;
    private BuildingManager buildingManager;
    private PondManager pondManager;
    public AudioManager audioManager;
    private PuddleManager puddleManager;
    protected EnergyDrinkManager energyDrinkManager;
    private WormManager wormManager;
    private RainManager rain;


    private OrthographicCamera camera;
    private TiledMapTileLayer collisionLayer;
    public LightingManager lighting;

    private boolean isPaused = false;
    private boolean isEPressed = false;
    RendererDelegate mapRenderer;
    private TiledMap map;
    private ImageDelegate mapImg;

    protected Goose goose;
    float stateTime;

    private Rectangle stealTorchTrigger;
    public boolean hasGoggles = false;
    private boolean isTorchOn = false;
    private boolean areGogglesOn = false;
    private boolean isCamOnGoose = false;
    protected boolean gameoverTrigger = false;

    /**
     * There should be a 1/{@code probabilityOfHonk} chance of a honk.
     */
    private final float probabilityOfHonk = 1000;

    public int numOfInventoryItems = 0;


    private Bus bus;
    public float playerSpeedModifier = 1;

    public static final int defaultTileDimensions = 8;

    /**
     * Initialise the game elements
     * @param game - Instance of Main
     */
    public GameScreen(final Main game) {
        super(game);
        tileDimensions = defaultTileDimensions;
        goose = new Goose(graphics, world);
        initialiseMap();
        audioManager = game.audioManager;
        audioManager.playMusic();
        initialisePlayer(940,1215);
        initialiseCamera();
        initialiseLighting();
        initialiseGoose(940,1000);
        initialisePuddles(30, 3);
        initialiseWorms(10, 4);
        initialiseEnergyDrinks(10, 3);
        bus = new Bus(1100, 1545, player, graphics, audioManager, items);
        rain = new RainManager(world, graphics, audioManager, puddleManager);
        buildingManager = new BuildingManager(game, this, player, audioManager);
        pondManager = new PondManager(player, lighting, graphics, world);
        pondManager.initializePondGeese(collisionLayer, tileDimensions);
        pondManager.initializeFeatherLighting();
        stateTime = 0f;
    }

    /**
     * Gets the bus from the screen.
     * @return the bus object used on the game screen.
     */
    public Bus getBus() {
        return bus;
    }



    /**
     * Load map and collision layer
    */
   private void initialiseMap() {
       TextureDelegate mapTex = graphics.createTextureDelegate(AssetManager.mapAsset);
       mapImg = mapTex.createImage();
       map = new TmxMapLoader().load("tileMap/map.tmx");
       mapRenderer = graphics.createRendererDelegate(map, 1);
       collisionLayer = (TiledMapTileLayer)map.getLayers().get(wallLayer);
    }

    private void initialisePuddles(int puddleNumber, int blockSize) {
        puddleManager = new PuddleManager(graphics, 3);
        world.addPuddleManager(puddleManager);
        puddleManager.addPuddles(puddleNumber);
    }

    private void initialiseWorms(int wormNumber, int blockSize) {
        wormManager = new WormManager(graphics, blockSize);
        world.addWormManager(wormManager);
        wormManager.addWorms(wormNumber);
    }

    protected void initialiseEnergyDrinks(int number, int blockSize) {
        energyDrinkManager = new EnergyDrinkManager(world, graphics, audioManager, blockSize);
        energyDrinkManager.addEnergyDrinks(number, items);
    }

    /**
     * Initialise player and set its position
     */
    private void initialisePlayer(int x, int y) {
        player = new Player(graphics, world, audioManager, items);
        player.loadSprite(collisionLayer, tileDimensions);
        player.sprite.setPosition(x, y);
        player.speed = 1;
    }

    /**
     * Initialise camera and set to position of player
     */
    private void initialiseCamera() {
        camera = new OrthographicCamera(400,225);
        camera.position.set(
            player.sprite.getX() + player.sprite.getWidth() / 2,
            player.sprite.getY() + player.sprite.getHeight() / 2,
            0);
        camera.update();
    }

    /**
     * Initialise goose and set its position
     */
    private void initialiseGoose(int x, int y){

        goose.loadSprite(collisionLayer, tileDimensions);
        goose.x = x;
        goose.y = y;

        stealTorchTrigger = new com.badlogic.gdx.math.Rectangle(510, 560, 50, 50);

    }


    /**
    * Add and hide light circles for player and goose
     */
    private void initialiseLighting() {
        lighting = game.lightingManager;

        lighting.addLightSource("playerTorch",
            player.sprite.getX() + (player.sprite.getWidth() / 2),
            player.sprite.getY() + (player.sprite.getHeight() / 2),
            new Color(0, 0, 0, 0),
            50);
        lighting.addLightSource("playerNoTorch",
            player.sprite.getX() + (player.sprite.getWidth() / 2),
            player.sprite.getY() + (player.sprite.getHeight() / 2),
            new Color(0, 0, 0, 0.4f),
            12);
        lighting.addLightSource("gooseTorch",goose.x+ (goose.getWidth() / 2), goose.y + (goose.getHeight() / 2), new Color(1,0.2f,0.1f,0.4f), 30);
        lighting.addLightSource("gooseNoTorch",goose.x+ (goose.getWidth() / 2), goose.y + (goose.getHeight() / 2), new Color(0, 0, 0, 0.4f), 10);
        lighting.isVisible("playerTorch", false);
        lighting.isVisible("playerNoTorch", false);
        lighting.isVisible("gooseTorch", false);
        lighting.isVisible("gooseNoTorch", false);
    }

    /**
     * Call every frame to update game state
     * @param delta - Time since last frame
     */
    protected void update(float delta) {
        if (bus.update(delta)) {
            Gdx.app.postRunnable(() -> game.setScreen(
                new WinScreen(game)
            ));
        };

        if (items.getPotion().playerHas) {
            player.ignoreCollisions = true;
        }

        if (items.getGoggles().playerHas) {
            hasGoggles = true;
        }

        lighting.updateLightSource("playerTorch", player.sprite.getX() + (player.sprite.getWidth() / 2), player.sprite.getY() + (player.sprite.getHeight() / 2));

        if(!isPaused && !bus.isLeaving()) {
            updateCamera();
            world.decrementTimer(delta);
            world.incrementScore(-delta);
            handleInput(delta);
            // freeze player while goose eats worm
            if (energyDrinkManager.isDrinkEffective()) {
                playerSpeedModifier = EnergyDrink.speedModifier;
            } else {
                playerSpeedModifier = 1f;
            }
            float effectiveSpeedModifier = goose.isPickingWorm() ? 0 : playerSpeedModifier;
            // Handle active energy drink speed buff
            player.handleInput(delta, effectiveSpeedModifier);
            float mapWidth = collisionLayer.getWidth() * collisionLayer.getTileWidth();
            float mapHeight = collisionLayer.getHeight() * collisionLayer.getTileHeight();
            // Update light positions
            lighting.updateLightSource("playerTorch", player.sprite.getX() + (player.sprite.getWidth() / 2), player.sprite.getY() + (player.sprite.getHeight() / 2));
            lighting.updateLightSource("playerNoTorch", player.sprite.getX() + (player.sprite.getWidth() / 2), player.sprite.getY() + (player.sprite.getHeight() / 2));
            lighting.updateLightSource("gooseNoTorch", goose.x+ (goose.getWidth() / 2), goose.y + (goose.getHeight() / 2));

            if (goose.hasStolenTorch()){
                lighting.updateLightSource("gooseTorch", goose.x+ (goose.getWidth() / 2), goose.y + (goose.getHeight() / 2));

            }

            player.updatePlayer(stateTime);
            if(player.isMoving() && !player.isFootsteps){
                audioManager.loopFootsteps();
                player.isFootsteps = true;
            }
            else if (!player.isMoving()){
                player.isFootsteps = false;
                audioManager.stopFootsteps();
            }

            goose.target(delta, stateTime, wormManager, player);

            // If there are baby geese, they follow the goose directly in front of them
            Goose trail = goose;
            float stateOffset = 0.075f;
            while (trail.baby != null) {
                trail.baby.moveGoose(stateTime - stateOffset,
                    trail.x,
                    trail.y,
                    player.isMoving(), trail.isSleeping);
                stateOffset += 0.075f;
                trail = trail.baby;
            }

            // Check if player can pick up items and update items.
            for (Collectable item : items.getItems()){
                item.update(delta);
                if (!item.playerHas && item.isVisible && item.originScreen.equals("GameScreen")){
                    if (item.checkInRange(player.sprite.getX(), player.sprite.getY()) && isEPressed){
                        if (!item.toString().equals("energy drink")) {
                            numOfInventoryItems += 1;
                        }
                        item.collect();
                        isEPressed = false;
                    }
                }
            }

            // Feed goose if player has food and in range
            float dx = (goose.x + (goose.getWidth())/2) - (player.sprite.getX()+ (player.sprite.getWidth()/2));
            float dy = (goose.y + (goose.getHeight()/2)) - (player.sprite.getY() + (player.sprite.getHeight()/2));
            if (World.withinDistance(dx, dy, 900)
                    && player.has(items.getGooseFood())
                    && isEPressed) {
                items.getGooseFood().playSound();
                //items.removeGooseFood();
                goose.loadBabyGoose(0);
                world.incrementScore(100);
                items.getGooseFood().playerHas = false;
                items.getGooseFood().isVisible = false;
                world.hiddenEventFound();
            }
            isEPressed = false;


            if(player.has(items.getTorch()) || goose.hasStolenTorch()){
                Rectangle playerRect = new Rectangle(
                    player.sprite.getX(),
                    player.sprite.getY(),
                    player.sprite.getWidth(),
                    player.sprite.getHeight()
                );

                if(playerRect.overlaps(stealTorchTrigger) && !goose.attackModeActivated){
                    goose.attackMode();
                    audioManager.playHonk();

                }
                else if (goose.attackModeActivated){
                    Rectangle gooseRect = new Rectangle( goose.x,goose.y,goose.getWidth(),goose.getHeight());
                    if (playerRect.overlaps(gooseRect) && !goose.hasStolenTorch()){
                        goose.stealTorch(player, lighting, items);
                        isCamOnGoose = true;
                        audioManager.playHonk();
                    }
                    else if (!playerRect.overlaps(stealTorchTrigger) &&playerRect.overlaps(gooseRect)
                             && goose.hasStolenTorch()) {

                        isCamOnGoose = false;
                        lighting.isVisible("gooseTorch", false);
                        lighting.isVisible("gooseNoTorch", true);
                        lighting.isVisible("playerTorch", true);
                        lighting.isVisible("playerNoTorch", false);


                        if (!goose.isSleeping && !player.has(items.getTorch())){
                            world.incrementScore(100);
                        }

                        items.getTorch().playerHas = true;
                    }
                }

            }

            // Keep sprites in map boundary
            player.sprite.setX(Math.max(0, Math.min(player.sprite.getX(), mapWidth - player.sprite.getWidth())));
            player.sprite.setY(Math.max(0, Math.min(player.sprite.getY(), mapHeight - player.sprite.getHeight())));
            goose.x = Math.max(0, Math.min(goose.x, mapWidth - goose.getWidth()));
            goose.y = Math.max(0, Math.min(goose.y, mapHeight - goose.getHeight()));

        } // End isPaused

        // If time up
        if (!gameoverTrigger && world.getTimer() <= 0) {
           gameOver();
           return;
        }

        if (Gdx.input.isKeyJustPressed(Input.Keys.P)) {
            game.elapsedTimeChecker.startTimer("Game to pause menu");
            audioManager.pauseMusic();
            pauseMenu();
        }

        buildingManager.update(delta);
        pondManager.update(delta, stateTime);

        playAudio();

    }

    /**
     * Switches to the pause menu.
     */
    public PauseScreen pauseMenu() {
        audioManager.stopFootsteps();
        PauseScreen screen = new PauseScreen(game, GameScreen.this, audioManager);
        game.setScreen(screen);
        return screen;
    }

    /**
     * Make camera follow player
     */
    private void updateCamera() {

        float mapWidth = collisionLayer.getWidth() * collisionLayer.getTileWidth();
        float mapHeight = collisionLayer.getHeight() * collisionLayer.getTileHeight();

        float playerCenterX = player.sprite.getX() + player.sprite.getWidth() / 2f;
        float playerCenterY = player.sprite.getY() + player.sprite.getHeight() / 2f;

        float gooseCenterX = goose.x + goose.getWidth() / 2f;
        float gooseCenterY = goose.y + goose.getHeight() / 2f;

        float finalX = (playerCenterX + gooseCenterX) / 2f;
        float finalY = (playerCenterY + gooseCenterY) / 2f;

        // camera follows player
        float slope = 0.1f;

        if(isCamOnGoose && Math.abs(finalX-playerCenterX)<100 && Math.abs(finalY-playerCenterY)<100){

            camera.position.x += (finalX - camera.position.x) * slope;
            camera.position.y += (finalY - camera.position.y) * slope;
        }
        else {
            camera.position.x += (playerCenterX - camera.position.x) * slope;
            camera.position.y += (playerCenterY - camera.position.y) * slope;
        }


        float halfWidth = camera.viewportWidth / 2f;
        float halfHeight = camera.viewportHeight / 2f;

        if (mapWidth > camera.viewportWidth) {
            camera.position.x = Math.max(halfWidth, Math.min(camera.position.x, mapWidth - halfWidth));
        } else {

            camera.position.x = mapWidth / 2f;
        }

        if (mapHeight > camera.viewportHeight) {
            camera.position.y = Math.max(halfHeight, Math.min(camera.position.y, mapHeight - halfHeight));
        } else {
            camera.position.y = mapHeight / 2f;
        }

        bus.leavingCamera(camera);
        camera.update();
}


    @Override
    public void show() {
        if (game.elapsedTimeChecker.timerExists("Main menu to game")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Main menu to game");
            System.out.println("Time taken to get from main menu to game: " + elapsed + " ms");
        }
    }

    /**
     * Calls every frame to draw game screen
     *
     * @param delta The time in seconds since the last render.
     */
    @Override
    public void render(float delta) {
        super.render(delta);
        update(delta);
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        if (mapRenderer != null) {
            game.viewport.apply();
            mapRenderer.setView(camera);
            mapRenderer.render();
            Gdx.gl.glFlush();
        }
        buildingManager.renderBuildingMap(camera);

        game.graphicsManager.updateBatchProjectionMatrix(camera.combined);
        game.graphicsManager.beginBatch();
        graphics.drawImage(mapImg, 1);
        for (Puddle puddle : puddleManager.getPuddles()) {
            graphics.drawImage(puddle.getImage(), 1);
        }
        for (Worm worm : wormManager.getWorms()) {
            if (!worm.isCollected()) {
                graphics.drawImage(worm.getImage(), 1);
            }
        }

        stateTime += delta;
        game.graphicsManager.drawTextureRegion(goose.currentGooseFrame,
            goose.x, goose.y);
        //Draw yellow baby geese
        game.graphicsManager.setBatchColour(Color.YELLOW);
        Goose trail = goose;
        while (trail.baby != null){
            trail = trail.baby;
            if (trail.currentGooseFrame != null) {
                graphics.drawTextureRegion(trail.currentGooseFrame, trail.x, trail.y,
                    16f, 16f);

            }
        }

        // draws pond geese
        game.graphicsManager.setBatchColour(Color.WHITE);
        Goose[] pondGeese = pondManager.getPondGeese();
        for (Goose pondGoose : pondGeese) {
            if (pondGoose != null && pondGoose.currentGooseFrame != null) {
                graphics.drawTextureRegion(pondGoose.currentGooseFrame, pondGoose.x, pondGoose.y);
            }
        }
        game.graphicsManager.setBatchColour(Color.WHITE);

        // Draw uncollected items in game
        for (Collectable item : items.getItems()){
            if(item.isVisible && !item.playerHas && item.originScreen.equals("GameScreen")){
                graphics.drawImage(item.img, 1);
            }
        }
        if (!player.sprite.nullTexture()) {
            // This adds the ghost effect
            if (items.getPotion().playerHas) {
                player.sprite.setColor(1f, 1f, 1f, 0.5f);
            }
            if (player.isInWater()) {
                Rectangle scissors = new Rectangle();
                Rectangle clipBounds = new Rectangle(player.sprite.getX(), player.sprite.getY() + (player.sprite.getHeight() * 0.4f), player.sprite.getWidth(), player.sprite.getHeight());
                ScissorStack.calculateScissors(camera, graphics.getTransformMatrix(), clipBounds, scissors);
                if (ScissorStack.pushScissors(scissors)) {
                    graphics.drawSprite(player.sprite);
                    graphics.flush();
                    ScissorStack.popScissors();
                }
            }
            else{
                graphics.drawSprite(player.sprite);
            }
            // Reset color after drawing so other stuff in the same sprite batch doesn't be a ghost
            player.sprite.setColor(1f, 1f, 1f, 1f);
        }
        if (player.has(items.getTorch())){
            player.torch.draw();
        }

        bus.draw();
        int mapWidth = collisionLayer.getWidth() * collisionLayer.getTileWidth();
        int mapHeight = collisionLayer.getHeight() * collisionLayer.getTileHeight();
        if (world.isDark()) {
            graphics.drawTexture(lighting.render(camera, mapWidth, mapHeight), 0, 0);
        }
        // Feathers always render on top  of the night effect + the steal torch effect
        TextureDelegate featherTexture = lighting.renderFeathersOnly(camera, mapWidth, mapHeight);
        if (featherTexture != null) {
            graphics.drawTexture(featherTexture, 0, 0);
        }
        rain.update(delta);
        game.graphicsManager.endBatch();


        renderUI();

        if (game.elapsedTimeChecker.timerExists("Exit building")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Exit building");
            System.out.println("Time taken to exit building and load map: " + elapsed + " ms");
        }
        if (game.elapsedTimeChecker.timerExists("First load map")) {
            float elapsed = game.elapsedTimeChecker.endTimer("First load map");
            System.out.println("Time taken to first load map: " + elapsed + " ms");
        }
    }
    Random random = new Random();
    private void playAudio(){
        int doHonk = random.nextInt((int) probabilityOfHonk);
        if (doHonk == 0 && !isPaused && !bus.isLeaving()) {
            audioManager.playHonk();
        }
    }

    /**
     * Check for keyboard input
     * @param delta time in seconds since last frame
     */
    private void handleInput(float delta) {
        if (Gdx.input.isKeyJustPressed(Input.Keys.E)) {
            isEPressed = true;
        }

        // Toggle the torch with click
        if(Gdx.input.isButtonJustPressed(Input.Buttons.LEFT) && player.has(items.getTorch())){
            isTorchOn = !isTorchOn;
            lighting.isVisible("playerTorch", isTorchOn);
            // Show ambient light when torch is off
            lighting.isVisible("playerNoTorch", !isTorchOn);
            audioManager.playTorch();
        }

        if(Gdx.input.isButtonJustPressed(Input.Buttons.RIGHT) && hasGoggles && world.isDark()){
            areGogglesOn = !areGogglesOn;
            lighting.setGogglesOn(areGogglesOn);
            audioManager.playTorch();
        }
    }

    /*
     * Draw UI on screen
     */
    private void renderUI() {
        if (bus.isLeaving()) return;

        BitmapFont smallFont = graphics.gameFont;
        BitmapFont bigFont = graphics.menuFont;
        float worldHeight = game.viewport.getWorldHeight();
        float worldWidth = game.viewport.getWorldWidth();
        graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        game.graphicsManager.beginBatch();

        // Draw collected items in inventory bar
        // Display instructions if an item can be used or collected
        float itemXPos = (worldWidth - ((numOfInventoryItems) * 32))/2;
        String instructions= "";
        for (Collectable item : items.getItems()) {
            if (item.playerHas){
                item.img.setPosition(itemXPos, worldHeight * 0.8f);
                graphics.drawImage(item.img, 1);
                itemXPos += 32;
                instructions = getInstructions(item.toString());

            }
            else if (item.originScreen.equals("GameScreen") && item.isVisible && item.checkInRange(player.sprite.getX(), player.sprite.getY())) {
                instructions = "Press 'e' to collect " + item.toString();

            }
        }
        //Draw instructions
        GlyphLayout layout = new GlyphLayout(graphics.menuFont, instructions);
        float textX = (worldWidth - layout.width) / 2;
        if (world.isDark()){
            graphics.drawText(bigFont, instructions,Color.WHITE, textX, worldHeight* 0.75f);
        }else {
            graphics.drawText(bigFont, instructions, Color.BLACK, textX, worldHeight * 0.75f);
        }
        drawEventTracker(smallFont);
        drawTimerAndScore(bigFont);

        if (goose.hasStolenTorch() && !player.has(items.getTorch())){
            layout = new GlyphLayout(graphics.menuFont, "THE GOOSE STOLE YOUR TORCH\nCATCH IT QUICK!!!");
            graphics.drawText(bigFont, "THE GOOSE STOLE YOUR TORCH\nCATCH IT QUICK!!!", Color.RED, (worldWidth -layout.width)/2, worldHeight-80f);
        }
        // Game instructions
        if (player.has(items.getTorch())) {
            String instruction = "Left click to for torch";
            if (hasGoggles && world.isDark()) {
                instruction += ", right click for goggles";
            }
            graphics.drawText(bigFont, instruction, Color.ORANGE, 20, 80);
        }
        graphics.drawText(bigFont, "Press 'p' to pause", Color.WHITE, 20, 55);
        graphics.drawText(bigFont, "Use Arrow Keys or WASD to move", Color.WHITE, 20, 30);

        if(isPaused) {
            game.graphicsManager.drawText(smallFont, "PAUSED",
                (float) worldWidth / 2, worldHeight - 100);
        }

        buildingManager.renderUI(smallFont, bigFont, worldWidth, worldHeight);
        game.graphicsManager.endBatch();

    }

    /**
     * Checks if inventory item can be used
     * @param key item being checked
     * @return String of instructions to display
     */
    private String getInstructions(String key) {
        if (key.equals("goose food")) {

            float dx = (goose.x + (goose.getWidth())/2) - (player.sprite.getX()+ (player.sprite.getWidth()/2));
            float dy = (goose.y + (goose.getHeight()/2)) - (player.sprite.getY() + (player.sprite.getHeight()/2));

            if (World.withinDistance(dx, dy, 900)) {
                return "Press 'e' to feed seeds to goose";
            }
        }
        return "";
    }

    public void gameOver(){
        gameoverTrigger = true;
        audioManager.stopMusic();
        audioManager.stopFootsteps();
        Gdx.app.postRunnable(() -> game.setScreen(
            new GameOverScreen(game, "Sorry you missed the bus, better luck next time")
        ));
    }

    /**
     * Getter for the puddle manager of this game screen.
     * @return the puddle manager.
     */
    public PuddleManager getPuddleManager() {
        return puddleManager;
    }

    /**
     * Getter for the player associated with this game.
     * @return the player object.
     */
    public Player getPlayer() {
        return player;
    }

    @Override
    public void resize(int width, int height) {
        game.viewport.update(width, height);
    }

    @Override
    public void pause() {
    }

    @Override
    public void resume() {

        isPaused = false;
    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        // release texture memory
        player.sprite.dispose();

        if (goose != null) {
            goose.currentGooseFrame.dispose();
        }

        if (map != null) {
            map.dispose();
        }
        if (lighting != null) {
            lighting.dispose();
        }

        if (mapRenderer != null) {
            mapRenderer.dispose();
        }

        if (buildingManager != null) {
            buildingManager.dispose();
        }

        bus.dispose();

    }
}
