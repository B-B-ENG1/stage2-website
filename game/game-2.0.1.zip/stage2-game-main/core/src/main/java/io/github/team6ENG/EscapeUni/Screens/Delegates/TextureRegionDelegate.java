package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

public class TextureRegionDelegate {
    protected TextureRegion texture;

    public TextureRegionDelegate() {}

    public TextureRegionDelegate(TextureRegion texture) {
        this.texture = texture;
    }

    public void draw(SpriteBatch batch, float x, float y) {
        batch.draw(texture, x, y);
    }

    public void draw(SpriteBatch batch, float x, float y,
                     float width, float height) {
        batch.draw(texture, x, y, width, height);
    }

    public float getRegionWidth() {
        return texture.getRegionWidth();
    }

    public float getRegionHeight() {
        return texture.getRegionHeight();
    }

    public SpriteDelegate createSpriteDelegate() {
        return new SpriteDelegate(new Sprite(texture));
    }

    public void setSpriteRegion(Sprite sprite) {
        sprite.setRegion(texture);
    }

    public void dispose() {
        texture.getTexture().dispose();
    }
}
