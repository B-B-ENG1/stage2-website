package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.glutils.FrameBuffer;

public class FrameBufferDelegate {

    private FrameBuffer frameBuffer;

    public FrameBufferDelegate() {}

    public FrameBufferDelegate(FrameBuffer frameBuffer) {
        this.frameBuffer = frameBuffer;
    }

    public void begin() {
        frameBuffer.begin();
    }

    public void end() {
        frameBuffer.end();
    }

}
