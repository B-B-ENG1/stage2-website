package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class TextureDelegate {

    private Texture texture;

    public TextureDelegate() {}

    public TextureDelegate(Texture texture) {
        this.texture = texture;
    }

    public void draw(SpriteBatch batch, float x, float y) {
        batch.draw(texture, x, y);
    }

    public void draw(SpriteBatch batch, float x, float y,
                     float width, float height) {
        batch.draw(texture, x, y, width, height);
    }

    public void dispose() {
        texture.dispose();
    }

    public void draw(Pixmap pixmap, int x, int y) {
        texture.draw(pixmap, x, y);
    }

    public float getWidth() {
        return texture.getWidth();
    }

    public float getHeight() {
        return texture.getHeight();
    }

    public TextureRegionDelegate[][] split(int tileWidth, int tileHeight) {
        TextureRegion[][] mySplit = TextureRegion.split(texture, tileWidth, tileHeight);
        TextureRegionDelegate[][] delegates =
            new TextureRegionDelegate[mySplit.length][mySplit[0].length];
        for (int i = 0; i < mySplit.length; i++) {
            for (int j = 0; j < mySplit[0].length; j++) {
                delegates[i][j] = new TextureRegionDelegate(mySplit[i][j]);
            }
        }
        return delegates;

    }

    public ImageDelegate createImage() {
        return new ImageDelegate(new Image(texture));
    }

    public TextureRegionDrawableDelegate createDrawable() {
        return new TextureRegionDrawableDelegate(
            new TextureRegionDrawable(texture));
    }

}
