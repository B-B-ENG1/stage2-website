package io.github.team6ENG.EscapeUni.Entities;

import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;

public class Puddle {

    public final float x,y;
    public final GraphicsManager graphics;
    private TextureDelegate tex;
    private ImageDelegate image;
    private float originalWidth;
    private float originalHeight;

    public Puddle(GraphicsManager graphicsManager, float posX, float posY) {
        x = posX;
        y = posY;
        graphics = graphicsManager;
        tex = graphics.createTextureDelegate(AssetManager.puddleAsset);
        image = tex.createImage();

        // This fixes the collisions being off cause of scaling
        originalWidth = image.getWidth();
        originalHeight = image.getHeight();
        image.setScale(1.4f);
        image.setPosition(x, y);
    }

    public ImageDelegate getImage() {
        return image;
    }

    /**
     * Checks whether the given position on the map collides with this puddle, that is,
     * whether it lies within the hitbox of this puddle.
     * @param colX is the x position of the colliding object.
     * @param colY is the y position of the colliding object.
     * @return true if there is a collision and false otherwise.
     */
    public boolean checkCollision(float colX, float colY) {
        // Use original dimensions scaled by 1.4 so the collsion is percise
        float scaledWidth = originalWidth * 1.4f;
        float scaledHeight = originalHeight * 1.4f;
        float right = x + scaledWidth;
        float bottom = y + scaledHeight;
        return colX >= x && colX <= right &&
               colY >= y && colY <= bottom;
    }

}
