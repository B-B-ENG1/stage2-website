package io.github.team6ENG.EscapeUni.Entities;

import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.World;

public class EnergyDrink extends Collectable {

    private float timer = 0f;
    public static final float speedModifier = 2f;
    public static final float duration = 10f;
    private final World world;

    public EnergyDrink(World world, float posX, float posY, GraphicsManager graphics, AudioManager audio) {
        super("energy drink", graphics, posX, posY, 0.03f, true,
            AssetManager.energyDrinkAsset, "GameScreen", audio);
        this.world = world;
    }

    /**
     * Determines whether the drink is in effect, that is, if the timer for the
     * drink is positive.
     * @return true if the drink is in effect and false otherwise,
     */
    public boolean isEffective() {
        return timer > 0;
    }

    @Override
    public void update(float delta) {
        timer = Math.max(0, timer - delta);
    }

    @Override
    public void collect() {
        playSound();
        isVisible = false;
        timer = duration;
        world.drinkEvent();
    }
}
