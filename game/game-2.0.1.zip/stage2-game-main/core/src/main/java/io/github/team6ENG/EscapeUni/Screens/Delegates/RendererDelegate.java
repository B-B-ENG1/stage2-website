package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;

public class RendererDelegate {
    private OrthogonalTiledMapRenderer mapRenderer;

    public RendererDelegate(OrthogonalTiledMapRenderer mapRenderer) {
        this.mapRenderer = mapRenderer;
    }

    public RendererDelegate() {}

    public void render() {
        mapRenderer.render();
    }

    public void setView(OrthographicCamera camera) {
        mapRenderer.setView(camera);
    }

    public void dispose() {
        mapRenderer.dispose();
    }

}
