package io.github.team6ENG.EscapeUni.Entities;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.World;

/**
 * Represents collectable game items.
 */
public class Collectable {
    public boolean playerHas = false;
    private GraphicsManager graphics;
    private TextureDelegate tex;
    public ImageDelegate img;
    public float x, y;
    public boolean isVisible = false;
    public String originScreen = "";
    private AudioManager audioManager;
    public static final float pickupDistanceSquared = 900f;
    public static final float pickupOffsetX = 8;
    public static final float pickupOffsetY = 16;
    private boolean isTesting;
    private String name;

    /**
     * A constructor for when graphics and audio is present, that is, when
     * not in testing mode.
     * @param posX is the x-position of the collectable.
     * @param posY is the y-position of the collectable.
     * @param scale is the scale of the image to be used.
     * @param isVisible is true if and only if the collectable is to be visible.
     * @param texturePath is the string from which the texture of the collectable
     *                    may be constructed.
     * @param originScreen is the screen on which the collectable should be put.
     * @param audioManager is the audio manager through which the collectable
     *                     will make sound.
     */
    public Collectable(String name, GraphicsManager graphics, float posX, float posY, float scale,
                       boolean isVisible, String texturePath, String originScreen,
                       AudioManager audioManager) {
        this(posX, posY);
        this.name = name;
        this.graphics = graphics;
        tex = graphics.createTextureDelegate(texturePath);
        img = tex.createImage();
        img.setPosition(x, y);
        img.setScale(scale);
        this.isVisible = isVisible;
        this.originScreen = originScreen;
        this.audioManager = audioManager;
    }

    /**
     * A constructor for the collectable regardless of mode: fundamentally
     * this depends only on the position of the collectable.
     * @param posX is the x-position of the collectable.
     * @param posY is the y-position of the collectable.
     */
    public Collectable(float posX, float posY) {
        this.x = posX;
        this.y = posY;
    }

    /**
     * Check if the player is in range. This is done by comparing the point
     * (playerX + 8, playerY + 16) to the position of the collectable via
     * Euclidean distance.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     * @return true if in range
     */
    public boolean checkInRange(float playerX, float playerY){
        if (!playerHas) {
            float dx = x - pickupOffsetX -playerX;
            float dy = y - pickupOffsetY - playerY;
            return World.withinDistance(dx, dy, pickupDistanceSquared);
        }

        return false;
    }

    /**
     * The logic to update this item's behaviour on each frame.
     * @param delta is the time since the previous frame.
     */
    public void update(float delta) {}

    /**
     * Mark as collected and scale to inventory bar size
     */
    public void collect() {
        playerHas = true;
        img.setScale(1f, 1f);
        float multiplier = img.getHeight() / img.getWidth();
        img.setWidth(24);
        img.setHeight(24 * multiplier);
        audioManager.playCollect();
    }

    /**
     * Tells the audio manager to play the collection sound.
     */
    public void playSound(){
        if (!isTesting) audioManager.playCollect();
    }

    @Override
    public String toString() {
        return name;
    }

    public void dispose() {
        tex.dispose();
    }
}
