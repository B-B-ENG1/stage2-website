package io.github.team6ENG.EscapeUni.Managers;

import com.badlogic.gdx.graphics.g2d.Animation;
import io.github.team6ENG.EscapeUni.Entities.Puddle;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;
import io.github.team6ENG.EscapeUni.World;

import java.util.Random;

/**
 * Manages the behaviour of rain in the game. Note that the value for whether
 * rain is happening or not is stored in the World object, and this manager
 * merely controls it. In fact, the world object can force rain to stop at
 * any time if it told to.
 */
public class RainManager {

    private Animation<ImageDelegate> animation;
    private ImageDelegate tint;
    protected final World world;
    private final GraphicsManager graphics;
    protected final AudioManager audio;
    protected final PuddleManager puddleManager;
    public static final float rainDuration = 80f;
    private float rainTime = 0;
    private final Random random = new Random();
    /**
     * The reciprocal of the probability of rain occurring per second. That is,
     * the average number of seconds it will take for rain to happen.
     */
    private static final int secondsPerRain = 60;
    /**
     * The reciprocal of the probability of a puddle being created during
     * rain every second. That is, every secondsPerPuddle seconds,
     * on average there is a puddle created somewhere.
     */
    private static final int secondsPerPuddle = 10;


    public RainManager(World world, GraphicsManager graphics, AudioManager audio,
                       PuddleManager puddleManager) {
        this.world = world;
        this.graphics = graphics;
        this.audio = audio;
        this.puddleManager = puddleManager;
        initialiseAnimation();
        tint = graphics.createTextureDelegate(AssetManager.rainTintAsset).createImage();
    }

    private void initialiseAnimation() {
        ImageDelegate[] keyFrames = new ImageDelegate[AssetManager.rainAssets.length];
        for (int i = 0; i < keyFrames.length; i++) {
            keyFrames[i] = graphics.createTextureDelegate(AssetManager.rainAssets[i]).createImage();
        }
        animation = new Animation<>(0.1f, keyFrames);
    }

    /**
     * If it has not rained yet, randomly decides whether it should start
     * raining this frame. Otherwise, if it is still raining, draws the rain,
     * potentially adds more puddles, and reduces the remaining rain time.
     * @param delta is the time since the previous frame.
     */
    public void update(float delta) {
        if (!world.hasRainOccurred()) {

            tryRain(delta);
        }else if (world.isRaining()) {
            draw();
            placePuddle(delta);
            rainTime += delta;
            if (rainTime >= rainDuration) {
                audio.stopRain();
                world.stopRain();
                rainTime = rainDuration;
            }
        }
    }

    /**
     * Tells the puddle manager (with a random chance) to place a puddle,
     * as required by {@code update}.
     * @param delta is the time since the previous frame.
     */
    protected void placePuddle(float delta) {
        // Seconds per puddle = delta / expectedPuddles
        // so, expectedPuddles = delta / secondsPerPuddle.
        // The bound is the reciprocal of the expectation.
        int probabilityBound = (int)(secondsPerPuddle / delta + 1);
        if (random.nextInt(probabilityBound) == 0) {
            puddleManager.addPuddles(1);
        }
    }

    /**
     * At random, decides whether to start raining or not as required by
     * {@code update}.
     * @param delta is the time since the previous frame.
     */
    protected void tryRain(float delta) {
        // Seconds per rain = delta / expectedRain
        // so, expectedRain = delta / secondsPerRain.
        // The bound is the reciprocal of the expectation.
        int probabilityBound = (int)(secondsPerRain / delta + 1);
        if (random.nextInt(probabilityBound) == 0) {
            world.rainEvent();
            audio.playRain();
        }
    }

    /**
     * Draws a rain image on the screen. The map is 1600x1600, and
     * each rain texture is 200x200. So, we draw 8 * 8 = 64 rain textures
     * to form a grid of rain around the map.
     */
    private void draw() {
        ImageDelegate currentImage = animation.getKeyFrame(rainTime, true);
        for (int x = 0; x < 8; x++ ){
            for (int y = 0; y < 8; y++ ){
                currentImage.setPosition(x * 200, y * 200);
                graphics.drawImage(currentImage, 0.45f);
            }
        }
        if (!world.isDark()) graphics.drawImage(tint, 0.25f);
    }
}
