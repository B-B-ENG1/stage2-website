package io.github.team6ENG.EscapeUni;

import java.util.ArrayList;

import io.github.team6ENG.EscapeUni.Entities.Puddle;
import io.github.team6ENG.EscapeUni.Entities.Worm;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.PuddleManager;
import io.github.team6ENG.EscapeUni.Managers.WormManager;

/**
 * A centre for common game logic and information to be accessed.
 * In future, we can add further data/methods to this if desired.
 */
public class World {
    // Events
    public static final int totalNegativeEvents = 5;
    public static final int totalPositiveEvents = 4;
    public static final int totalHiddenEvents = 3;
    private int foundNegativeEvents = 0;
    private int foundPositiveEvents = 0;
    private int foundHiddenEvents = 0;

    private boolean puddleEvent = false;
    private boolean wormEvent = false;
    private boolean rainEvent = false;
    private boolean pondEvent = false;
    private boolean piazzaEvent = false;
    private boolean darkEvent = false;
    private boolean drinkEvent = false;
    private boolean isRaining = false;
    private boolean isDark = false;
    /**
     * A worm that has been requested to be picked up/eaten by the Goose.
     * If this is null then there is no pickup request.
     */
    private Worm wormPickup;

    // Timer and Score
    public final static float initialTimer = 300;
    public final static float initialScore = 300;
    private float gameTimer = initialTimer;
    private float score = initialScore;

    // Character
    private AssetManager.CharacterChoice chara;

    // World Sizing: This is updated during resizing by Main. These are the
    // widths that come before rescaling.
    private float worldWidth = 100;
    private float worldHeight = 100;

    // Managers
    private PuddleManager puddleManager;
    private WormManager wormManager;

    public World() {
        chara = AssetManager.CharacterChoice.FEMALE;
    }

    /**
     * Adds a given puddle manager to the world. This manager is not necessary
     * for the world object to function: it's just an added connection if
     * needed.
     * @param puddleManager is the manager added.
     */
    public void addPuddleManager(PuddleManager puddleManager) {
        this.puddleManager = puddleManager;
    }

    /**
     * Adds a given worm manager to the world. This manager is not necessary
     * for the world object to function: it's just an added connection if
     * needed.
     * @param wormManager is the manager added.
     */
    public void addWormManager(WormManager wormManager) {
        this.wormManager = wormManager;
    }


    /**
     * Returns the puddles given by the puddle manager in this world.
     * If there is no such manager, then an empty list is given.
     * @return the list of puddles.
     */
    public ArrayList<Puddle> getPuddles() {
        if (puddleManager == null) return new ArrayList<>();
        return puddleManager.getPuddles();
    }

    /**
     * Returns the worms given by the worm manager in this world.
     * If there is no such manager, then an empty list is given.
     * @return the list of worms.
     */
    public ArrayList<Worm> getWorms() {
        if (wormManager == null) return new ArrayList<>();
        return wormManager.getWorms();
    }

    /**
     * Sets the choice of character to the given character.
     * @param chara is the character to be selected.
     */
    public void setCharacter(AssetManager.CharacterChoice chara) {
        this.chara = chara;
    }

    public String getCharacterAsset() {
        return chara.getCharacterAsset();
    }

    public String getIDCardAsset() {
        return chara.getIDCardAsset();
    }

    /**
     * Determines whether the world is dark right now.
     * @return true if it is dark and false otherwise.
     */
    public boolean isDark() {
        return isDark;
    }

    /**
     * Sets the state of the world to either be dark or not.
     * @param isDark is true if the world is to be set to dark and false
     *               otherwise.
     */
    public void toggleDark(boolean isDark) {
        if (isDark && !this.isDark) {
            darkEvent();
        }
        this.isDark = isDark;
    }

    /**
     * Determines whether it is currently raining in this world.
     * @return true if it is raining and false otherwise.
     */
    public boolean isRaining() {return isRaining;}

    /**
     * Makes it stop raining.
     */
    public void stopRain() {isRaining = false;}

    /**
     * Checks whether the given component distances give a total Euclidean
     * distance within the square root of the ceiling.
     * @param dx is the distance between points along the x-axis.
     * @param dy is the distance between points along the y-axis.
     * @param sqCeil is the square of the ceiling on the acceptable distance
     *               between two points.
     * @return true if the Euclidean distance between the points specified by
     *  the given component distances is below the square root of
     *  {@code sqCeil} (non-inclusive).
     */
    public static boolean withinDistance(float dx, float dy, float sqCeil) {
        if (sqCeil < 0) {
            throw new IllegalArgumentException("The square ceiling should be"
            + " non-negative.");
        }
        return dx * dx + dy * dy < sqCeil;
    }

    /**
     * Sets the timer and score back to their initial values and sets the
     * number of events found to zero.
     */
    public void reset() {
        gameTimer = initialTimer;
        score = initialScore;
        foundNegativeEvents = 0;
        foundPositiveEvents = 0;
        foundHiddenEvents = 0;
        puddleEvent = false;
        wormEvent = false;
        rainEvent = false;
        pondEvent = false;
        drinkEvent = false;
        piazzaEvent = false;
        darkEvent = false;
        isRaining = false;
        isDark = false;
    }

    /**
     * A getter for the timer.
     * @return the value of the timer.
     */
    public float getTimer() {
        return gameTimer;
    }

    /**
     * A setter for the timer.
     * @param delta is the time to reduce the timer by.
     * @throws IllegalArgumentException if delta is negative.
     */
    public void decrementTimer(float delta) {
        if (delta < 0) {
            throw new IllegalArgumentException("Time delta must be non-negative.");
        }
        gameTimer = Math.max(0, gameTimer - delta);
    }

    /**
     * A setter for the score via an incrementation.
     * @param scoreDelta is the value to be added to the score. This can be
     *                   positive or negative.
     */
    public void incrementScore(float scoreDelta) {
        score = Math.max(score + scoreDelta, 0);
    }

    /**
     * A getter for the score.
     * @return the current score.
     */
    public float getScore() {
        return score;
    }

    /**
     * Increments the number of found hidden events by 1.
     */
    public void hiddenEventFound() {
        foundHiddenEvents = Math.min(
            foundHiddenEvents + 1,
            totalHiddenEvents
        );
    }

    /**
     * Increments the number of found negative events by 1.
     */
    public void negativeEventFound() {
        foundNegativeEvents = Math.min(
            foundNegativeEvents + 1,
            totalNegativeEvents
        );
    }

    /**
     * Increments the number of found positive events by 1.
     */
    public void positiveEventFound() {
        foundPositiveEvents = Math.min(
            foundPositiveEvents + 1,
            totalPositiveEvents
        );
    }

    /**
     * A getter for the number of negative events found.
     * @return the attribute {@code foundNegativeEvents}
     */
    public int getFoundNegativeEvents() {
        return foundNegativeEvents;
    }

    /**
     * Marks the occurrence of a puddle event. This will do nothing if a puddle
     * event has already happened. Otherwise, it will increase the event counter
     * by 1.
     */
    public void puddleEvent() {
        if (!puddleEvent) {
            puddleEvent = true;
            negativeEventFound();
        }
    }

    /**
     * Marks the occurrence of a worm event. This will do nothing if a worm
     * event has already happened.
     */
    public void wormEvent() {
        if (!wormEvent) {
            wormEvent = true;
            negativeEventFound();
        }
    }

    /**
     * Request the given worm to be picked up.
     * @param worm is the worm to be picked up.
     */
    public void requestWormPickup(Worm worm) {
        wormPickup = worm;
    }

    /**
     * Consumes the pickup request for the worm, if it exists, and returns the
     * worm that was requested. If there was no such request then this is set
     * to null.
     * @return the worm that was requested for pickup by the Goose.
     */
    public Worm consumeWormPickupRequest() {
        Worm worm = wormPickup;
        wormPickup = null;
        return worm;
    }

    /**
     * Marks the occurrence of a pond event.
     */
    public void pondEvent() {
        if (!pondEvent) {
            pondEvent = true;
            hiddenEventFound();
        }
    }

    /**
     * Marks the occurrence of an energy drink event.
     */
    public void drinkEvent() {
        if (!drinkEvent) {
            drinkEvent = true;
            positiveEventFound();
        }
    }

    /**
     * Marks the occurrence of entering the Piazza building.
     */
    public void piazzaEvent() {
        if (!piazzaEvent) {
            piazzaEvent = true;
            hiddenEventFound();
        }
    }

    /**
     * Marks the occurrence of the world becoming dark.
     */
    public void darkEvent() {
        if (!darkEvent) {
            darkEvent = true;
            negativeEventFound();
        }
    }

    /**
     * Marks the occurrence of a rain event. This will do nothing if a rain
     * event has already happened. Otherwise, it will increase the event counter
     * by 1.
     */
    public void rainEvent() {
        isRaining = true;
        if (!rainEvent) {
            rainEvent = true;
            negativeEventFound();
        }
    }

    /**
     * Determines whether it has rained.
     * @return true if rain has started at any point and false otherwise.
     */
    public boolean hasRainOccurred() {
        return rainEvent;
    }

    /**
     * A getter for the number of positive events found.
     * @return the attribute {@code foundPositiveEvents}
     */
    public int getFoundPositiveEvents() {
        return foundPositiveEvents;
    }

    /**
     * A getter for the number of hidden events found.
     * @return the attribute {@code foundHiddenEvents}
     */
    public int getFoundHiddenEvents() {
        return foundHiddenEvents;
    }

    /**
     * Gets the current world width, scaled by the given tileDimensions.
     * @param tileDimensions
     * @return the value of {@code worldWidth} scaled by {@code tileDimensions}.
     */
    public float getWorldWidth(int tileDimensions) {
        return worldWidth *  tileDimensions;
    }

    /**
     * Gets the current, unscaled world width.
     * @return the current value of {@code worldWidth}.
     */
    public float getWorldWidth() {
        return worldWidth;
    }

    /**
     * Gets the current world height, scaled by the given tileDimensions.
     * @param tileDimensions
     * @return the current value of {@code worldHeight} scaled by {@code tileDimensions}.
     */
    public float getWorldHeight(int tileDimensions) {
        return worldHeight * tileDimensions;
    }

    /**
     * Gets the current, unscaled world height.
     * @return the current value of {@code worldHeight}.
     */
    public float getWorldHeight() {
        return worldHeight;
    }

    /**
     * A setter for {@code worldWidth}. This will need to be scaled by dimensions
     * when they are known.
     * @param worldViewportWidth is the viewport's world height.
     * @throws IllegalArgumentException if the given height is negative.
     */
    public void setWorldWidth(float worldViewportWidth) {
        if (worldViewportWidth < 0) {
            throw new IllegalArgumentException(
                "The world width should be non-negative.");
        }
        worldWidth = worldViewportWidth;
    }

    /**
     * A setter for {@code worldHeight}. This will need to be scaled by dimensions
     * when they are known.
     * @param worldViewportHeight is the viewport's world height.
     * @throws IllegalArgumentException if the given height is negative.
     */
    public void setWorldHeight(float worldViewportHeight) {
        if (worldViewportHeight < 0) {
            throw new IllegalArgumentException(
                "The world height should be non-negative.");
        }
        worldHeight = worldViewportHeight;
    }
}
