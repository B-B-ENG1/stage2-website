package io.github.team6ENG.EscapeUni.Managers;

import java.util.HashMap;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Pixmap;
import io.github.team6ENG.EscapeUni.Screens.Delegates.FrameBufferDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;

/**
 * Stores light sources and renders a dark overlay with
 * light sources (circles) to simulate 2D lighting effects.
 *
 */
public class LightingManager {
    private HashMap<String, LightSource> lights = new HashMap<String, LightSource>();
    private GraphicsManager graphics;
    private FrameBufferDelegate frameBuffer;
    private TextureDelegate lightTexture;
    private FrameBufferDelegate featherFrameBuffer;
    private TextureDelegate featherTexture;
    private boolean gogglesOn = false;

    public void setGogglesOn(boolean on) {
        this.gogglesOn = on;
    }

    public LightingManager(GraphicsManager graphics, int mapWidth, int mapHeight) {
        this.graphics = graphics;
        frameBuffer = graphics.createFrameBufferDelegate(Pixmap.Format.RGBA8888,
            mapWidth, mapHeight, false);
        lightTexture = graphics.createTextureDelegate(mapWidth, mapHeight,
            Pixmap.Format.RGBA8888);
        // Separate buffer for feathers so they don't overwrite the night effect
        featherFrameBuffer = graphics.createFrameBufferDelegate(Pixmap.Format.RGBA8888,
            mapWidth, mapHeight, false);
        featherTexture = graphics.createTextureDelegate(mapWidth, mapHeight,
            Pixmap.Format.RGBA8888);
    }

    /**
     * Represents a single light source
     */
    static class LightSource{
        float circleX;
        float circleY;
        Color colour;
        int radius;
        boolean isVisible;
        boolean alwaysOn;
        int priority;

        /**
         * Initialises single light source
         * @param circleX
         * @param circleY
         * @param colour
         * @param radius
         */
        protected LightSource(float circleX, float circleY, Color colour, int radius){
            this.circleX = circleX;
            this.circleY = circleY;
            this.colour = colour;
            this.radius = radius;
            isVisible = true;
            alwaysOn = false;
            priority = 0;
        }
    }

    /**
     * create new light source and add to list of lights
     * @param lightName
     * @param circleX
     * @param circleY
     * @param colour
     * @param radius
     */
    public void addLightSource(String lightName, float circleX, float circleY, Color colour, int radius){
        lights.put(lightName, new LightSource(circleX, circleY, colour, radius));
    }

    /**
     * Remove a light source from lights
     * @param lightName
     */
    public void removeLightSource(String lightName){
        lights.remove(lightName);
    }

    /**
     * Reset list of lights
     */
    public void clearLightSources(){
        lights.clear();
    }

    /**
     * Reposition light source
     */
    public void updateLightSource(String lightName, float circleX, float circleY){
        lights.get(lightName).circleX = circleX;
        lights.get(lightName).circleY = circleY;

    }

    /**
     * Adjust radius of a light source
     * @param lightName
     * @param radius
     */
    public void adjustRadius(String lightName, int radius){
        lights.get(lightName).radius = radius;
    }

    /**
     * Set visibility of light source
     * @param lightName
     * @param isVisible
     */
    public void isVisible(String lightName, boolean isVisible){
        lights.get(lightName).isVisible = isVisible;
    }


    /**
     * Determines whether there exists a visible light with the given name.
     * If the light does not exist or is not visible then false is returned.
     * @param lightName is the name of the light to be checked for.
     * @return true if and only if there exists a visible light with the given
     *  name.
     */
    public boolean isVisible(String lightName) {
        LightSource lightSource = lights.get(lightName);
        if (lightSource == null) return false;
        return lightSource.isVisible;
    }

    /**
     * Mark a light as always-on: lighting system will render it even when
     * the world global dark flag is not set (GameScreen checks this).
     */
    public void setAlwaysOn(String lightName, boolean alwaysOn) {
        if (lights.containsKey(lightName)) {
            lights.get(lightName).alwaysOn = alwaysOn;
        }
    }

    /**
     * Set priority for a light source.
     * This is for the feather patches
     * @param lightName the name of the feature light
     * @param priority the priority level >0 is on top of the night effect
     */
    public void setPriority(String lightName, int priority) {
        if (lights.containsKey(lightName)) {
            lights.get(lightName).priority = priority;
        }
    }

    /**
     * Returns true if any light is both visible and marked always-on.
     */
    public boolean hasActiveAlwaysOnLights() {
        for (LightSource ls : lights.values()) {
            if (ls != null && ls.isVisible && ls.alwaysOn) return true;
        }
        return false;
    }

    /**
     * Renders the lighting system:
     * 1. Draws a dark overlay
     * 2. Adds transparent circles
     *
     * @param camera The camera
     * @param mapWidth Dimensions of world map for drawing darkness
     * @param mapHeight Dimensions of world map for drawing darkness
     *
     * @return Texture representing the darkness and lights
     */

    public TextureDelegate render(OrthographicCamera camera, int mapWidth, int mapHeight) {
        frameBuffer.begin();

        Pixmap pixmap = new Pixmap(mapWidth,mapHeight, Pixmap.Format.RGBA8888);

        // Fill entire pixmap with semi-transparent black or green for goggles
        if (gogglesOn) {
            pixmap.setColor(0.2f,1,0.1f,0.4f);
        } else {
            pixmap.setColor(0f, 0f, 0f, 0.9f);
        }
        pixmap.fill();

        pixmap.setBlending(Pixmap.Blending.None);

        // Draw all night effect and torch event lights
        for(String l : lights.keySet()) {
            LightSource light = lights.get(l);
            if(light.isVisible && light.priority <= 0) {
                pixmap.setColor(light.colour);
                pixmap.fillCircle((int) (light.circleX), mapHeight - (int) (light.circleY), light.radius);
            }
        }

        lightTexture.draw(pixmap, 0, 0);


        pixmap.dispose();
        frameBuffer.end();

        return lightTexture;

    }

    /**
     * Renders the feather effect
     * Use this to draw feathers on top of the game without triggering the night effect.
     *
     * @param camera The camera
     * @param mapWidth Dimensions of world map
     * @param mapHeight Dimensions of world map
     * @return the feather texture lights
     */
    public TextureDelegate renderFeathersOnly(OrthographicCamera camera, int mapWidth, int mapHeight) {
        boolean hasFeathers = false;
        for (LightSource light : lights.values()) {
            if (light.isVisible && light.priority > 0) {
                hasFeathers = true;
                break;
            }
        }
        if (!hasFeathers) return null;

        featherFrameBuffer.begin();
        Pixmap pixmap = new Pixmap(mapWidth, mapHeight, Pixmap.Format.RGBA8888);

        // Start with fully transparent background
        pixmap.setColor(0f, 0f, 0f, 0f);
        pixmap.fill();
        pixmap.setBlending(Pixmap.Blending.None);

        // Draw only high priority feather lights
        for (String l : lights.keySet()) {
            LightSource light = lights.get(l);
            if (light.isVisible && light.priority > 0) {
                int cx = (int) light.circleX;
                int cy = mapHeight - (int) light.circleY;
                int r = light.radius;

                // Central quil
                pixmap.setColor(1f, 1f, 1f, 0.7f);
                for (int i = -r; i <= r; i++) {
                    int quillX = cx + i / 8; // slight curve
                    int quillY = cy + i;
                    pixmap.fillCircle(quillX, quillY, 3);
                }

                // Barbs
                pixmap.setColor(1f, 1f, 1f, 0.5f);
                for (int i = -r + 15; i < r - 15; i += 15) {
                    int quillX = cx + i / 8;
                    int quillY = cy + i;
                    // Left barbs
                    int barbLen = (int)(r * 0.5f * (1f - Math.abs(i) / (float)r));
                    for (int b = 0; b < barbLen; b += 2) {
                        int bx = quillX - b;
                        int by = quillY - b / 3;
                        pixmap.fillCircle(bx, by, 3);
                    }
                    // Right barbs
                    for (int b = 0; b < barbLen; b += 2) {
                        int bx = quillX + b;
                        int by = quillY - b / 3;
                        pixmap.fillCircle(bx, by, 3);
                    }
                }
            }
        }

        featherTexture.draw(pixmap, 0, 0);
        pixmap.dispose();
        featherFrameBuffer.end();

        return featherTexture;
    }

    public void dispose(){

    }
}
