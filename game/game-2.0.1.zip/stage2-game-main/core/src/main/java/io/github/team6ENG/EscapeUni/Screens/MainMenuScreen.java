package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

/**
 * first screen to display when game loads
*/
public class MainMenuScreen extends AbstractScreen {
    // stage and resources created in show() and disposed in dispose()
    private StageDelegate stage;
    private final GlyphLayout layout = new GlyphLayout();

    private TextButtonDelegate playButton;
    private TextButtonDelegate exitButton;

    private com.badlogic.gdx.InputProcessor previousInputProcessor; // used to restore on hide()

    private static final String TITLE_TEXT = "Escape University Of York";

    /**
     * Initialise menu screen
     * @param game current instance of Main
     */
    public MainMenuScreen(final Main game) {
        super(game);
        graphics = game.graphicsManager;
        game.elapsedTimeChecker.startTimer("Main menu to game");
        // DO NOT initialize stage/input here — do it in show()
    }

    @Override
    public void show() {
        // create stage with a fixed virtual size (you used 800x450)
        stage = graphics.createFixedStageDelegate(game.viewport);

        // remember previous input processor so we can restore it later
        previousInputProcessor = Gdx.input.getInputProcessor();
        stage.setInputProcessor();


        // build UI
        setupUI();

        if (game.elapsedTimeChecker.timerExists("Pause to Main Menu")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Pause to Main Menu");
            System.out.println("Time taken to get from pause screen to " +
                "main menu screen: " + elapsed + " ms");
        }
    }
    /**
     *Add required UI elements to stage
     */
    private void setupUI() {
        playButton = createButton("Play");
        exitButton = createButton("Exit");

        playButton.addToStage(stage);
        playButton.addToStage(stage);

        positionButtons();
        addListeners();
    }


    /**
     * Place buttons on screen
     */
    private void positionButtons() {
        float w = stage.getViewport().getWorldWidth();
        float h = stage.getViewport().getWorldHeight();

        playButton.setPosition((w - playButton.getWidth()) / 2f, h / 2f );
        exitButton.setPosition((w - exitButton.getWidth()) / 2f, h / 2f - 120);
    }

    /**
     * Getters for the play button's delegate, available for
     * testing purposes.
     * @return the play/exit button delegates associated with the screen.
     */
    public TextButtonDelegate getPlayButton() {
        return playButton;
    }
    public TextButtonDelegate getExitButton() {
        return exitButton;
    }


    /**
     * Add listeners for button functionality
     */
    private void addListeners() {
        Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
        Color clickColor = new Color(0.4f, 1f, 1f, 1f);

        playButton.addListener(new ClickListener() {
            private boolean clicked = false;
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (clicked) return;
                game.elapsedTimeChecker.startTimer("Main Menu to Username");
                clicked = true;
                playButton.setColor(clickColor);
                Gdx.app.postRunnable(() -> game.setScreen(new UsernameScreen(game)));
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                playButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                playButton.setColor(normalColor);
            }
        });

        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                exitButton.setColor(clickColor);
                Gdx.app.postRunnable(Gdx.app::exit);
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                exitButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                exitButton.setColor(normalColor);
            }
        });
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);

        // update stage
        if (stage != null) {
            stage.act(delta);
        }

        // Draw background + title using game's batch (aligned to stage camera)
        if (stage != null) {
            graphics.updateBatchProjectionMatrix(stage.getCameraCombinedProjection());
        } else {
            graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        }

        graphics.beginBatch();
        float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
        float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();

        float brightness = 0.85f + 0.15f * (float) Math.sin(TimeUtils.millis() / 500f);
        if (graphics.menuFont != null) {
            graphics.menuFont.setColor(brightness, brightness, brightness, 1f);
            layout.setText(graphics.menuFont, TITLE_TEXT);
            graphics.drawText(graphics.menuFont, TITLE_TEXT, (w - layout.width) / 2f, h * 0.82f);
            graphics.menuFont.setColor(Color.WHITE);
        }

        graphics.endBatch();

        if (stage != null) stage.draw();

        // allow quick keyboard start (space)
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) stage.getViewport().update(width, height, true);
        positionButtons();
    }

    @Override
    public void pause() { }

    @Override
    public void resume() { }

    @Override
    public void hide() {
        if (stage.isInputProcessor()) {
            Gdx.input.setInputProcessor(null);
        }

        if (previousInputProcessor != null) {
            Gdx.input.setInputProcessor(previousInputProcessor);
            previousInputProcessor = null;
        }
    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
