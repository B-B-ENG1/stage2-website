package io.github.team6ENG.EscapeUni.Managers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;

/**
 * Caches valid block positions for different block sizes so no need to ever recompute them.
 * As long as the block size is the same, the cords can be reused.
 */
public class BlockPositionCache {
    private static final Map<Integer, ArrayList<int[]>> cache = new HashMap<>();

    /**
     * Gets a copy of valid block positions for the specified block size, if it exist in the cache.
     * If it doesn't, it will compute it and store in the cache.
     * 
     * @param blockSize the size of blocks to get cords for
     * @return a array list with valid block cords
     */
    public static ArrayList<int[]> getValidBlockPositions(int blockSize) {
        if (!cache.containsKey(blockSize)) {
            cache.put(blockSize, computeValidBlockPositions(blockSize));
        }

        return new ArrayList<>(cache.get(blockSize));
    }

    
    /**
     * Computes valid top left positions for placing a block on walkable areas of the map.
     * Valid as in given N*N size block, all tiles within that block is still walkable.
     *
     * @param blockSize the width and height of the block to check for valid top left posisition.
     * @return an ArrayList of int arrays, where each int array contains the x y coordinates of the top left position
     */
    private static ArrayList<int[]> computeValidBlockPositions(int blockSize) {
        ArrayList<int[]> validBlockPositions = new ArrayList<>();
        TiledMap map = new TmxMapLoader().load("tileMap/map.tmx");
        TiledMapTileLayer collisionLayer = (TiledMapTileLayer)map.getLayers().get(TileManager.mapPathId);

        for (int x = 0; x < collisionLayer.getWidth() - (blockSize - 1); x++) {
            for (int y = 0; y < collisionLayer.getHeight() - (blockSize - 1); y++) {
                boolean isValidBlock = true;
                for (int dx = 0; dx < blockSize && isValidBlock; dx++) {
                    for (int dy = 0; dy < blockSize && isValidBlock; dy++) {
                        TiledMapTileLayer.Cell cell = collisionLayer.getCell(x + dx, y + dy);
                        if (!(cell == null || cell.getTile() == null)) {
                            isValidBlock = false;
                        }
                    }
                }
                if (isValidBlock) {
                    validBlockPositions.add(new int[]{x, y});
                }
            }
        }
        
        return validBlockPositions;
    }
}
