package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;

public class TextureRegionDrawableDelegate {

    private TextureRegionDrawable draw;

    public TextureRegionDrawableDelegate() {}

    public TextureRegionDrawableDelegate(TextureRegionDrawable draw) {
        this.draw = draw;
    }

    public ImageButtonDelegate createImageButton() {
        return new ImageButtonDelegate(new ImageButton(draw));
    }

    public void setMinSize(float width, float height) {
        this.draw.setMinSize(width, height);
    }

    public float getMinWidth() {
        return draw.getMinWidth();
    }

    public float getMinHeight() {
        return draw.getMinHeight();
    }
}
