package io.github.team6ENG.EscapeUni.Entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.Color;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.World;

/**
 * A container for all information about the bus.
 */
public class Bus {
    private final GraphicsManager graphics;
    private final AudioManager audio;
    private final ItemManager items;
    private final TextureDelegate texture;
    private final Player plr;
    private float x, y;
    private boolean leaving = false;
    public static final float width = 100;
    public static final float height = 60;

    public Bus(float x, float y, Player plr, GraphicsManager graphics,
               AudioManager audioManager, ItemManager items) {
        this.plr = plr;
        this.graphics = graphics;
        this.audio = audioManager;
        this.items = items;
        this.texture = graphics.createTextureDelegate(AssetManager.busAsset);
        this.x = x;
        this.y = y;
    }

    /**
     * If the bus is leaving, then update the camera to follow the bus.
     * Otherwise, do nothing.
     * @param camera is the camera to follow the bus.
     */
    public void leavingCamera(Camera camera) {
        if (leaving) {
            camera.position.x = x;
            camera.position.y = y + 20;
        }
    }

    public void leave() {
        leaving = true;
        audio.stopFootsteps();
        audio.setGameVolume(0);
        audio.setMusicVolume(0);
        audio.stopMusic();

    }

    /**
     * Determines whether the bus is in the state of leaving.
     * @return true if the bus is leaving and false otherwise.
     */
    public boolean isLeaving() {
        return leaving;
    }

    /**
     * If the bus is leaving, then the bus is moved backwards along with
     * the player. In this case, if the bus' x position is before 950,
     * then true is returned (to signal the game needing to end). Otherwise,
     * false is returned. In the case where the bus is not leaving, if the player
     * has their phone and are close enough, they may leave.
     * @param delta
     * @return
     */
    public boolean update(float delta) {
        if (leaving) {
            plr.torch.toggleNoNoise();
            x -= 80 * delta;
            plr.sprite.setPosition(x, y);
            Gdx.gl.glClearColor(0, 0, 0, Math.min(1, (x - 1500) / 300f));
            return x < 950;
        }else if (plr.has(items.getPhone())){
            plr.hasEnteredLangwith();
            if (playerWithinSquareDistance(2500)) {
                leave();
                items.getTorch().playerHas = false;
                plr.torch.toggleNoNoise(true);
                //player.sprite.setAlpha(0f);
                graphics.gameFont.setColor(Color.BLUE);
                graphics.gameFont.getData().setScale(2f);
            }
        }
        return false;
    }

    /**
     * Determines whether the player is within a given square radius of the bus.
     * @param squareDistance is the square of the upper bound on the acceptable
     *                       distance.
     * @return true if the player is within the distance and false otherwise.
     */
    private boolean playerWithinSquareDistance(float squareDistance) {
        float dx = plr.sprite.getX() - x;
        float dy = plr.sprite.getY() - y;
        return World.withinDistance(dx, dy, squareDistance);
    }

    /**
     * Draws the bus on the screen.
     */
    public void draw() {
        graphics.drawTexture(texture, x, y, width, height);
    }

    public void dispose() {
        texture.dispose();
    }
}
