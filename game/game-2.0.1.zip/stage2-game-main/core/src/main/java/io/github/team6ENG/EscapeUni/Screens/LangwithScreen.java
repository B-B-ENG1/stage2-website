package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.*;
import io.github.team6ENG.EscapeUni.Entities.Collectable;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Managers.BuildingManager;
import io.github.team6ENG.EscapeUni.Performance.FPSTracker;

/**
 * Represents the interior of the Ron Cooke building.
 * Displays a black background with a welcome message.
 */
public class LangwithScreen extends AbstractScreen {

    private final BuildingManager buildingManager;
    private final GameScreen gameScreen;  // keep reference to return
    private Player player;
    private float stateTime;
    private float pizzaText = 0;

    float worldWidth;
    float worldHeight ;

    private boolean isEPressed = false;
    private boolean isPaused = false;

    public LangwithScreen(Main game, BuildingManager buildingManager, GameScreen gameScreen) {
        super(game);
        tileDimensions = 16;
        this.buildingManager = buildingManager;
        this.gameScreen = gameScreen;
        this.font = graphics.menuFont;
        this.smallFont = graphics.gameFont;
        initialisePlayer((int) 60,(int) game.viewport.getWorldHeight()/2);
        stateTime = 0;
    }

    /**
     * Initialise player and set its position
     */
    private void initialisePlayer(int x, int y) {
        int height = (int)(game.viewport.getWorldHeight() / 16);
        int width = (int)(game.viewport.getWorldWidth() / 16);
        player = new Player(graphics, world, buildingManager.audioManager, items);
        player.loadSprite(new TiledMapTileLayer( width, height, 16,16), tileDimensions);
        player.sprite.setPosition(x, y);
        player.sprite.setScale(4);
        player.speed  = 2;

    }


    @Override
    public void render(float delta) {
        super.render(delta);
        // Clear to black
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        if(!isPaused) {
            player.handleInput(delta, gameScreen.playerSpeedModifier);
            player.updatePlayer(stateTime);
        }
        graphics.beginBatch();

        graphics.drawSprite(player.sprite);

        worldWidth = game.viewport.getWorldWidth();
        worldHeight = game.viewport.getWorldHeight();


        for (Collectable item : items.getItems()){
            if(item.isVisible && !item.playerHas && item.originScreen.equals("LangwithScreen")){
                graphics.drawImage(item.img, 1);
                if (item.checkInRange(player.sprite.getX()- (player.sprite.getHeight()/2) , player.sprite.getY() - (player.sprite.getHeight()/2)) && isEPressed){
                    if (item.toString().equals("pizza")){
                        isEPressed = false;
                        pizzaText = 5;
                        gameScreen.playerSpeedModifier = 2;
                        item.isVisible = false;
                        world.positiveEventFound();
                    }
                    else {

                        item.collect();
                        isEPressed = false;
                    }
                }
            }
        }
        graphics.endBatch();
        renderUI();
        world.decrementTimer(delta);
        world.incrementScore(-delta);
        if (world.getTimer() < 0){
            gameScreen.gameOver();
            return;
        }
        pizzaText -= delta;
        buildingManager.update(delta);
        stateTime += delta;
        isEPressed = Gdx.input.isKeyJustPressed(Input.Keys.E);



        if(Gdx.input.isKeyJustPressed(Input.Keys.P)) {
            isPaused = true;
            game.setScreen(new PauseScreen(game, this, buildingManager.audioManager));

        }

        if (game.elapsedTimeChecker.timerExists("Enter Langwith")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Enter Langwith");
            System.out.println("Time taken to enter Langwith: " + elapsed + " ms");
        }

    }

    private void renderUI(){

        graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        graphics.beginBatch();
        float itemXPos = (worldWidth - (gameScreen.numOfInventoryItems * 32))/2;
        String instructions = "";

        // draw items either in inventory or on screen
        for (Collectable item : items.getItems()) {

            if (item.playerHas){
                item.img.setPosition(itemXPos, worldHeight - 50);
                graphics.drawImage(item.img, 1);
                itemXPos += 32;
            }
            else if (item.originScreen.equals("LangwithScreen") && item.isVisible && item.checkInRange(player.sprite.getX()- 32, player.sprite.getY() - (player.sprite.getHeight()/2))){
                if (instructions.isEmpty()) {
                    if (item.toString().equals("pizza")) {
                        instructions = "Press 'e' to eat pizza";
                    }
                    else {

                        instructions = "Press 'e' to collect " + item.toString();
                    }


                }
            }
        }
        drawEventTracker(smallFont);

        GlyphLayout layout = new GlyphLayout(graphics.menuFont, instructions);
        float textX = (worldWidth - layout.width) / 2;
        graphics.drawText(font, instructions, Color.WHITE, textX, worldHeight -120);
        drawTimerAndScore(font);

        font.setColor(Color.GRAY);
        String exitText = "Press G to leave";
        GlyphLayout exitLayout = new GlyphLayout(font, exitText);
        graphics.drawText(font, exitText,
            (worldWidth - exitLayout.width) / 2, worldHeight - 80);

        if(pizzaText > 0) {
            font.setColor(Color.PURPLE);
            String text = "PIZZA ENERGY, x2 SPEED";
            layout = new GlyphLayout(font, text);
            graphics.drawText(font, text, (worldWidth - layout.width) / 2,
                worldHeight - 150);
        }

        graphics.endBatch();
    }

    @Override public void show() {}
    @Override public void resize(int width, int height) { game.viewport.update(width, height); }
    @Override public void pause() {}
    @Override public void resume() {
        isPaused = false;
    }
    @Override public void hide() {}
    @Override public void dispose() {}
}
