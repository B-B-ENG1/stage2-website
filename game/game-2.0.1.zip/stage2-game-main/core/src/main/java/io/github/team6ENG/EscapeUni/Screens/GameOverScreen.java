package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

/**
 * Displays then the player looses
 */
public class GameOverScreen extends AbstractScreen {

    // stage and resources created in show() and disposed in dispose()
    private StageDelegate stage;
    private final GlyphLayout layout = new GlyphLayout();

    public static final Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
    public static final Color clickColor = new Color(0.4f, 1f, 1f, 1f);

    private TextButtonDelegate mainMenuButton;
    private TextButtonDelegate exitButton;

    private com.badlogic.gdx.InputProcessor previousInputProcessor; // used to restore on hide()

    private static String titleText ;

    /**
     * Initialise game over screen
     * @param game Current instance of Main
     * @param deathMessage reason of death to display on screen
     */
    public GameOverScreen(final Main game, String deathMessage) {
        super(game);
        titleText = deathMessage;
        // DO NOT initialize stage/input here — do it in show()
    }

    @Override
    public void show() {
        // create stage with a fixed virtual size (you used 800x450)
        stage = graphics.createStageDelegate(game.viewport);

        // remember previous input processor so we can restore it later
        previousInputProcessor = Gdx.input.getInputProcessor();
        stage.setInputProcessor();

        // build UI
        setupUI();
    }
    /**
     *Add required UI elements to stage
     */
    private void setupUI() {
        exitButton = createButton("Exit");
        mainMenuButton = createButton("Main Menu");

        exitButton.addToStage(stage);
        mainMenuButton.addToStage(stage);

        positionButtons();
        addListeners();
    }

    /**
     * Place buttons on screen
     */
    private void positionButtons() {
        float w = stage.getViewport().getWorldWidth();
        float h = stage.getViewport().getWorldHeight();

        mainMenuButton.setPosition((w - mainMenuButton.getWidth()) / 2f, h / 2f -40);
        exitButton.setPosition((w - exitButton.getWidth()) / 2f, h / 2f - 150);
    }

    /**
     * getters for the exit/menu button's delegate, available for
     * testing purposes.
     * @return the exit/menu button delegate associated with the screen.
     */
    public TextButtonDelegate getExitButton() {return exitButton;}
    public TextButtonDelegate getMainMenuButton() {
        return mainMenuButton;
    }


    /**
     * Add listeners for button functionality
     */
    private void addListeners() {

        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                exitButton.setColor(clickColor);
                Gdx.app.postRunnable(Gdx.app::exit);
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                exitButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                exitButton.setColor(normalColor);
            }
        });
        mainMenuButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                mainMenuButton.setColor(clickColor);
                dispose();
                game.resetGame();
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                mainMenuButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                mainMenuButton.setColor(normalColor);
            }
        });
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);

        // update stage
        if (stage != null) {
            stage.act(delta);
        }

        // Draw background + title using game's batch (aligned to stage camera)
        if (stage != null) {
            graphics.updateBatchProjectionMatrix(stage.getCameraCombinedProjection());
        } else {
            graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        }

        graphics.beginBatch();
        float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
        float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();



        float brightness = 0.85f + 0.15f * (float) Math.sin(TimeUtils.millis() / 500f);
        if (graphics.menuFont != null) {
            graphics.menuFont.setColor(brightness, brightness, brightness, 1f);
            layout.setText(graphics.menuFont, titleText);
            graphics.drawText(graphics.menuFont, titleText,
                (w - layout.width) / 2f, h * 0.82f);
            graphics.menuFont.setColor(Color.WHITE);
        }

        graphics.endBatch();

        if (stage != null) stage.draw();

        // allow quick keyboard start (space)
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) stage.getViewport().update(width, height, true);
        positionButtons();
    }

    @Override
    public void pause() { }

    @Override
    public void resume() { }

    @Override
    public void hide() {
        if (stage.isInputProcessor()) {
            Gdx.input.setInputProcessor(null);
        }

        if (previousInputProcessor != null) {
            Gdx.input.setInputProcessor(previousInputProcessor);
            previousInputProcessor = null;
        }
    }

    @Override
    public void dispose() {
        // Dispose only things we created here
        stage.dispose();

        // DO NOT dispose game.menuFont or game.buttonSkin or game.batch here
    }
}
