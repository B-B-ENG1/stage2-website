package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.*;
import io.github.team6ENG.EscapeUni.Entities.Collectable;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.BuildingManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;

import java.util.ArrayList;

/**
 * Represents the interior of the Ron Cooke building.
 * Displays a black background with a welcome message.
 */
public class PiazzaScreen extends AbstractScreen {

    private final BuildingManager buildingManager;
    private final GameScreen gameScreen;  // keep reference to return
    private Player player;
    private ImageDelegate receptionist;
    private float stateTime;

    float worldWidth;
    float worldHeight ;

    float speechTimer = 0;
    ArrayList<String> speech = new ArrayList<String>();

    private boolean isEPressed = false;
    private boolean isPaused = false;

    public PiazzaScreen(Main game, BuildingManager buildingManager, GameScreen gameScreen) {
        super(game);
        tileDimensions = 16;
        this.buildingManager = buildingManager;
        this.gameScreen = gameScreen;
        this.font = graphics.menuFont;
        this.smallFont = graphics.gameFont;

        initialisePlayer((int) game.viewport.getWorldWidth()/2,(int) game.viewport.getWorldHeight()/2);
        initialiseReceptionist();
        stateTime = 0;
        speech.add("Welcome to the mail room!");
        speech.add("Post has arrived for you this morning");
        speech.add("     You have...");
        speech.add("Two new items!");
        speech.add("Enjoy!");
    }

    /**
     * Initialise player and set its position
     */
    private void initialisePlayer(int x, int y) {
        int height = (int)(game.viewport.getWorldHeight() / 16);
        int width = (int)(game.viewport.getWorldWidth() / 16);
        player = new Player(graphics, world, buildingManager.audioManager, items);
        player.loadSprite(new TiledMapTileLayer( width, height, 16,16), tileDimensions);
        player.sprite.setPosition(x, y);
        player.sprite.setScale(4);
        player.speed = 2;

    }
    private void initialiseReceptionist(){
        TextureDelegate tex = graphics.createTextureDelegate(AssetManager.receptionistAsset);
        receptionist = tex.createImage();
        receptionist.setPosition((float) (game.viewport.getWorldWidth() * 0.2),
            (game.viewport.getWorldHeight() - receptionist.getHeight()) /2.5f);
        receptionist.setScale(5);
    }

    @Override
    public void render(float delta) {
        // Clear to black
        Gdx.gl.glClearColor(0, 0, 0, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        if(!isPaused) {
            player.handleInput(delta, gameScreen.playerSpeedModifier);
            player.updatePlayer(stateTime);
        }
        graphics.beginBatch();

        graphics.drawSprite(player.sprite);
        graphics.drawImage(receptionist, 1);

        worldWidth = game.viewport.getWorldWidth();
        worldHeight = game.viewport.getWorldHeight();


        for(Collectable item : gameScreen.items.getItems()){
            if(item.isVisible && !item.playerHas && item.originScreen.equals("PiazzaScreen")){
                graphics.drawImage(item.img, 1);
                if (item.checkInRange(player.sprite.getX()- (player.sprite.getHeight()/2) , player.sprite.getY() - (player.sprite.getHeight()/2)) && isEPressed){
                    if (item.toString().equals("potion")){
                        isEPressed = false;
                        gameScreen.items.getPotion().isVisible = false;
                        world.positiveEventFound();
                    }
                    else if (item.toString().equals("goggles")){
                        isEPressed = false;
                        gameScreen.items.getGoggles().isVisible = false;
                        world.positiveEventFound();
                    }
                    item.collect();
                    isEPressed = false;

                }
            }
        }
        graphics.endBatch();
        renderUI();
        if(!isPaused) {
            world.decrementTimer(delta);
            world.incrementScore(-delta);
            if (world.getTimer() < 0){
                gameScreen.gameOver();
                return;
            }
            speechTimer += delta;
            if (gameScreen.items.getGoggles().playerHas && gameScreen.items.getPotion().playerHas) {
                buildingManager.update(delta);
            }
            stateTime += delta;
            isEPressed = Gdx.input.isKeyJustPressed(Input.Keys.E);

            if (Gdx.input.isKeyJustPressed(Input.Keys.P)) {
                isPaused = true;
                game.setScreen(new PauseScreen(game, this, buildingManager.audioManager));

            }
        }
    }

    private GlyphLayout layout = new GlyphLayout();
    private void renderUI(){

        graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        graphics.beginBatch();
        float itemXPos = (worldWidth - (gameScreen.numOfInventoryItems * 32))/2;
        String instructions = "";

        // draw items either in inventory or on screen
        for(Collectable item : gameScreen.items.getItems()) {
            if (item.playerHas){
                item.img.setPosition(itemXPos, worldHeight * 0.8f);
                graphics.drawImage(item.img, 1);
                itemXPos += 32;
            }
            else if (item.originScreen.equals("PiazzaScreen") && item.isVisible && item.checkInRange(player.sprite.getX()- 32, player.sprite.getY() - (player.sprite.getHeight()/2))){
                if (instructions.isEmpty()) {
                    instructions = "Press 'e' to collect " + item.toString();
                }
            }
        }
        float y = worldHeight - 20f;
        float lineSpacing = 15f;

        drawEventTracker(smallFont);
        layout.setText(graphics.menuFont, instructions);
        float textX = (worldWidth - layout.width) / 2;
        graphics.drawText(font, instructions, Color.WHITE, textX, worldHeight * 0.75f);
        drawTimerAndScore(font);

        if(gameScreen.items.getGoggles().playerHas){
            speech.clear();
        }

        //If not yet received card
        if(!speech.isEmpty()){
            graphics.drawText(font, speech.get(0), worldWidth * 0.1f , worldHeight * 0.8f);

            if (speechTimer >= 3){
                speechTimer = 0;
                speech.remove(0);
            }
        } //else second time vising Ron Cooke
        else{
            gameScreen.items.getGoggles().isVisible = true;
            gameScreen.items.getGoggles().x = (float) (game.viewport.getWorldWidth() * 0.3);
            gameScreen.items.getGoggles().y = (float) (game.viewport.getWorldHeight() *0.4);

            gameScreen.items.getPotion().isVisible = true;
            gameScreen.items.getPotion().x = (float) (game.viewport.getWorldWidth() * 0.3);
            gameScreen.items.getPotion().y = (float) (game.viewport.getWorldHeight() *0.45);

            if(gameScreen.items.getGoggles().playerHas) {
                font.setColor(Color.GRAY);
                String exitText = "Press G to leave";
                GlyphLayout exitLayout = new GlyphLayout(font, exitText);
                graphics.drawText(font, exitText, (worldWidth - exitLayout.width) / 2,
                    worldHeight - 50);
            }
        }
        graphics.endBatch();
    }

    @Override public void show() {}
    @Override public void resize(int width, int height) { game.viewport.update(width, height); }
    @Override public void pause() {}
    @Override public void resume() {
        isPaused = false;
    }
    @Override public void hide() {}
    @Override public void dispose() {

    }
}
