package io.github.team6ENG.EscapeUni.Managers;

import io.github.team6ENG.EscapeUni.Entities.Collectable;
import io.github.team6ENG.EscapeUni.Entities.EnergyDrink;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;
import io.github.team6ENG.EscapeUni.World;

import java.util.ArrayList;
import java.util.Random;

/**
 * Places energy drinks around the map using the same block-based algorithm
 * as PuddleManager and adds them to ItemManager.
 */
public class EnergyDrinkManager {

    private ArrayList<int[]> validBlockPositions = new ArrayList<>();
    private ArrayList<EnergyDrink> energyDrinks = new ArrayList<>();
    private Random random = new Random();
    private GraphicsManager graphics;
    private AudioManager audio;
    private World world;
    private final int blockSize;

    public EnergyDrinkManager(World world, GraphicsManager graphics, AudioManager audio, int blockSize) {
        this.blockSize = blockSize;
        if (blockSize <= 0) {
            throw new IllegalArgumentException("Block size must be a positive integer");
        }
        this.graphics = graphics;
        this.audio = audio;
        validBlockPositions = BlockPositionCache.getValidBlockPositions(blockSize);
        this.world = world;
    }

    public void addEnergyDrinks(int number, ItemManager items) {
        if (number <= 0) {
            throw new IllegalArgumentException("Energy drink number must be a positive integer");
        }
        if (number > validBlockPositions.size()) {
            throw new IllegalArgumentException("This many energy drinks cannot be drawn.");
        }

        for (int i = 0; i < number && !validBlockPositions.isEmpty(); i++) {
            int randomIndex = random.nextInt(validBlockPositions.size());
            int[] position = validBlockPositions.get(randomIndex);
            validBlockPositions.remove(randomIndex);
            int drinkX = position[0];
            int drinkY = position[1];

            int tileDimensions = GameScreen.defaultTileDimensions;
            float posX = (drinkX + blockSize / 2.0f) * tileDimensions - tileDimensions / 2.0f;
            float posY = (drinkY + blockSize / 2.0f) * tileDimensions - tileDimensions / 2.0f;

            EnergyDrink drink = new EnergyDrink(world, posX, posY, graphics, audio);
            items.addEnergyDrink(drink);
            energyDrinks.add(drink);
        }
    }

    /**
     * Determines whether there is a drink handled by the manager which is
     * currently in effect on the player.
     * @return true if there is a drink in effect and false otherwise.
     */
    public boolean isDrinkEffective() {
        for (EnergyDrink drink : energyDrinks) {
           if (drink.isEffective()) return true;
        }
        return false;
    }

}
