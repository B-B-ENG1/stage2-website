package io.github.team6ENG.EscapeUni.Managers;

/**
 * Contains all necessary IDs for the different types of tiles used
 * throughout the map, for convenience. This is a utility class.
 */
public abstract class TileManager {
    public static int mapLangwithBarriersId = 3;
    public static int mapWaterId = 2;
    public static int mapWallsId = 1;
    public static int mapPathId = 0;
}
