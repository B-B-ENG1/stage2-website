package io.github.team6ENG.EscapeUni.Managers;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.FrameBuffer;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.viewport.FitViewport;

import io.github.team6ENG.EscapeUni.Screens.Delegates.*;

public class GraphicsManager {

    protected SpriteBatch batch;
    public BitmapFont menuFont;
    public BitmapFont gameFont;
    public Skin buttonSkin;

    public GraphicsManager() {
        createBatch();
        initialiseFonts();
        createButtonSkin();
    }

    protected void createBatch() {
        batch = new SpriteBatch();
    }

    protected void createButtonSkin() {
        buttonSkin = new Skin(Gdx.files.internal(AssetManager.uiSkin));
    }

    public TextBoxDelegate createTextBox(String message, int width, int height,
                                         Color color) {
        TextField box = new TextField("", buttonSkin);
        box.setWidth(width);
        box.setHeight(height);
        box.setColor(color);
        box.setMessageText(message);
        return new TextBoxDelegate(box);
    }

    public TextButtonDelegate createTextButtonDelegate(String text) {
        return new TextButtonDelegate(new TextButton(text, buttonSkin));
    }

    public SliderDelegate createSliderDelegate(float min,
                                               float max,
                                               float stepSize,
                                               boolean vertical) {
        return new SliderDelegate(new Slider(min, max, stepSize, vertical, buttonSkin));
    }

    public TextureDelegate createTextureDelegate(String asset) {
        return new TextureDelegate(new Texture(Gdx.files.internal(asset)));
    }

    public TextureDelegate createTextureDelegate(int width, int height,
                                                 Pixmap.Format format) {
        return new TextureDelegate(new Texture(width, height, format));
    }



    public StageDelegate createStageDelegate(FitViewport viewport) {
        return new StageDelegate(viewport, batch);
    }

    public SpriteDelegate createSpriteDelegate(TextureRegionDelegate texture) {
        return texture.createSpriteDelegate();
    }

    public StageDelegate createFixedStageDelegate(FitViewport viewport) {
        return new StageDelegate(viewport);
    }

    /**
     * Create a delegate for an OrthogonalTiledMapRenderer.
     * @param map is the map for creation of the OrthogonalTiledMapRenderer.
     * @param unitScale is the unitScale of the OrthogonalTiledMapRenderer.
     * @return the delegate of the OrthogonalTiledMapRenderer.
     */
    public RendererDelegate createRendererDelegate(TiledMap map, float unitScale) {
        return new RendererDelegate(new OrthogonalTiledMapRenderer(map, unitScale));
    }

    public FrameBufferDelegate createFrameBufferDelegate(Pixmap.Format format,
                                                         int width,
                                                         int height,
                                                         boolean hasDepth) {
        return new FrameBufferDelegate(new FrameBuffer(format, width, height, hasDepth));
    }

    public void initialiseFonts() {
        //Scale font to our viewport by ratio of viewport height to screen height
        menuFont = new BitmapFont(Gdx.files.internal(AssetManager.menuScreenFont));
        menuFont.setUseIntegerPositions(false);
        menuFont.getData().setScale(0.8f);
        menuFont.setColor(Color.valueOf("4287f5FF"));

        gameFont = new BitmapFont(Gdx.files.internal(AssetManager.menuScreenFont));
        gameFont.getData().setScale(0.4f);
        gameFont.setColor(Color.valueOf("4287f5FF"));
    }

    /**
     * Draws text on the screen with a given font at a given posititon.
     * @param font is the font to be used.
     * @param str is the text to be written.
     * @param x is the x-position of the text.
     * @param y is the y-position of the text.
     */
    public void drawText(BitmapFont font, String str, float x, float y) {
        font.draw(batch, str, x, y);
    }

    /**
     * Helper method: text rendering logic to avoid repeated setColor() calls
     * @param font  The BitmapFont to use for rendering
     * @param text  The text string to display
     * @param colour The colour of the text
     * @param x     The x-coordinate for text position
     * @param y     The y-coordinate for text position
     */
    public void drawText(BitmapFont font, String text, Color colour, float x, float y) {
        font.setColor(colour);
        drawText(font, text, x, y);
    }

    public void drawImage(ImageDelegate image, float parentAlpha) {
        image.draw(batch, parentAlpha);
    }

    public void drawSprite(SpriteDelegate sprite) {
        sprite.draw(batch);
    }

    public void drawTexture(TextureDelegate texture, float x, float y) {

        texture.draw(batch, x, y);
    }

    public void drawTexture(TextureDelegate texture, float x,
                                  float y, float width, float height) {
        texture.draw(batch, x, y, width, height);
    }

    public void drawTextureRegion(TextureRegionDelegate texture, float x,
                                  float y) {
        texture.draw(batch, x, y);
    }

    public void drawTextureRegion(TextureRegionDelegate texture, float x,
                                  float y, float width, float height) {
        texture.draw(batch, x, y, width, height);
    }

    /**
     * Sets the colour of the sprite batch to the given colour.
     * @param colour is the colour to be given.
     */
    public void setBatchColour(Color colour) {
        batch.setColor(colour);
    }

    /**
     * Sets up the projection matrix for the sprite batch. This is set up
     * so that it can be faked during testing.
     * @param matrix is the matrix to be set.
     */
    public void updateBatchProjectionMatrix(Matrix4 matrix) {
        batch.setProjectionMatrix(matrix);
    }

    /**
     * Begins the batch.
     */
    public void beginBatch() {
        batch.begin();
    }

    /**
     * Ends the batch.
     */
    public void endBatch() {
        batch.end();
    }

    /**
     * Disposes of graphical elements such as fonts and skins.
     */
    public void dispose() {
        batch.dispose();
        if (menuFont != null) {
            menuFont.dispose();
        }
        if (gameFont != null) {
            gameFont.dispose();
        }
        if (buttonSkin != null) {
            buttonSkin.dispose();
        }
    }

    /**
     * Flushes the batch.
     */
    public void flush() {
        batch.flush();
    }

    public Matrix4 getTransformMatrix() {
        return batch.getTransformMatrix();
    }
}
