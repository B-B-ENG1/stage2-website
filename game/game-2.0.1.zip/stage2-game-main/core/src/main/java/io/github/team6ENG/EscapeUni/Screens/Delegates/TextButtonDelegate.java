package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class TextButtonDelegate extends ButtonDelegate {

    public TextButtonDelegate() {}

    public TextButtonDelegate(TextButton button) {
        super(button);
    }

    public void setFontScale(float scale) {
        ((TextButton)button).getLabel().setFontScale(scale);
    }



}
