package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class SpriteDelegate {

    private Sprite sprite;

    public SpriteDelegate() {}

    public SpriteDelegate(Sprite sprite) {
        this.sprite = sprite;
    }

    public void draw(SpriteBatch batch) {
        sprite.draw(batch);
    }

    public float getX() {
        return sprite.getX();
    }

    public float getY() {
        return sprite.getY();
    }

    public float getWidth() {
        return sprite.getWidth();
    }

    public float getHeight() {
        return sprite.getHeight();
    }

    public void setScale(float scale) {
        sprite.setScale(scale);
    }

    public void setScale(float scaleX, float scaleY) {
        sprite.setScale(scaleX, scaleY);
    }

    public void translateX(float deltaX) {
        sprite.translateX(deltaX);
    }

    public void setX(float x) {
        sprite.setX(x);
    }

    public void translateY(float deltaY) {
        sprite.translateY(deltaY);
    }

    public void setY(float y) {
        sprite.setY(y);
    }

    public void setBounds(float x, float y, int width, int height) {
        sprite.setBounds(x, y, width, height);
    }

    /**
     * Sets the region of the sprite to the given texture. This
     * involves telling the texture region delegate to assign to the sprite's
     * texture.
     * @param texture is the texture region delegate.
     */
    public void setRegion(TextureRegionDelegate texture) {
        texture.setSpriteRegion(sprite);
    }

    public void setPosition(float x, float y) {
        sprite.setPosition(x, y);
    }

    public boolean nullTexture() {
        return sprite == null;
    }

    public void setColor(float r, float g, float b, float a) {
        sprite.setColor(r, g, b, a);
    }

    public void dispose() {
        if (!nullTexture()) {
            sprite.getTexture().dispose();
        }
    }

}
