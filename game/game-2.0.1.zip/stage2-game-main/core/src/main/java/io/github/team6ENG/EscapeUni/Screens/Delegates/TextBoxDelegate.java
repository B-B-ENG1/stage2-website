package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.scenes.scene2d.ui.TextField;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class TextBoxDelegate {

    private TextField textBox;

    public TextBoxDelegate(TextField textBox) {
        this.textBox = textBox;
    }

    protected TextBoxDelegate() {}

    public void addToStage(StageDelegate stage) {
        stage.addActor(textBox);
    }

    public String getText() {
        return textBox.getText();
    }

    public void setText(String text) {
        textBox.setText(text);
    }

    public void setPosition(float x, float y) {
        textBox.setPosition(x, y);
    }

    public float getWidth() {
        return textBox.getWidth();
    }

    public void addListener(ClickListener listener) {
        textBox.addListener(listener);
    }

    public void addListener(ChangeListener listener) {
        textBox.addListener(listener);
    }
}
