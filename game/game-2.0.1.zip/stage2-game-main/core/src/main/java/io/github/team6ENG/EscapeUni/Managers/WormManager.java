package io.github.team6ENG.EscapeUni.Managers;

import java.util.ArrayList;
import java.util.Random;

import io.github.team6ENG.EscapeUni.Entities.Worm;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;

/**
 * Places worms around the map using the same block-based algorithm
 * as PuddleManager and adds them to the provided ItemManager.
 */
public class WormManager {
    private ArrayList<Worm> worms = new ArrayList<>();
    private ArrayList<int[]> validBlockPositions = new ArrayList<>();
    Random random = new Random();
    GraphicsManager graphics;
    private final int blockSize;

    public WormManager(GraphicsManager graphics, int blockSize) {
        this.blockSize = blockSize;
        if (blockSize <= 0) {
            throw new IllegalArgumentException("Block size must be a positive integer");
        }
        this.graphics = graphics;
        validBlockPositions = BlockPositionCache.getValidBlockPositions(blockSize);
    }

    public void addWorms(int wormNumber) {
        if (wormNumber <= 0) {
            throw new IllegalArgumentException("Worm number must be a positive integer");
        }
        if (wormNumber > validBlockPositions.size()) {
            throw new IllegalArgumentException("This many worms cannot be drawn.");
        }

        // Place worms at random block positions
        for (int i = 0; i < wormNumber && !validBlockPositions.isEmpty(); i++) {
            int randomIndex = random.nextInt(validBlockPositions.size());
            int[] position = validBlockPositions.get(randomIndex);
            validBlockPositions.remove(randomIndex);
            int wormX = position[0];
            int wormY = position[1];

            int tileDimensions = GameScreen.defaultTileDimensions;
            float posX = (wormX + blockSize / 2.0f) * tileDimensions - tileDimensions / 2.0f;
            float posY = (wormY + blockSize / 2.0f) * tileDimensions - tileDimensions / 2.0f;

            worms.add(new Worm(graphics, posX, posY));
        }
    }



    public ArrayList<Worm> getWorms() {
        return worms;
    }
}
