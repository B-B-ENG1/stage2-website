package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;

/**
 * screen displayed when player wins
 */
public class WinScreen extends AbstractScreen {


    // stage and resources created in show() and disposed in dispose()
    private StageDelegate stage;
    private final GlyphLayout layout = new GlyphLayout();

    private TextButtonDelegate exitButton;
    private TextButtonDelegate mainMenuButton;
    private TextButtonDelegate achievementsButton;

    private final LeaderboardManager leaderboard;
    private java.util.List<LeaderboardManager.ScoreEntry> topScores;
    private int playerPosition = -1;  // -1 if unknown
    private static final int TOP_LIMIT = 5;

    private com.badlogic.gdx.InputProcessor previousInputProcessor; // used to restore on hide()

    private static final String TITLE_TEXT = "Congratulations, you escaped university:)";

    /**
     * initialise win screen
     * @param game current Instance of Main
     */
    public WinScreen(final Main game) {
        super(game);
        this.leaderboard = game.createLeaderboard();
        // DO NOT initialize stage/input here — do it in show()
    }

    @Override
    public void show() {
        System.out.println(game.fpsTracker.toString());
        // create stage with a fixed virtual size (you used 800x450)
        stage = graphics.createFixedStageDelegate(game.viewport);

        // remember previous input processor so we can restore it later
        previousInputProcessor = Gdx.input.getInputProcessor();
        stage.setInputProcessor();

        // build UI
        setupUI();
        // Save player's score to the leaderboard and fetch top scores
        try {
            playerPosition = leaderboard.addOrUpdateScore(game.username, (int) world.getScore());
            topScores = leaderboard.getTopScores(TOP_LIMIT);
        } catch (Exception e) {
            // prevent crashes if there is an issue with the DB
            topScores = new java.util.ArrayList<>();
            playerPosition = -1;
        }
        // Reposition buttons after we know how many scores to display
        positionButtons();
    }

    private void setupUI() {
        exitButton = createButton("Exit");
        mainMenuButton = createButton("Main Menu");
        achievementsButton = createButton("Achievements");

        exitButton.addToStage(stage);
        mainMenuButton.addToStage(stage);
        achievementsButton.addToStage(stage);

        positionButtons();
        addListeners();
    }

    private void positionButtons() {
        float w = stage.getViewport().getWorldWidth();
        float h = stage.getViewport().getWorldHeight();


        // Computes a vertical offset based on how many score entries we have.
        int entries = (topScores == null) ? 0 : topScores.size();
        // Using fixed small font  for more space
        float scoresHeight = (entries) * 15f + 30f;

        mainMenuButton.setSize(280, 70);
        exitButton.setSize(280, 70);
        achievementsButton.setSize(280, 70);

        // Position buttons with proper spacing below leaderboard
        float baseY = Math.max(100f, h * 0.28f - scoresHeight * 0.3f);
        achievementsButton.setPosition((w - achievementsButton.getWidth()) / 2f, baseY);
        mainMenuButton.setPosition((w - mainMenuButton.getWidth()) / 2f, baseY - (achievementsButton.getHeight() + 16f));
        exitButton.setPosition((w - exitButton.getWidth()) / 2f, baseY - 2f * (mainMenuButton.getHeight() + 16f));
    }


    /**
     * Getters for the play button's delegate, available for
     * testing purposes.
     * @return the exit/main menu/achievments button delegates associated with the screen.
     */
    public TextButtonDelegate getExitButton() {
        return exitButton;
    }
    public TextButtonDelegate getMainMenuButton() {
        return mainMenuButton;
    }
    public TextButtonDelegate getAchievementsButton() {
        return achievementsButton;
    }


    private void addListeners() {
        Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
        Color clickColor = new Color(0.4f, 1f, 1f, 1f);


        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                exitButton.setColor(clickColor);
                Gdx.app.postRunnable(Gdx.app::exit);
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                exitButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                exitButton.setColor(normalColor);
            }
        });
        mainMenuButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                mainMenuButton.setColor(clickColor);
                dispose();
                game.resetGame();
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                mainMenuButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                mainMenuButton.setColor(normalColor);
            }
        });
        achievementsButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                achievementsButton.setColor(clickColor);
                dispose();
                Gdx.app.postRunnable(() -> game.setScreen(new AchievementsScreen(game)));
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                achievementsButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                achievementsButton.setColor(normalColor);
            }
        });
    }

    @Override
    public void render(float delta) {
        super.render(delta);
        ScreenUtils.clear(Color.BLACK);

        // update stage
        if (stage != null) {
            stage.act(delta);
        }

        // Draw background + title using game's batch (aligned to stage camera)
        if (stage != null) {
            graphics.updateBatchProjectionMatrix(
                stage.getCameraCombinedProjection());
        } else {
            graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        }

        graphics.beginBatch();
        float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
        float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();


        float brightness = 0.85f + 0.15f * (float) Math.sin(TimeUtils.millis() / 500f);
        if (graphics.menuFont != null) {
            graphics.menuFont.setColor(brightness, brightness, brightness, 1f);
            layout.setText(graphics.menuFont, TITLE_TEXT);
            graphics.drawText(graphics.menuFont, TITLE_TEXT, (w - layout.width) / 2f, h * 0.82f);
            graphics.menuFont.setColor(Color.WHITE);

            // Use much smaller gameFont for score and leaderboard to prevent overlap
            float prevScale = graphics.gameFont.getData().scaleX;
            graphics.gameFont.getData().setScale(0.30f);  // Fixed small scale
            graphics.gameFont.setColor(Color.WHITE);

            layout.setText(graphics.gameFont, "Score: "+ (int)world.getScore());
            graphics.drawText(graphics.gameFont,
                "Score: "+ (int)world.getScore(),
                (w - layout.width) / 2f, h * 0.65f);

            // Draw player's position if available
            if (playerPosition > 0) {
                String positionText = "Position: #" + playerPosition;
                layout.setText(graphics.gameFont, positionText);
                graphics.drawText(graphics.gameFont, positionText,
                    (w - layout.width) / 2f, h * 0.61f);
            }

            // Draw top leaderboard entries
            if (topScores != null && !topScores.isEmpty()) {
                float y = h * 0.58f;
                layout.setText(graphics.gameFont, "Top Scores:");
                graphics.drawText(graphics.gameFont, "Top Scores:", (w - layout.width) / 2f, y);
                y -= 16f;
                for (LeaderboardManager.ScoreEntry s : topScores) {
                    String username = s.username == null ? "Player" : s.username;
                    if (username.length() > 20) username = username.substring(0, 20);
                    String line = username + " - " + s.score;
                    layout.setText(graphics.gameFont, line);
                    graphics.drawText(graphics.gameFont, line, (w - layout.width) / 2f, y);
                    y -= 15f;
                }
            }

            // Restore original font scale
            graphics.gameFont.getData().setScale(prevScale);

        }

        graphics.endBatch();

        if (stage != null) stage.draw();

        // allow quick keyboard start (space)
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) stage.getViewport().update(width, height, true);
        positionButtons();
    }

    @Override
    public void pause() { }

    @Override
    public void resume() { }

    @Override
    public void hide() {
        if (stage != null && stage.isInputProcessor()) {
            Gdx.input.setInputProcessor(null);
        }

        if (previousInputProcessor != null) {
            Gdx.input.setInputProcessor(previousInputProcessor);
            previousInputProcessor = null;
        }
    }

    @Override
    public void dispose() {
        // Dispose only things we created here
        if (stage != null) {
            stage.dispose();
            stage = null;
        }
        // DO NOT dispose game.menuFont or game.buttonSkin or game.batch here
    }

    /**
     * A getter for the leaderboard associated with this WinScreen.
     * @return the leaderboard.
     */
    public LeaderboardManager getLeaderboard() {
        return leaderboard;
    }
}
