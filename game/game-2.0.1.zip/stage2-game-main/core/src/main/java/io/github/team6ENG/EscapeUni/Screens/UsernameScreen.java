package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;

import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextBoxDelegate;

/**
 * first screen to display when game loads
 */
public class UsernameScreen implements Screen {

    private final Main game;
    private final GraphicsManager graphics;

    // stage and resources created in show() and disposed in dispose()
    private StageDelegate stage;
    private final GlyphLayout layout = new GlyphLayout();

    public String username;
    private TextButtonDelegate confirmButton;
    private TextBoxDelegate textBox;

    private com.badlogic.gdx.InputProcessor previousInputProcessor; // used to restore on hide()

    private static final String TITLE_TEXT = "Escape University Of York";

    /**
     * Initialise menu screen
     * @param game current instance of Main
     */
    public UsernameScreen(final Main game) {
        this.game = game;
        graphics = game.graphicsManager;
        // DO NOT initialize stage/input here — do it in show()
    }

    /**
     * Gets the text box in which the username can be typed.
     * @return the delegate of the text box.
     */
    public TextBoxDelegate getTextBox() {
        return textBox;
    }

    /**
     * Gets the text button which can be pressed to confirm the username.
     * @return the delegate of the text button.
     */
    public TextButtonDelegate getConfirmButton() {
        return confirmButton;
    }

    @Override
    public void show() {
        // create stage with a fixed virtual size (you used 800x450)
        stage = graphics.createFixedStageDelegate(game.viewport);

        // remember previous input processor so we can restore it later
        previousInputProcessor = Gdx.input.getInputProcessor();
        stage.setInputProcessor();

        if (game.elapsedTimeChecker.timerExists("Main Menu to Username")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Main Menu to Username");
            System.out.println("Time taken to get from main menu screen to " +
                "username screen: " + elapsed + " ms");
        }
        game.elapsedTimeChecker.startTimer("Main Menu to Username");

        // build UI
        setupUI();
    }
    /**
     *Add required UI elements to stage
     */
    private void setupUI() {
        textBox = graphics.createTextBox("Enter Username:",
            320,
            100,
            new Color(0.0f, 0.95f, 0.95f, 1f));
        username = textBox.getText();
        textBox.addToStage(stage);

        confirmButton = graphics.createTextButtonDelegate("Confirm");
        confirmButton.addToStage(stage);
        confirmButton.setPosition((stage.getViewport().getWorldWidth() - confirmButton.getWidth()) / 2f, stage.getViewport().getWorldHeight()/2f - 140);
        confirmButton.addListener(new com.badlogic.gdx.scenes.scene2d.utils.ClickListener(){
            @Override
            public void clicked(com.badlogic.gdx.scenes.scene2d.InputEvent event, float x, float y) {
                game.elapsedTimeChecker.startTimer("Username to Character");
                String entered = textBox.getText();
                if (entered == null || entered.trim().isEmpty()) {
                    entered = "Player";
                }
                game.username = entered.trim();
                // proceed to character select
                Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
            }
        });

        positionBox();
    }

    /**
     * Place buttons on screen
     */
    private void positionBox() {
        float w = stage.getViewport().getWorldWidth();
        float h = stage.getViewport().getWorldHeight();

        textBox.setPosition((w - textBox.getWidth()) / 2f, h / 2f );
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);

        // update stage
        if (stage != null) {
            stage.act(delta);
        }

        // Draw background + title using game's batch (aligned to stage camera)
        if (stage != null) {
            graphics.updateBatchProjectionMatrix(stage.getCameraCombinedProjection());
        } else {
            graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        }

        graphics.beginBatch();
        float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
        float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();

        float brightness = 0.85f + 0.15f * (float) Math.sin(TimeUtils.millis() / 500f);
        if (graphics.menuFont != null) {
            graphics.menuFont.setColor(brightness, brightness, brightness, 1f);
            layout.setText(graphics.menuFont, TITLE_TEXT);
            graphics.drawText(graphics.menuFont, TITLE_TEXT,  (w - layout.width) / 2f, h * 0.82f);
            graphics.menuFont.setColor(Color.WHITE);
        }

        graphics.endBatch();

        if (stage != null) stage.draw();

        // allow quick keyboard start (space)
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) stage.getViewport().update(width, height, true);
        positionBox();
    }

    @Override
    public void pause() { }

    @Override
    public void resume() { }

    @Override
    public void hide() {
        if (Gdx.input.getInputProcessor() == stage) {
            Gdx.input.setInputProcessor(null);
        }

        if (previousInputProcessor != null) {
            Gdx.input.setInputProcessor(previousInputProcessor);
            previousInputProcessor = null;
        }
    }

    @Override
    public void dispose() {
        // Dispose only things we created here
        if (stage != null) {
            stage.dispose();
            stage = null;
        }


        // DO NOT dispose game.menuFont or game.buttonSkin or game.batch here
    }
}
