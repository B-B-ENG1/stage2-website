package io.github.team6ENG.EscapeUni.Performance;

import java.util.Dictionary;
import java.util.Hashtable;

/**
 * Manages timers for different purposes. This allows us to test the speed at
 * which different responses to inputs are happening. This is for testing only.
 */
public class ElapsedTimeChecker {

    /**
     * Contains elapsed time associated with different string keys for
     * different purposes.
     */
    private Dictionary<String, Long> timeTable;

    public ElapsedTimeChecker() {
        timeTable = new Hashtable<>();
    }

    /**
     * Starts a new timer with the given key from zero.
     * @param key is the key used to identify the timer.
     */
    public void startTimer(String key) {
        timeTable.put(key, System.currentTimeMillis());
    }

    /**
     * Stops the timer with the given key and returns its value. This timer is
     * then deleted.
     * @param key is the key of the timer to be stopped.
     * @return
     */
    public float endTimer(String key) throws InvalidTimerException{
        if (timeTable.get(key) == null) {
            throw new InvalidTimerException("Timer with key " + key + "does not " +
                "exist.");
        }
        float time = System.currentTimeMillis() - timeTable.get(key);
        timeTable.remove(key);
        return time;
    }

    /**
     * Determines whether a timer exists with the given key and is currently
     * running.
     * @param key is the key used to identify the timer.
     * @return true if the timer exists and is running, and false otherwise.
     */
    public boolean timerExists(String key) {
        return timeTable.get(key) != null;
    }

    /**
     * Occurs when the timer with a given key does not exist.
     */
    private static class InvalidTimerException extends RuntimeException {
        public InvalidTimerException(String message) {
            super(message);
        }

        public InvalidTimerException() {
            super();
        }
    }

}
