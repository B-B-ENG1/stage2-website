package io.github.team6ENG.EscapeUni.Entities;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Cuts sprite sheets up into animations
 */
public class SpriteAnimations  {

    public HashMap<String, Animation<TextureRegionDelegate>> animations =
        new HashMap<String, Animation<TextureRegionDelegate>>();
    private HashMap<String, Integer[]> animationInfo = new HashMap<String, Integer[]>();
    /**
     * A personal asset manager for this particular sprite. This manager
     * has the capacity to dispose the textures for the sprite at once.
     */
    protected GraphicsManager graphics;
    private final int COLUMNS;
    private final int ROWS;
    private final TextureDelegate sheet;
    protected List<TextureDelegate> textures;

    protected TiledMapTileLayer wallsLayer;
    protected int tileDimensions = 8;

    /**
     * Loads sprite sheet
     * @param file path of sprite sheet
     * @param SheetCols Number of columns in sheet
     * @param SheetRows Number of rows in sheet
     */
    public SpriteAnimations(GraphicsManager graphics, String file, int SheetCols, int SheetRows) {
        this.graphics = graphics;
        COLUMNS = SheetCols;
        ROWS = SheetRows;
        sheet = graphics.createTextureDelegate(file);
        textures = new ArrayList<>();
        textures.add(sheet);
    }

    /**
     * Stores map info for later boundary detection
     * @param walls tilemap of game walls
     */
    public void loadSprite(TiledMapTileLayer walls, int d) {
        wallsLayer = walls;
        tileDimensions = d;
    }

    /**
     * Cuts the sprite sheet up
     * Stores resulting animations into animations dictionary
     * @param animInfo dictionary of sprite sheet layout:
     *                 key - Name of animation
     *                 Value - Array representing row of animation on sprite sheet and index of start and end frames
     * @param animationSpeed number of seconds each animation frame should last
     */
    protected void generateAnimation( HashMap<String, Integer[]> animInfo, float animationSpeed){
        //animationInfo [0] = Row of animation, [1] = start frame [2] = end frame
        animationInfo = animInfo;

        TextureRegionDelegate[][] tmp = sheet.split(
            (int)sheet.getWidth() / COLUMNS,
            (int)sheet.getHeight() / ROWS);

        TextureRegionDelegate[] frames;
        for (String key : animationInfo.keySet())
        {
            frames = new TextureRegionDelegate[animationInfo.get(key)[2]- animationInfo.get(key)[1]];
            for (int i = animationInfo.get(key)[1]; i < animationInfo.get(key)[2]; i++ ){
                frames[i - animationInfo.get(key)[1]] = tmp[animationInfo.get(key)[0]][i];
            }
            animations.put(key, new Animation<TextureRegionDelegate>(animationSpeed, frames));

        }
    }

    /**
     * Disposes of all textures stored and clears the list of textures.
     */
    public void dispose() {
        for (TextureDelegate t : textures) {
            t.dispose();
        }
        textures.clear();
    }


}
