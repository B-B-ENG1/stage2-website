package io.github.team6ENG.EscapeUni.Managers;

import java.util.ArrayList;
import java.util.Random;

import io.github.team6ENG.EscapeUni.Entities.Puddle;
import io.github.team6ENG.EscapeUni.Screens.GameScreen;

/**
 * Manages the placement of puddles and stores all puddles in one place.
 */
public class PuddleManager {

    private ArrayList<int[]> validBlockPositions = new ArrayList<>();
    private ArrayList<Puddle> puddles = new ArrayList<>();
    Random random = new Random();
    GraphicsManager graphics;
    private final int blockSize;

    /**
     * Creates a new puddle manager.
     * @param graphics is the graphics manager to be used for drawing the puddles.
     * @param blockSize is the size of blocks in which puddles may be placed.
     */
    public PuddleManager(GraphicsManager graphics, int blockSize) {
        this.blockSize = blockSize;
        if (blockSize <= 0) {
            throw new IllegalArgumentException("Block size must be a positive integer");
        }
        this.graphics = graphics;
        validBlockPositions = BlockPositionCache.getValidBlockPositions(blockSize);
    }

    public void addPuddles(int puddleNumber) {
        if (puddleNumber <= 0) {
            throw new IllegalArgumentException("Puddle number must be a positive integer");
        }
        if (puddleNumber > validBlockPositions.size()) {
            throw new IllegalArgumentException("This many puddles cannot be drawn.");
        }
        // Place puddles at random block positions

        for (int i = 0; i < puddleNumber && !validBlockPositions.isEmpty(); i++) {
            int randomIndex = random.nextInt(validBlockPositions.size());
            int[] position = validBlockPositions.get(randomIndex);
            validBlockPositions.remove(randomIndex);
            int puddleX = position[0];
            int puddleY = position[1];

            // Place puddle at the top-left of the block
            int tileDimensions = GameScreen.defaultTileDimensions;
            puddles.add(new Puddle(graphics,
                puddleX * tileDimensions,
                puddleY * tileDimensions)
            );
        }
    }

    public ArrayList<Puddle> getPuddles() {
        return puddles;
    }
}
