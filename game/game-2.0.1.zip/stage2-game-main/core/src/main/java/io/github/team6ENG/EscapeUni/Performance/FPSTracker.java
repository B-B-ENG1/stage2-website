package io.github.team6ENG.EscapeUni.Performance;

import java.util.ArrayList;
import java.util.List;

/**
 * Checks the time between frames and calculates statistics regarding the frame
 * rate. This is for testing purposes only.
 */
public class FPSTracker {

    private float meanFPS = 0;
    private float maxFPS = 0;
    private float minFPS = Float.MAX_VALUE;
    private List<Float> recentReadings;

    /**
     * The number of times frames per second has been measured.
     */
    private int checkCount = 0;

    public FPSTracker() {
        recentReadings = new ArrayList<Float>();
    }

    /**
     * When a new frame occurs, the delta (time since previous frame) is
     * used to calculate the average FPS over this time interval. This is
     * then used to update the mean FPS, max FPS and min FPS.
     * @param delta is the time since the previous frame.
     */
    public void newFrameOccurred(float delta) {
        if (delta != 0) {
            float FPS = 1 / delta;
            meanFPS = (meanFPS * checkCount + FPS) / (checkCount + 1);
            checkCount++;
            if (maxFPS < FPS) maxFPS = FPS;
            if (minFPS > FPS) minFPS = FPS;
            recentReadings.add(FPS);
        }
    }

    /**
     * Obtains the mean of recent readings and clears the recent readings.
     * @return the mean of recent readings, rounded to the nearest integer.
     */
    public int readRecent() {
        float sum = 0;
        for (float fps :  recentReadings) {
            sum += fps;
        }
        int total = recentReadings.size();
        recentReadings.clear();
        return Math.round(sum / total);
    }

    public float getMaxFPS() {
        return maxFPS;
    }

    public float getMinFPS() {
        return minFPS;
    }

    public float getMeanFPS() {
        return meanFPS;
    }

    @Override
    public String toString() {
        return "Average FPS: " + getMeanFPS() + "\n";
    }
}
