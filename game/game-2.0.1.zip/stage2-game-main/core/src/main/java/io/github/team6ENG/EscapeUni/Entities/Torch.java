package io.github.team6ENG.EscapeUni.Entities;

import io.github.team6ENG.EscapeUni.Managers.LightingManager;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;

/**
 * Represents the torch which is attached to the player. This is different to
 * the torch collectable object, however they represent the same item
 * functionally.
 */
public class Torch {

    private final LightingManager lighting;
    private final AudioManager audio;
    private final GraphicsManager graphics;
    public static final float initialScale = 0.1f;
    public final TextureDelegate texture;
    public final ImageDelegate img;
    protected boolean on = false;

    public Torch(LightingManager lighting, AudioManager audio, GraphicsManager graphics) {
        this.lighting = lighting;
        this.audio = audio;
        this.graphics = graphics;
        texture = graphics.createTextureDelegate(AssetManager.torchAsset);
        img = texture.createImage();
        img.setScale(0.02f);
        img.setRotation(180);
    }

    /**
     * Positions the torch at the player when idle.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionIdle(float playerX, float playerY) {
        img.setRotation(-60);
        img.setPosition(playerX + 22, playerY + 26);
    }

    /**
     * Positions the torch at the player facing left backwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionLeftBackwards(float playerX, float playerY) {
        img.setRotation(150);
        img.setPosition(playerX + 22, playerY + 30);
    }

    /**
     * Positions the torch at the player facing right backwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionRightBackwards(float playerX, float playerY) {
        img.setRotation(30);
        img.setPosition(playerX + 26, playerY + 25);
    }

    /**
     * Positions the torch at the player facing backwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionBackwards(float playerX, float playerY) {
        img.setRotation(120);
        img.setPosition(playerX + 22, playerY + 30);
    }

    /**
     * Positions the torch at the player facing forwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionForwards(float playerX, float playerY) {
        img.setRotation(-90);
        img.setPosition(playerX + 20, playerY + 25);
    }

    /**
     * Positions the torch at the player facing left forwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionLeftForwards(float playerX, float playerY) {
        img.setRotation(180);
        img.setPosition(playerX + 24, playerY + 30);
    }

    /**
     * Positions the torch at the player facing right forwards.
     * @param playerX is the x-position of the player.
     * @param playerY is the y-position of the player.
     */
    public void positionRightForwards(float playerX, float playerY) {
        img.setRotation(0);
        img.setPosition(playerX + 26, playerY + 25);
    }


    /**
     * Toggles the torch to be on if it was off, and off if it was on, and
     * updates lighting accordingly. Plays the toggle sound.
     */
    public void toggle() {
        toggleNoNoise();
        audio.playTorch();
    }

    /**
     * Toggles the torch to be on if it was off, and off if it was on, and
     * updates lighting accordingly.
     */
    public void toggleNoNoise() {
        on = !on;
        lighting.isVisible("playerTorch", on);
        lighting.isVisible("playerNoTorch", !on);
    }

    /**
     * Toggles the torch based on the given boolean without making noise.
     * @param on is true if the torch is to be turned on and false otherwise.
     */
    public void toggleNoNoise(boolean on) {
        this.on = on;
        lighting.isVisible("playerTorch", on);
        lighting.isVisible("playerNoTorch", !on);
    }

    public void draw() {
        graphics.drawImage(img, 1f);
    }

}
