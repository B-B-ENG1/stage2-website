package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Managers.LightingManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.World;

/**
 * A screen with capacity to write trackers for events and score.
 */
public abstract class AbstractScreen implements Screen {

    protected BitmapFont smallFont;
    protected BitmapFont font;
    protected BitmapFont bigFont;
    protected Main game;
    protected GraphicsManager graphics;
    protected LightingManager lighting;
    protected ItemManager items;
    protected World world;
    protected int tileDimensions = 8;

    public AbstractScreen(Main game) {
        this.game = game;
        world = game.getWorld();
        graphics = game.graphicsManager;
        lighting = game.lightingManager;
        items = game.itemManager;

    }

    /**
     * Draws the tracker for how many of each type of event have been
     * encountered. This is done at position {@code worldHeight - 20}.
     */
    public void drawEventTracker(BitmapFont f) {
        float y = world.getWorldHeight() - 20f;
        float lineSpacing = 15f;

        // Requirements: Events tracker and game time.
        graphics.drawText(f, ("Negative Events: " + world.getFoundNegativeEvents() +"/" + World.totalNegativeEvents), Color.WHITE, 20, y);
        y -= lineSpacing;
        graphics.drawText(f, ("Positive Events: "+ world.getFoundPositiveEvents() +"/"+ World.totalPositiveEvents), Color.WHITE, 20, y);
        y -= lineSpacing;
        graphics.drawText(f, ("Hidden Events:   "+ world.getFoundHiddenEvents() +"/"+ World.totalHiddenEvents), Color.WHITE, 20, y);
        y -= lineSpacing;
    }

    public void drawTimerAndScore(BitmapFont f) {
        //Display time with 2 digits for seconds
        int timer = (int)world.getTimer();
        graphics.drawText(f,
            (timer/60 + ":"
                +(timer % 60 <10?"0" :"" )
                +timer % 60),
            Color.WHITE, world.getWorldWidth() - 80f,
            world.getWorldHeight() - 20f);
        GlyphLayout layout = new GlyphLayout(graphics.menuFont, ("Score: " + (int)world.getScore()));
        graphics.drawText(f, ("Score: " +(int)world.getScore()), Color.WHITE,
            (world.getWorldWidth() - layout.width)/2,
            world.getWorldHeight()-20f);
    }

    /**
     * Set up each button
     * @param text buttons display text
     * @return new button with required parameters
     */
    protected TextButtonDelegate createButton(String text) {
        // If skin is null, fallback to a simple TextButton may fail; ensure game.buttonSkin exists in assets
        //ButtonDelegate button = graphics.createButtonDelegate(text);
        TextButtonDelegate button = graphics.createTextButtonDelegate(text);
        button.setFontScale(1.6f);
        button.pad(25f);
        button.setSize(320, 100);
        button.setColor(new Color(0.0f, 0.95f, 0.95f, 1f));
        return button;
    }

    @Override
    public void render(float delta) {
        game.fpsTracker.newFrameOccurred(delta);
    }

}
