package io.github.team6ENG.EscapeUni.Entities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Managers.TileManager;
import io.github.team6ENG.EscapeUni.Performance.ElapsedTimeChecker;
import io.github.team6ENG.EscapeUni.Performance.FPSTracker;
import io.github.team6ENG.EscapeUni.Screens.Delegates.SpriteDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;
import io.github.team6ENG.EscapeUni.World;

import java.util.HashMap;

/**
 * Represents and controls the main player character
 */
public class Player extends SpriteAnimations {
    private HashMap<String, Integer[]> animationInfo = new HashMap<String, Integer[]>();
    public TextureRegionDelegate currentPlayerFrame;
    public float speed = 1.25f;
    public static final float puddleSlowDuration = 2;
    private float puddleSlowedTime = 0;
    private World world;

    public SpriteDelegate sprite;
    public Torch torch;

    private boolean isFacingUp = false;
    private boolean isFacingLeft = false;
    private boolean isMoving;
    private boolean isMovingHorizontally;
    private boolean inWater;
    private boolean hasEnteredLangwith = false;
    private AudioManager audioManager;
    private ItemManager items;
    public boolean isFootsteps = false;
    private ElapsedTimeChecker timer;

    public boolean ignoreCollisions = false;

    public enum AnimationEnum {
        IDLE,
        FORWARDS,
        LEFT_FORWARDS,
        RIGHT_FORWARDS,
        BACKWARDS,
        LEFT_BACKWARDS,
        RIGHT_BACKWARDS;

        public TextureRegionDelegate getFrame(HashMap<String, Animation<TextureRegionDelegate>> animations,
                                              float stateTime, boolean looping) {
            return animations.get(toString()).getKeyFrame(stateTime, looping);
        }

        @Override
        public String toString() {
            switch(this) {
                case FORWARDS:
                    return "walkForwards";
                case LEFT_FORWARDS:
                    return "walkLeftForwards";
                case RIGHT_FORWARDS:
                    return "walkRightForwards";
                case BACKWARDS:
                    return "walkBackwards";
                case LEFT_BACKWARDS:
                    return "walkLeftBackwards";
                case RIGHT_BACKWARDS:
                    return "walkRightBackwards";
                default:
                    return "idle";
            }
        }
    }

    private AnimationEnum anim = AnimationEnum.IDLE;

    /**
     * Initialises the player and its animations
     */
    public Player(final GraphicsManager graphics, final World world,
                  AudioManager audioManager, ItemManager items) {
        super(graphics, world.getCharacterAsset(), 8, 7);
        this.audioManager = audioManager;
        this.items = items;
        this.world = world;
        // HashMap<String, Integer[]> animationInfo:
        //      key - Name of animation
        //      Value - Array representing row of animation on sprite sheet and index of start and end frames

        initializeAnimations();
        sprite = graphics.createSpriteDelegate(animations.get("walkLeftForwards").getKeyFrame(0, true));
        sprite.setBounds(sprite.getX(), sprite.getY(), 48, 64);
        torch = items.createTorch();
        timer = new ElapsedTimeChecker();
    }

    public AnimationEnum getAnimatingState() {
        return anim;
    }

    /**
     * Creates the data for all animations and puts them into animationInfo.
     * Then, this animation information is used to generate an animation.
     */
    private void initializeAnimations() {
        animationInfo.put(AnimationEnum.IDLE.toString(), new Integer[]{0,0,8});
        animationInfo.put(AnimationEnum.FORWARDS.toString(), new Integer[]{1,0,8});
        animationInfo.put(AnimationEnum.LEFT_FORWARDS.toString(), new Integer[]{2,0,8});
        animationInfo.put(AnimationEnum.RIGHT_FORWARDS.toString(), new Integer[]{6,0,8});
        animationInfo.put(AnimationEnum.RIGHT_BACKWARDS.toString(), new Integer[]{5,0,8});
        animationInfo.put(AnimationEnum.LEFT_BACKWARDS.toString(), new Integer[]{3,0,8});
        animationInfo.put(AnimationEnum.BACKWARDS.toString(), new Integer[]{4,0,8});
        generateAnimation(animationInfo, 0.3f);
    }

    /**
     * Checks if the given cell would cause a collision with the player.
     * Specifically, a player collides with a cell if and only if they are
     * unable to pass through it.
     * @param cell is the cell to be checked for a collision.
     * @return true if the player would collide with the cell, and false
     *  otherwise.
     */
    public boolean checkCellCollision(TiledMapTileLayer.Cell cell) {
        if (cell == null || ignoreCollisions == true) return false;
        if (cell.getTile().getId() == TileManager.mapWallsId) return true;
        return (cell.getTile().getId() == TileManager.mapLangwithBarriersId)
            && !hasEnteredLangwith;
    }

    /**
     * If the player's center is within the bounds of any puddle, note that a
     * puddle event has occurred and tell the player to be slowed. Otherwise,
     * stop the slowing.
     */
    public void checkPuddleCollision() {
        float playerCenterX = sprite.getX() + sprite.getWidth() / 2;
        float playerCenterY = sprite.getY() + sprite.getHeight() / 2;
        for (Puddle puddle : world.getPuddles()) {
            if (puddle.checkCollision(playerCenterX, playerCenterY)) {
                puddleSlowedTime = puddleSlowDuration;
                world.puddleEvent();
                return;
            }
        }
        puddleSlowedTime = 0;
    }

    public void checkWormCollision(float delta) {
        float playerCenterX = sprite.getX() + sprite.getWidth() / 2;
        float playerCenterY = sprite.getY() + sprite.getHeight() / 2;
        java.util.Iterator<Worm> it = world.getWorms().iterator();
        while (it.hasNext()) {
            Worm worm = it.next();
            if (!worm.isTargeted() && worm.checkCollision(playerCenterX, playerCenterY)) {
                world.wormEvent();
                world.requestWormPickup(worm);
                return;
            }
        }
    }

    /**
     * Determines whether the player is currently in a puddle in the sense that
     * they are affected by said puddle.
     * @return true if the player is currently colliding with a puddle, and
     * false otherwise.
     */
    public boolean inPuddle() {
        return puddleSlowedTime > 0;
    }

    private void startInputTimers() {
        if (Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP)) {
            timer.startTimer("MoveUp");
        }
    }

    /**
     * Check for keyboard input and move player
     * @param delta time in seconds since last frame
     */
    public void handleInput(float delta, float speedModifier) {
        startInputTimers();
        checkPuddleCollision();
        checkWormCollision(delta);

        float actualSpeed = computeDisplacement(delta, speedModifier);
        if (inWater) actualSpeed /=2;
        if (puddleSlowedTime > 0) actualSpeed *= 0.4f;
        TiledMapTileLayer.Cell cell;
        int x = (int)(sprite.getX()+(sprite.getWidth()/2))/tileDimensions;
        int y = (int)(sprite.getY()+(sprite.getHeight()/2))/tileDimensions;
        int mapWidth = wallsLayer.getWidth();
        int mapHeight = wallsLayer.getHeight();
        isMoving = false;
        isFacingLeft = false;
        isFacingUp = false;
        isMovingHorizontally = false;
        // move up
        if (Gdx.input.isKeyPressed(Input.Keys.W) || Gdx.input.isKeyPressed(Input.Keys.UP)) {
            if (y + 1 < mapHeight) {
                cell = wallsLayer.getCell(x, y + 1);
                if (!checkCellCollision(cell)) {
                    sprite.translateY(actualSpeed);
                    isMoving = true;
                    isFacingUp = true;
                }
                checkIfInWater(cell);
            }
            // If needed for testing, we can print the input delay here.
            if (timer.timerExists("MoveUp")) {
                timer.endTimer("MoveUp");
            }
        }
        // move down
        if (Gdx.input.isKeyPressed(Input.Keys.S) || Gdx.input.isKeyPressed(Input.Keys.DOWN)) {
            if (y - 1 >= 0) {
                cell = wallsLayer.getCell(x, y -1);
                if (!checkCellCollision(cell)) {
                    sprite.translateY(-actualSpeed);
                    isMoving = true;
                    isFacingUp = false;
                }
                checkIfInWater(cell);
            }
        }
        // move left
        if (Gdx.input.isKeyPressed(Input.Keys.A) || Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
            if (x - 1 >= 0) {
                cell = wallsLayer.getCell(x -1 , y);
                if (!checkCellCollision(cell)) {
                    sprite.translateX(-actualSpeed);
                    isMoving = true;
                    isFacingLeft = true;
                    isMovingHorizontally = true;
                }
                checkIfInWater(cell);
            }

        }
        // move right
        if (Gdx.input.isKeyPressed(Input.Keys.D) || Gdx.input.isKeyPressed(Input.Keys.RIGHT)) {
            if (x + 1 < mapWidth) {
                cell = wallsLayer.getCell(x + 1, y);
                if (!checkCellCollision(cell)) {
                    sprite.translateX(actualSpeed);
                    isMoving = true;
                    isFacingLeft = false;
                    isMovingHorizontally = true;
                }
                checkIfInWater(cell);
            }
        }
        // check boundary
        keepPlayerInBounds();
        if(isMoving && !isFootsteps){
            isFootsteps = true;
            audioManager.loopFootsteps();
        }
        else if (!isMoving){
            isFootsteps = false;
            audioManager.stopFootsteps();
        }

        if (Gdx.input.justTouched() && has(items.getTorch())) {
            torch.toggle();
        }
    }


    /**
     * Determines whether the player has a particular item.
     * @param item is the item to be checked.
     * @return true if the player has the item and false otherwise.
     */
    public boolean has(Collectable item) {
        if (item == null) return false;
        return item.playerHas;
    }

    public float getX() {
        return sprite.getX();
    }

    public float getY() {
        return sprite.getY();
    }

    /**
     * Calculates the displacement along a given axis associated with the
     * current speed, a given speed modifier and a given change in time.
     * @param delta is the change in time over which the displacement occurs.
     * @param speedModifier is a multiplier for the speed.
     * @return the displacement calculated.
     */
    public float computeDisplacement(float delta, float speedModifier) {
        return speed * speedModifier * 60f * delta;
    }

    private void checkIfInWater(TiledMapTileLayer.Cell cell){
        if (cell != null && cell.getTile().getId() == TileManager.mapWaterId) {
            inWater = true;
        }
        else{
            inWater = false;
        }
    }
    /**
     * Ensure player can't leave the map
     */
    private void keepPlayerInBounds() {

        float worldWidth = world.getWorldWidth(tileDimensions);
        float worldHeight = world.getWorldHeight(tileDimensions);

        if (sprite.getX() < 0) sprite.setX(0);

        if (sprite.getY() < 0) sprite.setY(0);

        if (sprite.getX() > worldWidth - sprite.getWidth())
            sprite.setX(worldWidth - sprite.getWidth());

        if (sprite.getY() > worldHeight - sprite.getHeight())
            sprite.setY(worldHeight - sprite.getHeight());
    }

    /**
     * Update player animation and torch position
     * @param stateTime time in seconds since last frame
     */
    public void updatePlayer(float stateTime){
        if (isMoving){
            if (isFacingUp){
                if (isMovingHorizontally) {
                    if (isFacingLeft) {
                        anim = AnimationEnum.LEFT_BACKWARDS;
                        torch.positionLeftBackwards(sprite.getX(), sprite.getY());
                    } else {
                        anim = AnimationEnum.RIGHT_BACKWARDS;
                        torch.positionRightBackwards(sprite.getX(), sprite.getY());
                    }
                }
                else{
                    anim = AnimationEnum.BACKWARDS;
                    torch.positionBackwards(sprite.getX(), sprite.getY());
                }
            }
            else{
                if(isMovingHorizontally) {
                    if (isFacingLeft) {
                        anim = AnimationEnum.LEFT_FORWARDS;
                        torch.positionLeftForwards(sprite.getX(), sprite.getY());
                    } else {
                        anim = AnimationEnum.RIGHT_FORWARDS;
                        torch.positionRightForwards(sprite.getX(), sprite.getY());
                    }
                }
                else{
                    anim = AnimationEnum.FORWARDS;
                    torch.positionForwards(sprite.getX(), sprite.getY());
                }

            }

        }
        else{
            anim = AnimationEnum.IDLE;
            torch.positionIdle(sprite.getX(), sprite.getY());
        }
        currentPlayerFrame = anim.getFrame(animations, stateTime, true);
        sprite.setRegion(currentPlayerFrame);

    }

    /**
     * A getter for the {@code isMoving} attribute.
     * @return true if and only if the player is moving.
     */
    public boolean isMoving() {
        return isMoving;
    }

    /**
     * A getter for the {@code inWater} attribute.
     * @return true if and only if the player is in water.
     */
    public boolean isInWater() {
        return inWater;
    }

    /**
     * Marks the fact that the player has entered Langwith.
     */
    public void hasEnteredLangwith() {
        hasEnteredLangwith = true;
    }
}
