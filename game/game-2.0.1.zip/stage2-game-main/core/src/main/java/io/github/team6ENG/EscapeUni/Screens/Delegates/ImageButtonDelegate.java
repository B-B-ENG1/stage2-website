package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.Skin;

public class ImageButtonDelegate extends ButtonDelegate {

    public ImageButtonDelegate(ImageButton imageButton) {
        super(imageButton);
    }

    public ImageButtonDelegate() {}

}
