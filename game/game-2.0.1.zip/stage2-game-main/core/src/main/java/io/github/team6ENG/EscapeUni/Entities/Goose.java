package io.github.team6ENG.EscapeUni.Entities;

import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import io.github.team6ENG.EscapeUni.Managers.*;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureRegionDelegate;
import io.github.team6ENG.EscapeUni.World;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Represents and controls a goose
 */
public class Goose extends SpriteAnimations {
    public float x;
    public float y;
    private World world;
    private HashMap<String, Integer[]> animationInfo = new HashMap<String, Integer[]>();
    public boolean isFacingLeft = true;

    private boolean hasStolenTorch = false;
    private Worm wormTarget;
    private float eatingTimer = 0;
    private boolean eating = false;

    public TextureRegionDelegate currentGooseFrame;
    protected float defaultSpeed = 0.7f;
    /**
     * The factor by which speed is multiplied when it is raining.
     */
    public static int gooseCount = 0;
    private static float rainSpeedFactor = 1.5f;
    private int idleDistanceSquared = 2000;
    public boolean isFlying;
    private TiledMapTileLayer.Cell cell;
    public Goose baby = null;
    public boolean attackModeActivated = false;
    public boolean isSleeping = false;
    private List<int[]> runPath =  Arrays.asList(new int[]{700, 400}, new int[]{340, 300}, new int[]{600, 150}, new int[]{550, 50});
    /**
     * Generate goose and its animations
     */
    public Goose(GraphicsManager graphicsManager, World world) {
        super(graphicsManager, AssetManager.gooseAsset, 15, 17);
        this.world = world;
        // HashMap<String, Integer[]> animationInfo:
        //      key - Name of animation
        //      Value - Array representing row of animation on sprite sheet and index of start and end frames
        animationInfo.put("walkLeft", new Integer[]{5,0,4});
        animationInfo.put("walkRight", new Integer[]{6,0,4});
        animationInfo.put("idleLeft", new Integer[]{16,0,5});
        animationInfo.put("idleRight", new Integer[]{15,0,5});
        animationInfo.put("flyRight", new Integer[]{11,0,10});
        animationInfo.put("flyLeft", new Integer[]{12,0,10});
        animationInfo.put("sleep", new Integer[]{13,5,10});

        gooseCount++;
        generateAnimation(animationInfo,0.13f);


    }

    /**
     * Check if goose is obstructed
     * @param tileX y position of tile approaching
     * @param tileY y position of tile approaching
     * @return true if goose can move, else false
     */
    private boolean isMoveAllowed(int tileX, int tileY) {
        // check map boundaries
        if (tileX < 0 || tileY < 0 || tileX >= wallsLayer.getWidth() ||
                tileY >= wallsLayer.getHeight()) {
            return false;
        }

        // check if tile is empty (null) or contains a wall
        cell = wallsLayer.getCell(tileX, tileY);
        if (cell == null || cell.getTile() == null) {
            return true;
        }

        return cell.getTile().getId() != TileManager.mapWallsId;
    }

    /**
     * Determines whether the goose is picking up a worm.
     * @return true if the goose is picking up a worm, and false otherwise.
     */
    public boolean isPickingWorm() {
        return wormTarget != null;
    }

    /**
     * Assigns the x and y coordinates of the goose to the provided coordinates.
     * @param x is the x-coordinate required of the goose.
     * @param y is the y-coordinate required of the goose.
     */
    public void setPosition(float x, float y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Provided there exists a worm which is targeted, either moves towards the
     * target worm (if not currently eating it) or remains idle if eating it.
     * @param delta is the time since the previous frame.
     * @param stateTime is the current animation time state of the game.
     * @param wormManager is the worm manager used to create the worms in the game.
     */
    private void targetWorm(float delta, float stateTime, WormManager wormManager) {
        if (wormTarget == null) return;
        if (!eating) {
            moveGoose(stateTime, wormTarget.x, wormTarget.y, true, false);
            float dx = Math.abs(x - wormTarget.x);
            float dy = Math.abs(y - wormTarget.y);
            if (dx < 8 && dy < 8) {
                eating = true;
                eatingTimer = 0;
            }
        } else {
            // idle while eating
            moveGoose(stateTime, wormTarget.x, wormTarget.y, false, false);
            eatingTimer += delta;
            if (eatingTimer >= 3f) {
                // remove the worm after goose eats it
                wormManager.getWorms().remove(wormTarget);
                wormTarget.collect();
                wormTarget = null;
                eating = false;
            }
        }
    }

    /**
     * Marks that the goose has stolen the torch, adjusting lighting
     * and items accordingly.
     */
    public void stealTorch(Player plr, LightingManager lighting, ItemManager items) {
        hasStolenTorch = true;
        world.negativeEventFound();
        lighting.isVisible("gooseTorch", true);
        lighting.isVisible("gooseNoTorch", false);
        lighting.isVisible("playerTorch", false);
        lighting.isVisible("playerNoTorch", true);
        items.getTorch().playerHas = false;
    }

    /**
     * Determines whether the goose has stolen the torch.
     * @return true if and only if the goose has stolen the torch.
     */
    public boolean hasStolenTorch() {
        return hasStolenTorch;
    }

    /**
     * Contains the logic for the Goose targeting on this frame. It first
     * checks for a worm to target if there isn't one already. If after this
     * there is a target then {@code targetWorm} is run.
     *
     * Otherwise, it either runs to random locations if it has not stolen their
     * torch yet, or will follow the player until it does.
     * @param delta is the time since the previous frame.
     * @param stateTime is the current animation time state of the game.
     * @param wormManager is the worm manager used to create the worms in the game.
     * @param player is the player to be followed.
     */
    public void target(float delta, float stateTime,
                             WormManager wormManager,
                             Player player) {
        // If there is no current target then check to see if one is requested.
        if (wormTarget == null) {
            wormTarget = world.consumeWormPickupRequest();
        }
        // If this results in a target being picked, then target the worm.
        if (wormTarget != null) {
            wormTarget.target();
            targetWorm(delta, stateTime, wormManager);
        }
        else if (!hasStolenTorch) {
            moveGoose(stateTime,
                player.sprite.getX() + (player.sprite.getWidth() / 2) - 20,
                player.sprite.getY() + (player.sprite.getHeight() / 2),
                player.isMoving(), false);
        }
        else{
            int[] runCoords = nextRunLocation();
            moveGoose(stateTime,runCoords[0],runCoords[1],true, false);
        }
    }

    /**
     * Move goose towards target and update animations
     * @param stateTime time in seconds since last frame
     * @param followX x of target
     * @param followY y of target
     * @param isPlayerMoving is player moving
     */
    public void moveGoose(float stateTime, float followX, float followY, boolean isPlayerMoving, boolean followIsSleeping) {
        float speed = defaultSpeed;
        if (world.isRaining()) {
            speed *= rainSpeedFactor;
        }
        int tileX = (int)(x+ getWidth() / 2) / tileDimensions;
        int tileY = (int)(y+ getHeight() / 2) / tileDimensions;
        currentGooseFrame = animations.get("sleep").getKeyFrame(stateTime, true);
        if (isSleeping){return;}
        float dx = (x-followX);
        float dy = (y-followY);
        // If target is in range, idle
        boolean idle = false;
        if (World.withinDistance(dx,dy,idleDistanceSquared)) {
            if (!isPlayerMoving && isMoveAllowed(tileX, tileY)) {
                idle = true;
                if (isFacingLeft) {
                    currentGooseFrame = animations.get("idleLeft").getKeyFrame(stateTime, true);
                } else {
                    currentGooseFrame = animations.get("idleRight").getKeyFrame(stateTime, true);
                }
                if (followIsSleeping) {
                    currentGooseFrame = animations.get("sleep").getKeyFrame(stateTime, true);

                }
            }else{
                speed *= 0.2f;
            }
        }
        if (!idle) {
            isFlying = false;
            if (x > followX) {
                isFacingLeft = true;

                if (!isMoveAllowed(tileX-1,tileY) || !isMoveAllowed(tileX,tileY)) {
                    isFlying = true;
                    x -= speed;
                }
                else if (isMoveAllowed(tileX-1,tileY)){

                    x -= speed;
                }
            }
            else if(x <= followX -5) {
                isFacingLeft = false;
                if (!isMoveAllowed(tileX+1,tileY) || !isMoveAllowed(tileX,tileY)){
                    isFlying = true;
                    x += speed;
                }
                else if(isMoveAllowed(tileX+1,tileY)){

                    x += speed;
                }
            }

            if(y > followY +5 ) {
                if (!isMoveAllowed(tileX,tileY-1) || !isMoveAllowed(tileX,tileY)) {
                    isFlying = true;
                    y -= speed;
                }
                else if(isMoveAllowed(tileX, tileY-1)){
                    y-=speed;
                }
            }
            else if (y <= followY -5 ) {
                if(!isMoveAllowed(tileX ,tileY+1) || !isMoveAllowed(tileX,tileY)){
                    isFlying = true;
                    y += speed;
                }
                else if (isMoveAllowed(tileX ,tileY+1)){

                    y += speed;
                }
            }

            if(isFlying){
                if(isFacingLeft){
                    currentGooseFrame = animations.get("flyLeft").getKeyFrame(stateTime, true);

                }
                else{
                    currentGooseFrame = animations.get("flyRight").getKeyFrame(stateTime, true);
                }
            }
            else{
                if(isFacingLeft){
                    currentGooseFrame = animations.get("walkLeft").getKeyFrame(stateTime, true);

                }
                else{
                    currentGooseFrame = animations.get("walkRight").getKeyFrame(stateTime, true);
                }

            }
        }
    }

    /**
     * get width of goose frame
     * @return width of goose
     */
    public float getWidth() {
        return currentGooseFrame != null ? currentGooseFrame.getRegionWidth() : 16f; // default value
    }

    /**
     * get height of goose frame
     * @return height of goose
     */
    public float getHeight() {

        return currentGooseFrame != null ? currentGooseFrame.getRegionHeight() : 16f;
    }

    /**
     * Recursively generate a trail of baby geese
     * Each goose points to the next baby goose
     * Base case: Goose index, only generate 5 geese
     * @param gooseIndex number of current goose in the trail
     */
    public void loadBabyGoose(int gooseIndex){
        if (gooseIndex < 5) {
            baby = new Goose(graphics, world);

            baby.loadSprite(wallsLayer, tileDimensions);
            baby.x = x;
            baby.y = y;
            baby.defaultSpeed = defaultSpeed * 0.9f;

            baby.loadBabyGoose(gooseIndex + 1);

        }
    }

    /**
     * Goose steals torch
     */
    public void attackMode(){

        defaultSpeed = 1.3f;
        idleDistanceSquared = 0;
        attackModeActivated = true;
    }

    /**
     * Path for goose to run with torch
     * @return destination coordinates
     */
    public int[] nextRunLocation(){
        if (Math.abs(x -runPath.get(0)[0]) <=5 && Math.abs(y - runPath.get(0)[1] ) <= 5&& runPath.size()>1) {

            runPath = runPath.subList(1,runPath.size());
        }
        else if(Math.abs(x -runPath.get(0)[0]) <=5 && Math.abs(y - runPath.get(0)[1] ) <= 5){
            isSleeping = true;
        }
        return runPath.get(0);
    }
}


