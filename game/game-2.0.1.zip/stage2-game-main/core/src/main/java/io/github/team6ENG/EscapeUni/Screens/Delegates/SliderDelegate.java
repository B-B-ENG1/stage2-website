package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;
import com.badlogic.gdx.scenes.scene2d.ui.Slider;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.TextButton;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class SliderDelegate {
    private Slider slider;

    public SliderDelegate(Slider slider){
        this.slider = slider;
    }

    public SliderDelegate() {}

    public void setValue(float value) {
        slider.setValue(value);
    }

    public float getValue() {
        return slider.getValue();
    }

    public void addListener(ChangeListener listener) {
        slider.addListener(listener);
    }

    public Cell addToTable(Table table) {
        return table.add(slider);
    }

    public void change(float value) {
        // For testing purposes.
        ChangeListener.ChangeEvent event = new ChangeListener.ChangeEvent();
        slider.setValue(value);
        slider.fire(event);
    }

}
