package io.github.team6ENG.EscapeUni.Managers;

import java.util.Random;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.math.Rectangle;

import io.github.team6ENG.EscapeUni.Entities.Goose;
import io.github.team6ENG.EscapeUni.Entities.Player;
import io.github.team6ENG.EscapeUni.World;

/**
 * Manages the pond area, spawning geese and creating a peaceful feather lighting effect.
 * When the player enters the pond, white feather patches light up the area.
 */
public class PondManager {

    private boolean inPond = false;
    private final Player player;
    private final LightingManager lighting;
    private final GraphicsManager graphics;
    private final World world;

    private Rectangle pondTrigger;

    private Goose pondGeese[] = new Goose[10];
    private final Random random = new Random();

    // These are offsets from camera center so it doesn't be all in center
    private float featherOffsetX1, featherOffsetY1; private int featherR1;
    private float featherOffsetX2, featherOffsetY2; private int featherR2;
    private float featherOffsetX3, featherOffsetY3; private int featherR3;

    /**
     * Constructs a PondManager with references to game systems.
     * @param player player instance used to track position.
     * @param lighting lighting manager for feather patch effects.
     * @param graphics graphics manager for creating geese entities.
     * @param world world instance.
     */
    public PondManager(Player player, LightingManager lighting, GraphicsManager graphics, World world) {
        this.player = player;
        this.lighting = lighting;
        this.graphics = graphics;
        this.world = world;
        this.pondTrigger = new Rectangle(500f,300f, 70f,70f);
    }

    /**
     * Initializes pond geese entities.
     * @param collisionLayer collision layer for pathfinding.
     * @param tileDimensions tile dimension size.
     */
    public void initializePondGeese(com.badlogic.gdx.maps.tiled.TiledMapTileLayer collisionLayer, int tileDimensions) {
        // Spawn geese at random positions inside the pond trigger rectangle
        for (int i = 0; i < pondGeese.length; i++) {
            pondGeese[i] = new Goose(graphics, world);
            pondGeese[i].loadSprite(collisionLayer, tileDimensions);
            float spawnX = pondTrigger.x + random.nextFloat() * pondTrigger.width;
            float spawnY = pondTrigger.y + random.nextFloat() * pondTrigger.height;
            pondGeese[i].x = spawnX;
            pondGeese[i].y = spawnY;
        }
    }

    /**
     * Create feather objects that follows player and on top of the night effect.
     */
    public void initializeFeatherLighting() {
        // These are offset from the camera center for the feathers
        featherOffsetX1 = -80f; featherOffsetY1 = 60f; featherR1 = 60;
        featherOffsetX2 = 100f; featherOffsetY2 = -30f; featherR2 = 70;
        featherOffsetX3 = -20f; featherOffsetY3 = -80f; featherR3 = 55;
        
        // Create the 3 feather light sources but it get offeseted later
        float px = player.sprite.getX() + player.sprite.getWidth() / 2f;
        float py = player.sprite.getY() + player.sprite.getHeight() / 2f;
        
        lighting.addLightSource("featherPatch1", px + featherOffsetX1, py + featherOffsetY1, new Color(1f, 1f, 1f, 0.6f), featherR1);
        lighting.addLightSource("featherPatch2", px + featherOffsetX2, py + featherOffsetY2, new Color(1f, 1f, 1f, 0.6f), featherR2);
        lighting.addLightSource("featherPatch3", px + featherOffsetX3, py + featherOffsetY3, new Color(1f, 1f, 1f, 0.6f), featherR3);

        // Set the feathers hidden at first
        lighting.isVisible("featherPatch1", false);
        lighting.isVisible("featherPatch2", false);
        lighting.isVisible("featherPatch3", false);
        // Feather is piority 1 so it get display over the night effect which is 0
        lighting.setPriority("featherPatch1", 1);
        lighting.setPriority("featherPatch2", 1);
        lighting.setPriority("featherPatch3", 1);
    }

    /**
     * Updates pond logic each frame.
     *
     * @param delta Time elapsed since the last frame (in seconds).
     * @param stateTime The animation state time.
     */
    public void update(float delta, float stateTime) {
        checkPondTrigger();
        
        // Update feather to follow player
        float px = player.sprite.getX() + player.sprite.getWidth() / 2f;
        float py = player.sprite.getY() + player.sprite.getHeight() / 2f;
        lighting.updateLightSource("featherPatch1", px + featherOffsetX1, py + featherOffsetY1);
        lighting.updateLightSource("featherPatch2", px + featherOffsetX2, py + featherOffsetY2);
        lighting.updateLightSource("featherPatch3", px + featherOffsetX3, py + featherOffsetY3);

        // Update pond geese positions and animations - they idle peacefully in the pond
        if (pondGeese[0] != null) {
            // Parent goose idles near center of pond
            pondGeese[0].moveGoose(stateTime, pondGeese[0].x, pondGeese[0].y, false, false);
        }
        for (int i = 1; i < pondGeese.length; i++) {
            if (pondGeese[i] != null) {
                // Baby geese idle peacefully near their spawn positions
                pondGeese[i].moveGoose(stateTime, pondGeese[i].x, pondGeese[i].y, false, false);
            }
        }
    }

    /**
     * Checks if the player is within the pond trigger area.
     */
    private void checkPondTrigger() {
        Rectangle playerRect = new Rectangle(
                player.sprite.getX(),
                player.sprite.getY(),
                player.sprite.getWidth(),
                player.sprite.getHeight()
        );

        boolean wasInPond = inPond;
        inPond = playerRect.overlaps(pondTrigger);

        // Trigger pond event when entering pond
        if (inPond && !wasInPond) {
            world.pondEvent();
            // Activate feather effect 
            lighting.isVisible("featherPatch1", true);
            lighting.isVisible("featherPatch2", true);
            lighting.isVisible("featherPatch3", true);
        }
    }

    /**
     * Returns whether the player is currently in the pond area.
     */
    public boolean isInPond() {
        return inPond;
    }

    /**
     * Gets the pond geese array.
     */
    public Goose[] getPondGeese() {
        return pondGeese;
    }

    /**
     * Gets the trigger zone rectangle.
     */
    public Rectangle getPondTrigger() {
        return pondTrigger;
    }
}
