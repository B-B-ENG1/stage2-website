package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.ui.Value;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.*;
import io.github.team6ENG.EscapeUni.World;

/**
 * Represents character select screen
 */
public class CharacterSelectScreen implements Screen {


    private final Main game;
    private final GraphicsManager graphics;
    private final World world;
    private final StageDelegate stage;

    private ImageButtonDelegate characterButton1;
    private ImageButtonDelegate characterButton2;

    /**
     * Initialises scene
     * @param game instance of Main
     */
    public CharacterSelectScreen(final Main game) {
        this.game = game;
        world = game.getWorld();
        graphics = game.graphicsManager;

        stage = graphics.createStageDelegate(game.viewport);

        Table table = new Table();
        table.setFillParent(true);
        stage.addActor(table);
        table.bottom();
        table.defaults().pad(50).fillX().uniformX().padBottom(0);


        TextureDelegate img1 = graphics.createTextureDelegate(AssetManager.femaleImgAsset);
        TextureRegionDrawableDelegate drawable1 = img1.createDrawable();
        TextureDelegate img2 = graphics.createTextureDelegate(AssetManager.maleImgAsset);
        TextureRegionDrawableDelegate drawable2 = img2.createDrawable();
        drawable1.setMinSize(drawable1.getMinWidth() * 10, drawable1.getMinHeight() * 10);
        drawable2.setMinSize(drawable2.getMinWidth() * 10, drawable2.getMinHeight() * 10);

        characterButton1 = drawable1.createImageButton();
        characterButton2 = drawable2.createImageButton();

        characterButton1.addToTable(table).height(Value.percentHeight(1f, table));
        characterButton2.addToTable(table).height(Value.percentHeight(1f, table));

        characterButton1.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {

                Gdx.app.postRunnable(() -> {
                    game.elapsedTimeChecker.startTimer("Character to Instructions");
                    world.setCharacter(AssetManager.CharacterChoice.FEMALE);
                    game.setScreen(new InstructionsScreen(game));
                    dispose();
                });
            } });
        characterButton2.addListener(new ClickListener(){
            @Override
            public void clicked(InputEvent event, float x, float y) {

                Gdx.app.postRunnable(() -> {
                    game.elapsedTimeChecker.startTimer("Character to Instructions");
                    world.setCharacter(AssetManager.CharacterChoice.MALE);
                    game.setScreen(new InstructionsScreen(game));
                    dispose();
                });
            }
        });
    }

    /**
     * getters for the two character button's delegate, available for testing purposes.
     * @return the character 1 & 2 button delegates associated with the screen.
     */
    public ImageButtonDelegate getcharacterButton1() {
        return characterButton1;
    }
    public ImageButtonDelegate getcharacterButton2() {
        return characterButton2;
    }

    @Override
    public void show() {
        stage.setInputProcessor();
        if (game.elapsedTimeChecker.timerExists("Username to Character")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Username to Character");
            System.out.println("Time taken to get from username screen to " +
                "character selection screen: " + elapsed + " ms");
        }
    }

    /**
     * Render screen
     * @param delta The time in seconds since the last render.
     */
    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);
        game.viewport.apply();
        graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);

        graphics.beginBatch();


        float worldWidth = game.viewport.getWorldWidth();
        float worldHeight = game.viewport.getWorldHeight();

        String title = "Choose your player";
        GlyphLayout layout = new GlyphLayout(graphics.menuFont, title);
        float titleX = (worldWidth - layout.width) / 2;
        graphics.menuFont.setColor(Color.WHITE);
        graphics.drawText(graphics.menuFont, title, titleX, worldHeight * 0.9f);

        graphics.endBatch();

        stage.act();
        stage.draw();


    }

    @Override
    public void resize(int width, int height) {
        stage.getViewport().update(width, height, true);

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
