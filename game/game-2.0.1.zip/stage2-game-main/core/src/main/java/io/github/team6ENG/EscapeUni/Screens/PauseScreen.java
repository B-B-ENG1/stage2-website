package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ChangeListener;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.SliderDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

/**
 * screen when game is paused, contains volume settings
 */
public class PauseScreen extends AbstractScreen {

    private final Screen playScreen;
    private final AudioManager audioManager;
    private final StageDelegate stage;

    private final SliderDelegate musicSlider;
    private final SliderDelegate volumeSlider;
    private final TextButtonDelegate continueButton;
    private final TextButtonDelegate mainMenuButton;

    /**
     * initialise pause screen
     * @param game current instance of Main
     * @param playScreen screen to return to
     * @param audioManager active audio manager
     */
    public PauseScreen(final Main game, final Screen playScreen, AudioManager audioManager) {
        super(game);
        this.playScreen = playScreen;
        this.audioManager = audioManager;
        this.stage = graphics.createFixedStageDelegate(
            new FitViewport(960, 540));

        audioManager.pauseMusic();
        audioManager.stopFootsteps();

        stage.setInputProcessor();

        // title
        Label titleLabel = new Label("Paused", new Label.LabelStyle(graphics.menuFont, Color.WHITE));

        // music slider
        Label musicLabel = new Label("Music Volume", new Label.LabelStyle(graphics.menuFont, Color.WHITE));
        musicSlider = graphics.createSliderDelegate(0f, 1f, 0.1f, false);
        musicSlider.setValue(audioManager.getMusicVolume());
        // volume slider
        Label volumeLabel = new Label("Sound Volume", new Label.LabelStyle(graphics.menuFont, Color.WHITE));
        volumeSlider = graphics.createSliderDelegate(0f, 1f, 0.01f, false);
        volumeSlider.setValue(audioManager.getGameVolume());

        continueButton = createButton("Continue");
        mainMenuButton = createButton("Main Menu");

        Table table = new Table();
        table.setFillParent(true);
        table.center();
        stage.addActor(table);

        table.add(titleLabel).padBottom(50f).row();
        table.add(musicLabel).padBottom(10f).row();
        musicSlider.addToTable(table).width(300).padBottom(40f).row();
        table.add(volumeLabel).padBottom(10f).row();
        volumeSlider.addToTable(table).width(300).padBottom(40f).row();
        continueButton.addToTable(table).width(300).height(60).padBottom(20f).row();
        mainMenuButton.addToTable(table).width(300).height(60).padBottom(20f).row();

        addListeners();
    }

    public TextButtonDelegate getContinueButton() {
        return continueButton;
    }
    public TextButtonDelegate getMainMenuButton() {
        return mainMenuButton;
    }

    private void addListeners() {
        Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
        Color clickColor = new Color(0.4f, 1f, 1f, 1f);
        // Continue button returns to same paused game
        continueButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {
                audioManager.setMusicVolume();
                audioManager.playMusic();
                playScreen.resume();
                game.setScreen(playScreen);
                dispose();
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                continueButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                continueButton.setColor(normalColor);
            }
        });
        // Main menu button resets the game
        mainMenuButton.addListener(new ClickListener() {
            public void clicked(InputEvent event, float x, float y) {;
                game.elapsedTimeChecker.startTimer("Pause to Main Menu");
                dispose();
                game.resetGame();
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                mainMenuButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                mainMenuButton.setColor(normalColor);
            }
        });
        musicSlider.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                audioManager.setMusicVolume(musicSlider.getValue());
            }

        });
        volumeSlider.addListener(new ChangeListener() {
            @Override
            public void changed(ChangeEvent event, Actor actor) {
                audioManager.setGameVolume(volumeSlider.getValue());
            }

        });


    }

    public SliderDelegate getMusicSlider() {
        return musicSlider;
    }

    public SliderDelegate getGameVolumeSlider() {
        return volumeSlider;
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);
        stage.act(delta);
        stage.draw();
    }

    @Override
    public void resize(int width, int height) {

        stage.getViewport().update(width, height, true);
    }

    @Override public void show() {
        if (game.elapsedTimeChecker.timerExists("Game to pause menu")) {
            float elapsed = game.elapsedTimeChecker.endTimer("Game to pause menu");
            System.out.println("Time taken to get to pause menu after pressing P: "
                + elapsed + " ms");
        }
    }

    @Override public void hide() {

    }
    @Override public void pause() {

    }
    @Override public void resume() {

    }
    @Override public void dispose() {
        stage.dispose();
    }
}
