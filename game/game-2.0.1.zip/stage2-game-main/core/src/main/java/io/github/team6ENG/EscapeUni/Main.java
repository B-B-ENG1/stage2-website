package io.github.team6ENG.EscapeUni;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TiledMapTileLayer;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.utils.viewport.FitViewport;

import io.github.team6ENG.EscapeUni.Managers.AudioManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Managers.ItemManager;
import io.github.team6ENG.EscapeUni.Managers.LeaderboardManager;
import io.github.team6ENG.EscapeUni.Managers.LightingManager;
import io.github.team6ENG.EscapeUni.Performance.ElapsedTimeChecker;
import io.github.team6ENG.EscapeUni.Performance.FPSTracker;
import io.github.team6ENG.EscapeUni.Screens.MainMenuScreen;

/**
 * Main class initialises the game
 */
public class Main extends Game {

    protected final World world;
    public GraphicsManager graphicsManager;
    public ItemManager itemManager;
    public LightingManager lightingManager;
    public AudioManager audioManager;
    public FitViewport viewport;
    protected Screen currentScreen;
    public String username = "Player";
    public ElapsedTimeChecker elapsedTimeChecker;
    public FPSTracker fpsTracker;

    public Main() {
        world = new World();
        elapsedTimeChecker = new ElapsedTimeChecker();
        fpsTracker = new FPSTracker();
    }

    /**
     * A getter for the {@code currentScreen} attribute.
     * @return the value of {@code currentScreen}.
     */
    public Screen getCurrentScreen() {
        return currentScreen;
    }

    @Override
    public void setScreen(Screen screen) {
        super.setScreen(screen);
        currentScreen = screen;
    }

    public void createGraphicsManager() {
        graphicsManager = new GraphicsManager();
    }

    /**
     * Gets the world associated with the game.
     * @return the attribute {@code world}.
     */
    public World getWorld() {
        return world;
    }

    /**
     * Initialise global game variables
     */
    public void create() {
        createGraphicsManager();
        audioManager = new AudioManager();
        TiledMap map = new TmxMapLoader().load("tileMap/map.tmx");
        TiledMapTileLayer collisionLayer = (TiledMapTileLayer)map.getLayers().get(0);
        int mapWidth = collisionLayer.getWidth() * collisionLayer.getTileWidth();
        int mapHeight = collisionLayer.getHeight() * collisionLayer.getTileHeight();
        lightingManager = new LightingManager(graphicsManager,
            mapWidth,
            mapHeight
        );
        itemManager = new ItemManager(this);
        viewport = new FitViewport(800, 450);
        this.setScreen(new MainMenuScreen(this));

    }


    /**`
     * Reset game and return to the main menu
     */
    public void resetGame() {
        world.reset();
        itemManager = new ItemManager(this);
        graphicsManager.initialiseFonts();
        audioManager.dispose();
        float gameVol = audioManager.getGameVolume();
        float musicVol = audioManager.getMusicVolume();
        audioManager = new AudioManager();
        audioManager.setMusicVolume(musicVol);
        audioManager.setGameVolume(gameVol);
        // Return to main menu
        this.setScreen(new MainMenuScreen(this));

    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height);
        world.setWorldHeight(viewport.getWorldHeight());
        world.setWorldWidth(viewport.getWorldWidth());
        super.resize(width, height);
    }

    public void setInputProcessor(com.badlogic.gdx.InputProcessor processor) {
        Gdx.input.setInputProcessor(processor);
    }


    public void render() {
        Gdx.gl.glClearColor(0, 0, 0, 1);    // black environment
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        viewport.apply();
        graphicsManager.updateBatchProjectionMatrix(
            viewport.getCamera().combined
        );
        super.render();
    }

    public void dispose() {
       // dispose resources in reverse creation order
        graphicsManager.dispose();
    }

    public LeaderboardManager createLeaderboard() {
        return new LeaderboardManager();
    }
}
