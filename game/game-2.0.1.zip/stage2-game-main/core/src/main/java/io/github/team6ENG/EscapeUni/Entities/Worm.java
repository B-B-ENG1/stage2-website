package io.github.team6ENG.EscapeUni.Entities;

import io.github.team6ENG.EscapeUni.Managers.AssetManager;
import io.github.team6ENG.EscapeUni.Managers.GraphicsManager;
import io.github.team6ENG.EscapeUni.Screens.Delegates.ImageDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextureDelegate;

public class Worm {

    public final float x,y;
    public final GraphicsManager graphics;
    private TextureDelegate tex;
    private ImageDelegate image;
    private boolean collected = false;
    private float scale = 0.05f;
    private boolean targeted = false;

    public Worm(GraphicsManager graphicsManager, float posX, float posY) {
        x = posX;
        y = posY;
        graphics = graphicsManager;
        tex = graphics.createTextureDelegate(AssetManager.wormAsset);
        image = tex.createImage();
        image.setScale(scale);
        // position using texture dimensions scaled to match collision calculations
        float halfWidth = tex.getWidth() * scale / 2f;
        float halfHeight = tex.getHeight() * scale / 2f;
        image.setPosition(x - halfWidth, y - halfHeight);
    }

    public ImageDelegate getImage() {
        return image;
    }

    public boolean isCollected() {
        return collected;
    }

    public void collect() {
        collected = true;
        try {
            if (image != null) image.dispose();
        } catch (Exception ignored) {}
    }

    /**
     * Mark that the worm is being eaten.
     */
    public void target() {
        targeted = true;
    }

    /**
     * @return true if the worm is being eaten and false otherwise.
     */
    public boolean isTargeted() {
        return targeted;
    }

    /**
     * Checks whether the given position on the map collides with this worm.
     *
     * @param colX is the x position of the colliding object.
     * @param colY is the y position of the colliding object.
     * @return true if there is a collision and false otherwise.
     */
    public boolean checkCollision(float colX, float colY) {
        float halfWidth = tex.getWidth() * scale / 2f;
        float halfHeight = tex.getHeight() * scale / 2f;
        return colX >= x - halfWidth && colX <= x + halfWidth &&
               colY >= y - halfHeight && colY <= y + halfHeight;
    }

    public void removeWormIfColliding(float x, float y) {
        if (checkCollision(x, y)) {
            image.dispose();
        }
    }
}
