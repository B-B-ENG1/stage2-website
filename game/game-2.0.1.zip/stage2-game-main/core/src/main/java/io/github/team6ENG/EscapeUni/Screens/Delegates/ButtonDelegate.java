package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.ui.Button;
import com.badlogic.gdx.scenes.scene2d.ui.Cell;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;

public class ButtonDelegate {

    protected Button button;

    public ButtonDelegate(Button button) {
        this.button = button;
    }

    protected ButtonDelegate() {}

    public void pad(float pad) {
        button.pad(pad);
    }

    public void setSize(float width, float height) {
        button.setSize(width, height);
    }

    public float getWidth() {
        return button.getWidth();
    }

    public float getHeight() {
        return button.getHeight();
    }

    public void setPosition(float x, float y) {
        button.setPosition(x, y);
    }

    public void setColor(Color color) {
        button.setColor(color);
    }

    /**
     * Adds the contained button to the stage.
     * @param stage is the delegate for the stage to be added to.
     */
    public void addToStage(StageDelegate stage) {
        stage.addActor(button);
    }

    public Cell addToTable(Table table) {
        return table.add(button);
    }

    public void addListener(ClickListener listener) {
        button.addListener(listener);
    }

    public void click(float x, float y) {
        // For testing purposes.
        InputEvent down = new InputEvent();
        down.setType(InputEvent.Type.touchDown);
        button.getClickListener().clicked(down, x, y);
        InputEvent up = new InputEvent();
        up.setType(InputEvent.Type.touchUp);
        button.getClickListener().clicked(up, x, y);

    }

    public void enter(float x, float y) {
        // For testing purposes.
        InputEvent event = new InputEvent();
        event.setType(InputEvent.Type.enter);
        button.getClickListener().enter(event, x, y, 1, new Actor());
    }

    public void exit(float x, float y) {
        // For testing purposes.
        InputEvent event = new InputEvent();
        event.setType(InputEvent.Type.exit);
        button.getClickListener().enter(event, x, y, 1, new Actor());
    }

    public Color getColor() {
        return button.getColor();
    }
}
