package io.github.team6ENG.EscapeUni.Managers;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.badlogic.gdx.utils.JsonReader;
import com.badlogic.gdx.utils.JsonValue;

/**
 * Remote leaderboard system that falls back to local SQlite db on connection failure.
 */
public class LeaderboardManager {
    private static final String DB_URL = "jdbc:sqlite:scores.db";
    private static final String REMOTE_TOP_URL = "https://api.bensonc.how/eng1/top";
    private static final String REMOTE_SUBMIT_URL = "https://api.bensonc.how/eng1/submit";
    private static final int REMOTE_TIMEOUT_MS = 5000;

    public LeaderboardManager() {
        createTableIfNotExists();
    }

    protected void createTableIfNotExists() {
        String sql = "CREATE TABLE IF NOT EXISTS Player_Scores ("
            + " Username TEXT,"
            + " Score INTEGER"
            + ")";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.execute();
        } catch (SQLException e) {
            System.err.println("Error creating leaderboard table: " + e.getMessage());
        }
    }

    /**
     * Add a new score for a username every run
     * Tries remote API first if no work fall back to the local DB
     * Returns the player's position on the leaderboard
     */
    public int addOrUpdateScore(String username, int score) {
        if (username == null || username.trim().isEmpty()) {
            username = "Player";
        }
        username = username.trim();

        // Try remote submission first
        int position = submitScoreRemote(username, score);
        if (position > 0) {
            System.out.println("Score submitted to remote server. Position: " + position);
            return position;
        } else {
            System.out.println("Remote submission failed, saving locally");
            position = addScoreLocal(username, score);
            return position;
        }
    }

    protected int submitScoreRemote(String username, int score) {
        try {
            URL url = new URL(REMOTE_SUBMIT_URL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);
            conn.setConnectTimeout(REMOTE_TIMEOUT_MS);
            conn.setReadTimeout(REMOTE_TIMEOUT_MS);

            String jsonPayload = String.format("{\"name\":\"%s\",\"score\":%d}", username, score);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            int responseCode = conn.getResponseCode();
            if (responseCode >= 200 && responseCode < 300) {
                try (Scanner scanner = new Scanner(conn.getInputStream(), StandardCharsets.UTF_8.name())) {
                    StringBuilder response = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        response.append(scanner.nextLine());
                    }
                    conn.disconnect();
                    return parsePositionFromJson(response.toString());
                }
            }
            conn.disconnect();
            return -1;
        } catch (Exception e) {
            System.err.println("Remote submit error: " + e.getMessage());
            return -1;
        }
    }

    private int parsePositionFromJson(String json) {
        try {
            JsonReader jsonReader = new JsonReader();
            JsonValue root = jsonReader.parse(json);
            return root.getInt("position", -1);
        } catch (Exception e) {
            System.err.println("Error parsing position from JSON: " + e.getMessage());
            return -1;
        }
    }

    protected int addScoreLocal(String username, int score) {
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            String ins = "INSERT INTO Player_Scores(Username, Score) VALUES(?,?)";
            try (PreparedStatement insP = conn.prepareStatement(ins)) {
                insP.setString(1, username);
                insP.setInt(2, score);
                insP.executeUpdate();
            }
            
            // Calculate player's position by counting how many scores is higher
            String countSql = "SELECT COUNT(*) as count FROM Player_Scores WHERE Score > ?";
            try (PreparedStatement countP = conn.prepareStatement(countSql)) {
                countP.setInt(1, score);
                ResultSet rs = countP.executeQuery();
                if (rs.next()) {
                    int position = rs.getInt("count") + 1;  // Position is count + 1
                    System.out.println("Score saved locally. Position: " + position);
                    return position;
                }
            }
        } catch (SQLException e) {
            System.err.println("Error adding score: " + e.getMessage());
        }
        return -1;
    }

    /**
     * Returns the top scores ordered by score descend
     * Tries remote API first if no work fall back to the local DB
     */
    public List<ScoreEntry> getTopScores(int limit) {
        List<ScoreEntry> remoteScores = getTopScoresRemote(limit);
        if (remoteScores != null && !remoteScores.isEmpty()) {
            System.out.println("Retrieved scores from remote server");
            return remoteScores;
        } else {
            System.out.println("Remote retrieval failed, using local database");
            return getTopScoresLocal(limit);
        }
    }

    protected List<ScoreEntry> getTopScoresRemote(int limit) {
        try {
            URL url = new URL(REMOTE_TOP_URL + "?limit=" + limit);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(REMOTE_TIMEOUT_MS);
            conn.setReadTimeout(REMOTE_TIMEOUT_MS);

            int responseCode = conn.getResponseCode();
            if (responseCode >= 200 && responseCode < 300) {
                try (Scanner scanner = new Scanner(conn.getInputStream(), StandardCharsets.UTF_8.name())) {
                    StringBuilder response = new StringBuilder();
                    while (scanner.hasNextLine()) {
                        response.append(scanner.nextLine());
                    }
                    conn.disconnect();
                    return parseJsonScores(response.toString());
                }
            }
            conn.disconnect();
            return null;
        } catch (Exception e) {
            System.err.println("Remote retrieval error: " + e.getMessage());
            return null;
        }
    }

    private List<ScoreEntry> parseJsonScores(String json) {
        List<ScoreEntry> scores = new ArrayList<>();
        try {
            JsonReader jsonReader = new JsonReader();
            JsonValue root = jsonReader.parse(json);

            if (root.isArray()) {
                for (JsonValue entry : root) {
                    String username = entry.getString("name", "Player");
                    int score = entry.getInt("score", 0);
                    scores.add(new ScoreEntry(username, score));
                }
            }
        } catch (Exception e) {
            System.err.println("Error parsing JSON: " + e.getMessage());
        }
        return scores;
    }

    protected List<ScoreEntry> getTopScoresLocal(int limit) {
        List<ScoreEntry> out = new ArrayList<>();
        String sql = "SELECT Username, Score FROM Player_Scores ORDER BY Score DESC LIMIT ?";
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                out.add(new ScoreEntry(rs.getString("Username"), rs.getInt("Score")));
            }
        } catch (SQLException e) {
            System.err.println("Error retrieving top scores: " + e.getMessage());
        }
        return out;
    }

    public static class ScoreEntry {
        public final String username;
        public final int score;
        public final int position;

        public ScoreEntry(String username, int score) {
            this(username, score, -1);
        }

        public ScoreEntry(String username, int score, int position) {
            this.username = username;
            this.score = score;
            this.position = position;
        }

        @Override
        public String toString() {
            return "Username: " + username + ", Score: " + score;
        }

        @Override
        public boolean equals(Object o) {
            if (o instanceof ScoreEntry) {
                ScoreEntry entry = (ScoreEntry) o;
                return this.username.equals(entry.username) && this.score == entry.score;
            }
            return false;
        }
    }
}
