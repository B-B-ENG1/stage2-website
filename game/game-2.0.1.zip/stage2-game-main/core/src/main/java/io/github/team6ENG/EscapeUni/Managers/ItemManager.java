package io.github.team6ENG.EscapeUni.Managers;

import java.util.ArrayList;

import io.github.team6ENG.EscapeUni.Entities.Collectable;
import io.github.team6ENG.EscapeUni.Entities.Torch;
import io.github.team6ENG.EscapeUni.Main;

public class ItemManager {
    private GraphicsManager graphics;
    private AudioManager audio;
    private LightingManager lighting;

    private Collectable torch;
    private Collectable gooseFood;
    private Collectable idCard;
    private Collectable pizza;
    private Collectable phone;
    private Collectable goggles;
    private Collectable potion;
    private ArrayList<Collectable> energyDrinks = new ArrayList<>();

    public ItemManager(Main main) {
        graphics = main.graphicsManager;
        audio = main.audioManager;
        lighting = main.lightingManager;

        gooseFood = new Collectable("goose food", graphics, 500, 1500, 0.03f, true,
            AssetManager.gooseFoodAsset, "GameScreen", audio);
        idCard = new Collectable("ID card", graphics, 300, 200, 0.05f,
            false, main.getWorld().getIDCardAsset(), "RonCookeScreen", audio);
        pizza = new Collectable("pizza", graphics, 600, 100, 0.4f, true,
            AssetManager.pizzaAsset, "LangwithScreen", audio);
        phone = new Collectable("phone", graphics, 100, 100, 0.05f, true,
            AssetManager.phoneAsset, "LangwithScreen", audio);
        torch = new Collectable("torch", graphics, 300, 220, 0.1f, false,
            AssetManager.torchAsset, "RonCookeScreen", audio);
        goggles = new Collectable("goggles", graphics, 300, 200, 0.1f, false,
            AssetManager.gogglesAsset, "PiazzaScreen", audio);
        potion = new Collectable("potion", graphics, 300, 220, 0.1f, false,
            AssetManager.potionAsset, "PiazzaScreen", audio);
    }

    /**
     * Create a torch object as a tool that the player carries. This is different to
     * the Collectable torch, which represents the same entity before it has been
     * collected by the player.
     * @return the new torch object.
     */
    public Torch createTorch() {
        return new Torch(lighting, audio, graphics);
    }

    /**
     * Returns the torch in this item manager if it exists, or null otherwise.
     * @return the torch in this manager, if it exists.
     */
    public Collectable getTorch() {
        return torch;
    }

    public Collectable getGooseFood() {
        return gooseFood;
    }

    public Collectable getIdCard() {
        return idCard;
    }

    public Collectable getPizza() {
        return pizza;
    }

    public Collectable getPhone() {
        return phone;
    }

    public Collectable getGoggles() {
        return goggles;
    }

    public Collectable getPotion() {
        return potion;
    }

    /**
     * Adds a dynamically-placed energy drink collectable to this manager.
     * @param drink the collectable to add
     */
    public void addEnergyDrink(Collectable drink) {
        if (drink == null) return;
        energyDrinks.add(drink);
    }

    public ArrayList<Collectable> getItems() {
        ArrayList<Collectable> items = new ArrayList<>();
        if (torch != null) {
            items.add(torch);
        }
        if (gooseFood != null) {
            items.add(gooseFood);
        }
        if (idCard != null) {
            items.add(idCard);
        }
        if (pizza != null) {
            items.add(pizza);
        }
        if (phone != null) {
            items.add(phone);
        }
        if (!energyDrinks.isEmpty()) {
            items.addAll(energyDrinks);
        }
        if (goggles != null) {
            items.add(goggles);
        }
        if (potion != null) {
            items.add(potion);
        }
        return items;
    }

    public void dispose() {
        if (torch != null) {
            torch.dispose();
        }
        if (gooseFood != null) {
            gooseFood.dispose();
        }
        if (idCard != null) {
            idCard.dispose();
        }
        if (pizza != null) {
            pizza.dispose();
        }
        if (phone != null) {
            phone.dispose();
        }
        if (!energyDrinks.isEmpty()) {
            for (Collectable item : energyDrinks) item.dispose();
        }
    }

    /**
     * Reset all the items to initial states
     */
    public void reset() {
        if (torch != null) torch.playerHas = false;
        if (gooseFood != null) gooseFood.playerHas = false;
        if (idCard != null) idCard.playerHas = false;
        if (pizza != null) pizza.playerHas = false;
        if (phone != null) phone.playerHas = false;
        if (goggles != null) goggles.playerHas = false;
        if (potion != null) potion.playerHas = false;
        energyDrinks.clear();
    }
}
