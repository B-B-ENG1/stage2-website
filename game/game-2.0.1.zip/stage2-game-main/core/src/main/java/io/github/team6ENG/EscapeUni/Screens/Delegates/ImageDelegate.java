package io.github.team6ENG.EscapeUni.Screens.Delegates;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.ui.Image;

public class ImageDelegate {

    private Image image;

    public ImageDelegate() {}

    public ImageDelegate(Image image) {
        this.image = image;
    }

    public void setPosition(float x, float y) {
        image.setPosition(x, y);
    }

    public void setScale(float scale) {
        image.setScale(scale);
    }

    public void setScale(float scaleX, float scaleY) {
        image.setScale(scaleX, scaleY);
    }

    public void setRotation(float rotation) {
        image.setRotation(rotation);
    }

    public void draw(SpriteBatch batch, float parentAlpha) {
        image.draw(batch, parentAlpha);
    }

    public float getHeight() {
        return image.getHeight();
    }

    public float getWidth() {
        return image.getWidth();
    }

    public void setWidth(float width) {
        image.setWidth(width);
    }

    public void setHeight(float height) {
        image.setHeight(height);
    }

    public void dispose() {
        image.remove();
    }
}
