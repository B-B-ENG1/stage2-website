package io.github.team6ENG.EscapeUni.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.TimeUtils;
import io.github.team6ENG.EscapeUni.Main;
import io.github.team6ENG.EscapeUni.Screens.Delegates.TextButtonDelegate;
import io.github.team6ENG.EscapeUni.Screens.Delegates.StageDelegate;

/**
 * Instructions Screen, displays before game starts
 */
public class InstructionsScreen extends AbstractScreen {

    // stage and resources created in show() and disposed in dispose()
    private StageDelegate stage;
    private final GlyphLayout layout = new GlyphLayout();

    public static final Color normalColor = new Color(0.0f, 0.95f, 0.95f, 1f);
    public static final Color clickColor = new Color(0.4f, 1f, 1f, 1f);
    private TextButtonDelegate playButton;

    private com.badlogic.gdx.InputProcessor previousInputProcessor; // used to restore on hide()

    private static final String TITLE_TEXT = "It's time to meet your friends in town\nand the bus leaves in 5 minutes, better\ngrab your phone from your room in\nLangwith college before you board.";

    /**
     * Initialise the instructions screen
     * @param game current instance of game
     */
    public InstructionsScreen(final Main game) {
        super(game);
        // DO NOT initialize stage/input here — do it in show()
    }

    @Override
    public void show() {
        // create stage with a fixed virtual size (you used 800x450)
        stage = graphics.createFixedStageDelegate(game.viewport);

        // remember previous input processor so we can restore it later
        previousInputProcessor = Gdx.input.getInputProcessor();
        stage.setInputProcessor();

        // build UI
        setupUI();

        if (game.elapsedTimeChecker.timerExists("Character to Instructions")) {
            System.out.println(
                "Time taken to get from character select screen to instructions" +
                " screen: " +
                game.elapsedTimeChecker.endTimer("Character to Instructions") +
                "ms"
            );
        }
    }

    /**
     *Add required UI elements to stage
     */
    private void setupUI() {
        playButton = createButton("Play");

        playButton.addToStage(stage);

        positionButtons();
        addListeners();
    }


    /**
     * Place buttons on screen
     */
    private void positionButtons() {
        float w = stage.getViewport().getWorldWidth();
        float h = stage.getViewport().getWorldHeight();

        playButton.setPosition((w - playButton.getWidth()) / 2f, h / 2f -100);
    }

    /**
     * A getter for the play button's delegate, available for
     * testing purposes.
     * @return the play button delegate associated with the screen.
     */
    public TextButtonDelegate getPlayButton() {
        return playButton;
    }



    /**
     * Add listeners for button functionality
     */
    private void addListeners() {


        playButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                game.elapsedTimeChecker.startTimer("First load map");
                playButton.setColor(clickColor);
                game.setScreen(new GameScreen(game));
            }
            @Override
            public void enter(InputEvent event, float x, float y, int pointer, Actor fromActor) {
                playButton.setColor(clickColor);
            }
            @Override
            public void exit(InputEvent event, float x, float y, int pointer, Actor toActor) {
                playButton.setColor(normalColor);
            }
        });
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(Color.BLACK);

        // update stage
        if (stage != null) {
            stage.act(delta);
        }

        // Draw background + title using game's batch (aligned to stage camera)
        if (stage != null) {
            graphics.updateBatchProjectionMatrix(stage.getCameraCombinedProjection());
        } else {
            graphics.updateBatchProjectionMatrix(game.viewport.getCamera().combined);
        }

        graphics.beginBatch();
        float w = (stage != null) ? stage.getViewport().getWorldWidth() : game.viewport.getWorldWidth();
        float h = (stage != null) ? stage.getViewport().getWorldHeight() : game.viewport.getWorldHeight();


        float brightness = 0.85f + 0.15f * (float) Math.sin(TimeUtils.millis() / 500f);
        if (graphics.menuFont != null) {
            graphics.menuFont.setColor(brightness, brightness, brightness, 1f);
            layout.setText(graphics.menuFont, TITLE_TEXT);
            graphics.drawText(graphics.menuFont, TITLE_TEXT,
                (w - layout.width) / 2f, h * 0.82f);
            graphics.menuFont.setColor(Color.WHITE);

        }

        graphics.endBatch();

        if (stage != null) stage.draw();

        // allow quick keyboard start (space)
        if (Gdx.input.isKeyJustPressed(Input.Keys.SPACE)) {
            Gdx.app.postRunnable(() -> game.setScreen(new CharacterSelectScreen(game)));
        }
    }

    @Override
    public void resize(int width, int height) {
        if (stage != null) stage.getViewport().update(width, height, true);
        positionButtons();
    }

    @Override
    public void pause() { }

    @Override
    public void resume() { }

    @Override
    public void hide() {
        if (stage.isInputProcessor()) {
            Gdx.input.setInputProcessor(null);
        }

        if (previousInputProcessor != null) {
            Gdx.input.setInputProcessor(previousInputProcessor);
            previousInputProcessor = null;
        }
    }

    @Override
    public void dispose() {
        // Dispose only things we created here
        stage.dispose();
        // DO NOT dispose game.menuFont or game.buttonSkin or game.batch here
    }
}
